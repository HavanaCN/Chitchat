-- Chitchat Forum Database Schema
-- Version 1.0.0

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Groups (roles)
CREATE TABLE IF NOT EXISTS `groups` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`         VARCHAR(50) NOT NULL,
  `display_name` VARCHAR(80) DEFAULT NULL,
  `permissions`  TEXT NOT NULL,
  `color`        VARCHAR(20) DEFAULT '#666666',
  `icon`         VARCHAR(50) DEFAULT NULL,
  `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Users
CREATE TABLE IF NOT EXISTS `users` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `username`         VARCHAR(50) NOT NULL UNIQUE,
  `email`            VARCHAR(150) NOT NULL UNIQUE,
  `password`         VARCHAR(255) NOT NULL,
  `avatar`           VARCHAR(255) DEFAULT NULL,
  `bio`              TEXT DEFAULT NULL,
  `group_id`         INT UNSIGNED NOT NULL DEFAULT 3,
  `suspended_until`  DATETIME DEFAULT NULL,
  `last_seen_at`     DATETIME DEFAULT NULL,
  `created_at`       DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_email` (`email`),
  INDEX `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Remember tokens
CREATE TABLE IF NOT EXISTS `remember_tokens` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT UNSIGNED NOT NULL,
  `token`      VARCHAR(64) NOT NULL UNIQUE,
  `expires_at` DATETIME NOT NULL,
  INDEX `idx_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tags / Categories
CREATE TABLE IF NOT EXISTS `tags` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`        VARCHAR(80) NOT NULL,
  `slug`        VARCHAR(80) NOT NULL UNIQUE,
  `description` VARCHAR(500) DEFAULT NULL,
  `color`       VARCHAR(20) DEFAULT '#0077cc',
  `icon`        VARCHAR(50) DEFAULT NULL,
  `parent_id`   INT UNSIGNED DEFAULT NULL,
  `position`    SMALLINT UNSIGNED DEFAULT 0,
  `is_hidden`   TINYINT(1) DEFAULT 0,
  `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Discussions
CREATE TABLE IF NOT EXISTS `discussions` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title`          VARCHAR(200) NOT NULL,
  `user_id`        INT UNSIGNED NOT NULL,
  `first_post_id`  INT UNSIGNED DEFAULT NULL,
  `last_post_id`   INT UNSIGNED DEFAULT NULL,
  `last_user_id`   INT UNSIGNED DEFAULT NULL,
  `comment_count`  INT UNSIGNED DEFAULT 0,
  `is_sticky`      TINYINT(1) DEFAULT 0,
  `is_locked`      TINYINT(1) DEFAULT 0,
  `is_featured`    TINYINT(1) DEFAULT 0,
  `is_hidden`      TINYINT(1) DEFAULT 0,
  `last_posted_at` DATETIME DEFAULT NULL,
  `created_at`     DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_user` (`user_id`),
  INDEX `idx_last_posted` (`last_posted_at`),
  INDEX `idx_sticky` (`is_sticky`),
  INDEX `idx_featured` (`is_featured`),
  FULLTEXT KEY `ft_title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Discussion-Tag pivot
CREATE TABLE IF NOT EXISTS `discussion_tag` (
  `discussion_id` INT UNSIGNED NOT NULL,
  `tag_id`        INT UNSIGNED NOT NULL,
  PRIMARY KEY (`discussion_id`, `tag_id`),
  INDEX `idx_tag` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Posts
CREATE TABLE IF NOT EXISTS `posts` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `discussion_id` INT UNSIGNED NOT NULL,
  `user_id`       INT UNSIGNED NOT NULL,
  `number`        SMALLINT UNSIGNED DEFAULT 1,
  `content`       MEDIUMTEXT NOT NULL,
  `reply_to`      INT UNSIGNED DEFAULT NULL,
  `like_count`    INT UNSIGNED DEFAULT 0,
  `is_hidden`     TINYINT(1) DEFAULT 0,
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_discussion` (`discussion_id`),
  INDEX `idx_user` (`user_id`),
  FULLTEXT KEY `ft_content` (`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Likes
CREATE TABLE IF NOT EXISTS `likes` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT UNSIGNED NOT NULL,
  `post_id`    INT UNSIGNED NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_user_post` (`user_id`, `post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`      INT UNSIGNED NOT NULL,
  `from_user_id` INT UNSIGNED DEFAULT NULL,
  `type`         VARCHAR(50) NOT NULL,
  `data`         TEXT DEFAULT NULL,
  `is_read`      TINYINT(1) DEFAULT 0,
  `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_read` (`user_id`, `is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings
CREATE TABLE IF NOT EXISTS `settings` (
  `key`   VARCHAR(100) PRIMARY KEY,
  `value` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Email verification / reset codes
CREATE TABLE IF NOT EXISTS `email_codes` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `email`      VARCHAR(150) NOT NULL,
  `purpose`    VARCHAR(50) NOT NULL,
  `code`       VARCHAR(12) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `used_at`    DATETIME DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_email_purpose` (`email`, `purpose`),
  INDEX `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Plugins
CREATE TABLE IF NOT EXISTS `plugins` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `slug`         VARCHAR(100) NOT NULL UNIQUE,
  `name`         VARCHAR(150) NOT NULL,
  `version`      VARCHAR(20) DEFAULT '1.0.0',
  `is_active`    TINYINT(1) DEFAULT 0,
  `installed_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `plugin`      VARCHAR(100) NOT NULL DEFAULT 'core',
  `version`     VARCHAR(100) NOT NULL,
  `executed_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
