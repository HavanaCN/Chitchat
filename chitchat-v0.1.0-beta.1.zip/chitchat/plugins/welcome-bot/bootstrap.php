<?php
namespace Plugins\WelcomeBot;

use App\Core\Container;
use App\Core\EventDispatcher;

class PluginBootstrap
{
    protected Container $container;
    protected EventDispatcher $events;

    public function __construct(Container $container, EventDispatcher $events)
    {
        $this->container = $container;
        $this->events    = $events;
    }

    public function boot(): void
    {
        // Listen for user registration
        $this->events->listen('user.registered', function (array $data) {
            $db = $this->container->make('db');
            $userId = $data['user_id'] ?? null;
            if (!$userId) return;

            // Send welcome notification
            $db->table('notifications')->insert([
                'user_id'      => $userId,
                'from_user_id' => 1, // System / Admin
                'type'         => 'welcome',
                'data'         => json_encode(['message' => '欢迎加入 Chitchat！请先完善你的个人资料。']),
                'is_read'      => 0,
                'created_at'   => date('Y-m-d H:i:s'),
            ]);
        });
    }
}
