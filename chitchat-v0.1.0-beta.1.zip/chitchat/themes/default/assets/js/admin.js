/**
 * Chitchat Admin Panel - JavaScript
 */

(function () {
  // Auto-hide alerts
  document.querySelectorAll('.alert-success, .alert-error').forEach(el => {
    if (el.style.display !== 'none') {
      setTimeout(() => { el.style.display = 'none'; }, 4000);
    }
  });

  // Confirm delete actions
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', function (e) {
      if (!confirm(this.dataset.confirm)) e.preventDefault();
    });
  });

  console.log('%c🗨️ Chitchat Admin', 'color:#0077cc;font-weight:bold');
})();
