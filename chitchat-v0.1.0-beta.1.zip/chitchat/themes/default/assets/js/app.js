/**
 * Chitchat Forum - Main JavaScript
 * Version: 1.0.0
 */

(function () {
  'use strict';

  const SMTP_ENABLED = Boolean(window.CHITCHAT_SMTP_ENABLED);
  const SMTP_UNAVAILABLE_MESSAGE = window.CHITCHAT_SMTP_UNAVAILABLE_MESSAGE || '当前站点尚未启用邮件服务，暂不支持相关功能。';
  const countdownTimers = new WeakMap();

  function $(sel, ctx = document) { return ctx.querySelector(sel); }
  function $$(sel, ctx = document) { return Array.from(ctx.querySelectorAll(sel)); }
  function on(el, ev, fn) { el && el.addEventListener(ev, fn); }
  function url(path, query) {
    if (typeof window.chitchatRoute === 'function') {
      return window.chitchatRoute(path, query);
    }
    return typeof window.chitchatUrl === 'function' ? window.chitchatUrl(path) : path;
  }

  function isTypingField(target) {
    if (!target || !(target instanceof HTMLElement)) {
      return false;
    }
    const tagName = target.tagName;
    return target.isContentEditable || tagName === 'INPUT' || tagName === 'TEXTAREA' || tagName === 'SELECT';
  }

  function getHomeUrl() {
    return url('');
  }

  function getSearchUrl(query) {
    return url('search', query ? { q: query } : {});
  }

  function getPrimarySearchInput() {
    return document.querySelector('.page-search input[name="q"], .header-search-form input[name="q"]');
  }


  function getSearchPage() {
    return document.querySelector('[data-search-page="true"]');
  }

  function navigateToSearch(query) {
    const keyword = String(query || '').trim();
    location.href = getSearchUrl(keyword);
  }

  function getCsrf() {

    return document.getElementById('loginForm')?.querySelector('[name=_token]')?.value
      || document.querySelector('[name=_token]')?.value
      || '';
  }

  function hideMessage(el) {
    if (!el) return;
    el.textContent = '';
    el.style.display = 'none';
  }

  function showMessage(el, message) {
    if (!el) return;
    el.textContent = message;
    el.style.display = message ? 'block' : 'none';
  }

  function clearModalMessages() {
    ['loginError', 'registerError', 'registerSuccess', 'forgotPasswordError', 'forgotPasswordSuccess'].forEach(id => {
      hideMessage(document.getElementById(id));
    });
  }

  function collectMessages(payload) {
    if (!payload || typeof payload !== 'object') {
      return [];
    }
    if (payload.error) {
      return [String(payload.error)];
    }
    if (payload.errors && typeof payload.errors === 'object') {
      return Object.values(payload.errors).flat().map(String);
    }
    if (payload.message) {
      return [String(payload.message)];
    }
    return [];
  }

  async function requestJson(endpoint, data) {
    const response = await fetch(url(endpoint), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-Token': getCsrf(),
      },
      body: JSON.stringify(data),
    });

    let payload = {};
    try {
      payload = await response.json();
    } catch (_) {
      payload = {};
    }

    return { response, payload };
  }

  function startCountdown(button, seconds, idleText) {
    if (!button) return;

    if (countdownTimers.has(button)) {
      clearInterval(countdownTimers.get(button));
    }

    let remaining = seconds;
    button.disabled = true;
    button.textContent = remaining + 's';

    const timer = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(timer);
        countdownTimers.delete(button);
        button.disabled = false;
        button.textContent = idleText;
        return;
      }
      button.textContent = remaining + 's';
    }, 1000);

    countdownTimers.set(button, timer);
  }

  function withLoading(button, loadingText) {
    if (!button) {
      return () => {};
    }
    const originalHtml = button.innerHTML;
    const originalText = button.textContent;
    const wasDisabled = button.disabled;
    button.disabled = true;
    button.textContent = loadingText;

    return function restore() {
      if (countdownTimers.has(button)) {
        return;
      }
      button.disabled = wasDisabled;
      if (originalHtml && originalHtml !== originalText) {
        button.innerHTML = originalHtml;
      } else {
        button.textContent = originalText;
      }
    };
  }

  /* ── Modals ── */
  const backdrop = document.getElementById('modalBackdrop');

  function openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.add('open');
    backdrop && backdrop.classList.add('open');
    document.body.style.overflow = 'hidden';
    const firstField = modal.querySelector('input:not([type=hidden]), textarea, button:not(.modal-close)');
    firstField && window.requestAnimationFrame(() => firstField.focus());
  }

  function closeModal(id) {
    const modal = id ? document.getElementById(id) : null;
    if (modal) {
      modal.classList.remove('open');
    } else {
      $$('.modal').forEach(node => node.classList.remove('open'));
    }

    if (!$('.modal.open')) {
      backdrop && backdrop.classList.remove('open');
      document.body.style.overflow = '';
    }
  }

  on(backdrop, 'click', () => {
    closeModal();
    $('#notifPanel')?.classList.remove('open');
  });

  $$('[data-close]').forEach(btn => {
    on(btn, 'click', () => closeModal(btn.dataset.close));
  });

  ['loginBtn', 'loginBtn2', 'loginBtn3', 'loginToReplyBtn'].forEach(id => {

    on(document.getElementById(id), 'click', () => {
      clearModalMessages();
      openModal('loginModal');
    });
  });

  on(document.getElementById('signupBtn'), 'click', () => {
    clearModalMessages();
    openModal('registerModal');
  });

  on(document.getElementById('switchToRegister'), 'click', (e) => {
    e.preventDefault();
    clearModalMessages();
    closeModal('loginModal');
    openModal('registerModal');
  });

  on(document.getElementById('switchToLogin'), 'click', (e) => {
    e.preventDefault();
    clearModalMessages();
    closeModal('registerModal');
    openModal('loginModal');
  });

  on(document.getElementById('switchToLoginFromForgot'), 'click', (e) => {
    e.preventDefault();
    clearModalMessages();
    closeModal('forgotPasswordModal');
    openModal('loginModal');
  });

  const forgotPasswordBtn = document.getElementById('forgotPasswordBtn');
  on(forgotPasswordBtn, 'click', (e) => {
    if (forgotPasswordBtn?.getAttribute('aria-disabled') === 'true' || !SMTP_ENABLED) {
      e.preventDefault();
      showMessage(document.getElementById('loginError'), SMTP_UNAVAILABLE_MESSAGE);
      return;
    }
    clearModalMessages();
    closeModal('loginModal');
    openModal('forgotPasswordModal');
  });

  const registerCodeGroup = document.getElementById('registerCodeGroup');
  const sendRegisterCodeBtn = document.getElementById('sendRegisterCodeBtn');
  const sendResetCodeBtn = document.getElementById('sendResetCodeBtn');

  if (registerCodeGroup) {
    registerCodeGroup.classList.toggle('hidden', !SMTP_ENABLED);
  }
  if (!SMTP_ENABLED && sendResetCodeBtn) {
    sendResetCodeBtn.disabled = true;
    sendResetCodeBtn.textContent = '未启用';
  }

  /* ── Login Form ── */
  on(document.getElementById('loginForm'), 'submit', async function (e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(this));
    const errorEl = document.getElementById('loginError');
    hideMessage(errorEl);

    try {
      const { payload } = await requestJson('/login', data);
      if (payload.redirect) {
        location.href = payload.redirect;
        return;
      }

      const messages = collectMessages(payload);
      showMessage(errorEl, messages[0] || '登录失败，请检查输入后重试');
    } catch (_) {
      showMessage(errorEl, '网络错误，请稍后重试');
    }
  });

  /* ── Register Form ── */
  on(sendRegisterCodeBtn, 'click', async () => {
    const registerForm = document.getElementById('registerForm');
    const errorEl = document.getElementById('registerError');
    const successEl = document.getElementById('registerSuccess');
    hideMessage(errorEl);
    hideMessage(successEl);

    if (!SMTP_ENABLED) {
      showMessage(errorEl, SMTP_UNAVAILABLE_MESSAGE);
      return;
    }

    const email = registerForm?.querySelector('[name=email]')?.value.trim() || '';
    const username = registerForm?.querySelector('[name=username]')?.value.trim() || '';

    if (!email) {
      showMessage(errorEl, '请先填写邮箱地址');
      registerForm?.querySelector('[name=email]')?.focus();
      return;
    }

    const restore = withLoading(sendRegisterCodeBtn, '发送中...');

    try {
      const { response, payload } = await requestJson('/register/code', {
        username,
        email,
        _token: getCsrf(),
      });

      if (response.ok && payload.success) {
        showMessage(successEl, payload.message || '验证码已发送，请检查邮箱');
        startCountdown(sendRegisterCodeBtn, 60, '重新发送');
        return;
      }

      const messages = collectMessages(payload);
      showMessage(errorEl, messages[0] || '验证码发送失败，请稍后重试');
      restore();
    } catch (_) {
      showMessage(errorEl, '网络错误，请稍后重试');
      restore();
    }
  });

  on(document.getElementById('registerForm'), 'submit', async function (e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(this));
    const errorEl = document.getElementById('registerError');
    const successEl = document.getElementById('registerSuccess');
    hideMessage(errorEl);
    hideMessage(successEl);

    if (!SMTP_ENABLED) {
      delete data.email_code;
    }

    try {
      const { response, payload } = await requestJson('/register', data);
      if (payload.redirect) {
        showMessage(successEl, payload.message || '注册成功，正在跳转...');
        location.href = payload.redirect;
        return;
      }

      const messages = collectMessages(payload);
      showMessage(errorEl, messages[0] || (!response.ok ? '注册失败，请稍后重试' : '注册失败，请检查输入信息'));
    } catch (_) {
      showMessage(errorEl, '网络错误，请稍后重试');
    }
  });

  /* ── Forgot Password Form ── */
  on(sendResetCodeBtn, 'click', async () => {
    const form = document.getElementById('forgotPasswordForm');
    const errorEl = document.getElementById('forgotPasswordError');
    const successEl = document.getElementById('forgotPasswordSuccess');
    hideMessage(errorEl);
    hideMessage(successEl);

    if (!SMTP_ENABLED) {
      showMessage(errorEl, SMTP_UNAVAILABLE_MESSAGE);
      return;
    }

    const email = form?.querySelector('[name=email]')?.value.trim() || '';
    if (!email) {
      showMessage(errorEl, '请先填写注册邮箱');
      form?.querySelector('[name=email]')?.focus();
      return;
    }

    const restore = withLoading(sendResetCodeBtn, '发送中...');

    try {
      const { response, payload } = await requestJson('/password/forgot/code', {
        email,
        _token: getCsrf(),
      });

      if (response.ok && payload.success) {
        showMessage(successEl, payload.message || '重置验证码已发送，请检查邮箱');
        startCountdown(sendResetCodeBtn, 60, '重新发送');
        return;
      }

      const messages = collectMessages(payload);
      showMessage(errorEl, messages[0] || '验证码发送失败，请稍后重试');
      restore();
    } catch (_) {
      showMessage(errorEl, '网络错误，请稍后重试');
      restore();
    }
  });

  on(document.getElementById('forgotPasswordForm'), 'submit', async function (e) {
    e.preventDefault();
    const errorEl = document.getElementById('forgotPasswordError');
    const successEl = document.getElementById('forgotPasswordSuccess');
    hideMessage(errorEl);
    hideMessage(successEl);

    if (!SMTP_ENABLED) {
      showMessage(errorEl, SMTP_UNAVAILABLE_MESSAGE);
      return;
    }

    const data = Object.fromEntries(new FormData(this));
    try {
      const { response, payload } = await requestJson('/password/reset', data);
      if (response.ok && payload.success) {
        showMessage(successEl, payload.message || '密码已重置，请重新登录');
        this.reset();
        setTimeout(() => {
          hideMessage(successEl);
          closeModal('forgotPasswordModal');
          openModal('loginModal');
        }, 1200);
        return;
      }

      const messages = collectMessages(payload);
      showMessage(errorEl, messages[0] || '密码重置失败，请稍后重试');
    } catch (_) {
      showMessage(errorEl, '网络错误，请稍后重试');
    }
  });

  /* ── User Dropdown ── */
  const userMenuBtn = document.getElementById('userMenuBtn');
  const userDropdown = document.getElementById('userDropdown');
  on(userMenuBtn, 'click', (e) => {
    e.stopPropagation();
    userDropdown && userDropdown.classList.toggle('open');
  });
  document.addEventListener('click', () => userDropdown && userDropdown.classList.remove('open'));

  /* ── Notification Panel ── */
  const notifBtn = document.getElementById('notifBtn');
  const notifPanel = document.getElementById('notifPanel');
  const notifBadge = document.getElementById('notifBadge');
  const notifList = document.getElementById('notifList');

  if (notifBtn) {
    on(notifBtn, 'click', async (e) => {
      e.stopPropagation();
      if (notifPanel.classList.toggle('open')) {
        try {
          const res = await fetch(url('/notifications'), { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
          const json = await res.json();
          renderNotifications(json.notifications || []);
          if (notifBadge) notifBadge.style.display = 'none';
        } catch (_) {}
      }
    });

    async function pollNotifCount() {
      try {
        const res = await fetch(url('/notifications/count'), { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        const json = await res.json();
        const count = json.count || 0;
        if (!notifBadge) return;
        if (count > 0) {
          notifBadge.style.display = 'flex';
          notifBadge.textContent = count > 99 ? '99+' : count;
        } else {
          notifBadge.style.display = 'none';
        }
      } catch (_) {}
    }

    pollNotifCount();
    setInterval(pollNotifCount, 30000);
  }

  function renderNotifications(notifications) {
    if (!notifList) return;
    if (!notifications.length) {
      notifList.innerHTML = '<div class="notif-empty">暂无通知</div>';
      return;
    }

    notifList.innerHTML = notifications.map(n => {
      let data = n.data || {};
      if (typeof data === 'string') {
        try {
          data = JSON.parse(data);
        } catch (_) {
          data = {};
        }
      }

      const discussionTitle = data.discussion_title || '';
      let text = '';
      if (n.type === 'new_reply') {
        text = `<strong>${n.from_username || '有人'}</strong> 回复了你的讨论：${discussionTitle}`;
      } else if (n.type === 'quoted_reply') {
        const quotedFloor = Number(data.quoted_post_number || 0) > 0 ? `（#${Number(data.quoted_post_number)}）` : '';
        text = `<strong>${data.quoted_by || n.from_username || '有人'}</strong> 引用了你的回复${quotedFloor}${discussionTitle ? `：${discussionTitle}` : ''}`;
      } else if (n.type === 'mention') {
        text = `<strong>${data.mentioned_by || '有人'}</strong> 在讨论中提到了你${discussionTitle ? `：${discussionTitle}` : ''}`;
      } else {
        text = '你有一条新通知';
      }

      const discussionLink = data.discussion_id ? url('/d/' + data.discussion_id) : '#';
      const link = data.post_id ? `${discussionLink}#post-${data.post_id}` : discussionLink;
      return `<a href="${link}" class="notif-item ${n.is_read ? '' : 'unread'}">
        <div class="notif-content">
          <div>${text}</div>
          <div class="notif-time">${n.created_at || ''}</div>
        </div>
      </a>`;
    }).join('');
  }

  on(document.getElementById('markAllRead'), 'click', async () => {
    try {
      await fetch(url('/notifications'), { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
    } catch (_) {}
    $$('.notif-item.unread').forEach(el => el.classList.remove('unread'));
    if (notifBadge) notifBadge.style.display = 'none';
  });

  /* ── Sidebar Toggle (mobile) ── */
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  on(sidebarToggle, 'click', (e) => {
    e.stopPropagation();
    sidebar && sidebar.classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    if (sidebar && !sidebar.contains(e.target) && e.target !== sidebarToggle) {
      sidebar.classList.remove('open');
    }
  });

  /* ── Search interactions ── */
  $$('form[data-search-launcher="global"]').forEach(form => {
    on(form, 'submit', (e) => {
      e.preventDefault();
      const query = form.querySelector('input[name="q"]')?.value || '';
      navigateToSearch(query);
    });
  });

  /* ── Keyboard shortcuts ── */
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const hadOverlayOpen = Boolean($('.modal.open') || $('#notifPanel.open') || $('#userDropdown.open'));
      closeModal();
      $('#notifPanel')?.classList.remove('open');
      $('#userDropdown')?.classList.remove('open');

      if (hadOverlayOpen) {
        return;
      }

      const searchPage = getSearchPage();
      if (searchPage) {
        location.href = searchPage.dataset.homeUrl || getHomeUrl();
      }
      return;
    }


    if (e.key === '/' && !e.ctrlKey && !e.metaKey && !e.altKey && !isTypingField(e.target)) {
      e.preventDefault();
      getPrimarySearchInput()?.focus();
      getPrimarySearchInput()?.select();
      return;
    }

    if (e.key === 'Enter' && e.target instanceof HTMLInputElement && e.target.form?.matches('form[data-search-launcher="global"]')) {
      e.preventDefault();
      navigateToSearch(e.target.value || '');
    }
  });


  /* ── Auto resize textarea ── */
  $$('textarea.reply-textarea, textarea.main-editor').forEach(ta => {
    ta.addEventListener('input', function () {
      this.style.height = 'auto';
      this.style.height = Math.max(this.scrollHeight, 100) + 'px';
    });
  });

  /* ── Time formatting ── */
  function timeAgo(dateStr) {
    const diff = (Date.now() - new Date(dateStr)) / 1000;
    if (diff < 60) return '刚刚';
    if (diff < 3600) return Math.floor(diff / 60) + ' 分钟前';
    if (diff < 86400) return Math.floor(diff / 3600) + ' 小时前';
    if (diff < 2592000) return Math.floor(diff / 86400) + ' 天前';
    return new Date(dateStr).toLocaleDateString('zh-CN');
  }

  $$('.post-time[title], .di-time[title]').forEach(el => {
    if (el.title) el.textContent = timeAgo(el.title);
  });

  /* ── Smooth anchor ── */
  document.querySelectorAll('a[href^="#post-"]').forEach(a => {
    a.addEventListener('click', function (e) {
      const target = document.getElementById(this.getAttribute('href').slice(1));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        target.style.transition = 'background .5s';
        target.style.background = 'var(--primary-light)';
        setTimeout(() => { target.style.background = ''; }, 1500);
      }
    });
  });

  console.log('%c🗨️ Chitchat Forum', 'color:#0077cc;font-size:14px;font-weight:bold;');
})();
