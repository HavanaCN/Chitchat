</div><!-- .app-wrapper -->

<footer class="app-footer">
  <div class="footer-inner">
    <div>
      Powered by <a href="https://github.com/HavanaCN/Chitchat" target="_blank" rel="noopener noreferrer">Chitchat</a> <?= htmlspecialchars($appVersion['tag'] ?? 'v0.0.0-dev') ?> &nbsp;·&nbsp;

      <?= htmlspecialchars($forum['forum_name'] ?? 'Chitchat') ?>
    </div>

    <?php if (!empty($forum['icp_filing'])): ?>
    <div class="footer-icp">
      <a href="https://beian.miit.gov.cn/" target="_blank" rel="noopener noreferrer"><?= htmlspecialchars($forum['icp_filing']) ?></a>
    </div>
    <?php endif; ?>
  </div>
</footer>

<script src="<?= ($view ?? $this)->asset('js/app.js') ?>"></script>
</body>
</html>

