<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $pageTitle ?? '管理后台' ?> - <?= htmlspecialchars($forum['forum_name'] ?? 'Chitchat') ?></title>
<meta name="chitchat-base-url" content="<?= htmlspecialchars($basePath ?? '', ENT_QUOTES, 'UTF-8') ?>">
<meta name="csrf-token" content="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">
<script>
window.CHITCHAT_BASE_URL = <?= json_encode($basePath ?? '', JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
window.CHITCHAT_ROUTE_BASE = <?= json_encode(\App\Helpers\Url::entryScript(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
window.chitchatUrl = function(path) {
  if (!path) return window.CHITCHAT_BASE_URL || '/';
  if (/^(?:[a-z][a-z0-9+.-]*:)?\/\//i.test(path) || path.startsWith('#') || path.startsWith('mailto:') || path.startsWith('javascript:')) {
    return path;
  }
  return (window.CHITCHAT_BASE_URL || '') + (path.startsWith('/') ? path : '/' + path);
};
window.chitchatRoute = function(path, query) {
  var url = window.CHITCHAT_ROUTE_BASE || '/index.php';
  var normalized = typeof path === 'string' ? path.trim() : '';
  var params = new URLSearchParams(query || {});
  if (normalized && normalized !== '/') {
    params.set('route', normalized.replace(/^\/+/, ''));
  }
  var queryString = params.toString();
  return queryString ? url + '?' + queryString : url;
};
</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= ($view ?? $this)->asset('css/admin.css') ?>">
</head>
<body class="admin-layout">

<aside class="admin-sidebar">
  <div class="admin-brand">
    <a href="<?= \App\Helpers\Url::route() ?>" class="admin-logo">
      <?= \App\Helpers\ForumIcon::render($forum, 'admin-brand-icon') ?>
      <span><?= htmlspecialchars($forum['forum_name'] ?? 'Chitchat') ?></span>
    </a>
    <a href="<?= \App\Helpers\Url::route() ?>" class="view-site"><i class="fa fa-external-link"></i> 查看论坛</a>
  </div>

  <nav class="admin-nav">
    <a href="<?= \App\Helpers\Url::route('admin') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'dashboard' ? 'active' : '' ?>">
      <i class="fa fa-chart-bar"></i> 仪表盘
    </a>
    <a href="<?= \App\Helpers\Url::route('admin/users') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'users' ? 'active' : '' ?>">
      <i class="fa fa-users"></i> 用户管理
    </a>
    <a href="<?= \App\Helpers\Url::route('admin/groups') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'groups' ? 'active' : '' ?>">
      <i class="fa fa-user-shield"></i> 用户组权限
    </a>
    <a href="<?= \App\Helpers\Url::route('admin/tags') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'tags' ? 'active' : '' ?>">
      <i class="fa fa-tags"></i> 分类管理
    </a>
    <a href="<?= \App\Helpers\Url::route('admin/mail') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'mail' ? 'active' : '' ?>">
      <i class="fa fa-envelope"></i> 邮件服务
    </a>
    <a href="<?= \App\Helpers\Url::route('admin/plugins') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'plugins' ? 'active' : '' ?>">
      <i class="fa fa-puzzle-piece"></i> 插件管理
    </a>
    <a href="<?= \App\Helpers\Url::route('admin/themes') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'themes' ? 'active' : '' ?>">
      <i class="fa fa-palette"></i> 主题模板
    </a>
    <a href="<?= \App\Helpers\Url::route('admin/settings') ?>" class="admin-nav-item <?= ($activePage ?? '') === 'settings' ? 'active' : '' ?>">
      <i class="fa fa-cog"></i> 论坛设置
    </a>
  </nav>
</aside>

<div class="admin-main">
  <header class="admin-topbar">
    <h1><?= $pageTitle ?? '管理后台' ?></h1>
    <div class="admin-topbar-right">
      <span class="admin-user">
        <img src="<?= \App\Forum\Models\User::getAvatarUrl($currentUser, 28) ?>" class="avatar-28">
        <?= htmlspecialchars($currentUser['username'] ?? '') ?>
      </span>
    </div>
  </header>
  <div class="admin-content">
