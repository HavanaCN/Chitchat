<?php
$smtpEnabled = \App\Helpers\Settings::isSmtpEnabled($forum ?? []);
$smtpUnavailableMessage = '当前站点的邮件服务尚未启用或还没通过 SMTP 测试验证，暂不支持验证码与密码找回，请联系站点管理员。';

$canEnterAdmin = $currentUser
    && (\App\Helpers\GroupPermission::has($currentUser['group_permissions'] ?? null, 'admin')
        || (int)($currentUser['group_id'] ?? 0) === 1);
?>
<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle ?? ($forum['forum_name'] ?? 'Chitchat')) ?></title>
<meta name="description" content="<?= htmlspecialchars($forum['forum_description'] ?? '') ?>">
<meta name="chitchat-base-url" content="<?= htmlspecialchars($basePath ?? '', ENT_QUOTES, 'UTF-8') ?>">
<meta name="csrf-token" content="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">
<script>
window.CHITCHAT_BASE_URL = <?= json_encode($basePath ?? '', JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
window.CHITCHAT_ROUTE_BASE = <?= json_encode(\App\Helpers\Url::entryScript(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
window.CHITCHAT_SMTP_ENABLED = <?= $smtpEnabled ? 'true' : 'false' ?>;
window.CHITCHAT_SMTP_UNAVAILABLE_MESSAGE = <?= json_encode($smtpUnavailableMessage, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
window.chitchatUrl = function(path) {
  if (!path) return window.CHITCHAT_BASE_URL || '/';
  if (/^(?:[a-z][a-z0-9+.-]*:)?\/\//i.test(path) || path.startsWith('#') || path.startsWith('mailto:') || path.startsWith('javascript:')) {
    return path;
  }
  return (window.CHITCHAT_BASE_URL || '') + (path.startsWith('/') ? path : '/' + path);
};
window.chitchatRoute = function(path, query) {
  var url = window.CHITCHAT_ROUTE_BASE || '/index.php';
  var normalized = typeof path === 'string' ? path.trim() : '';
  var params = new URLSearchParams(query || {});
  if (normalized && normalized !== '/') {
    params.set('route', normalized.replace(/^\/+/, ''));
  }
  var queryString = params.toString();
  return queryString ? url + '?' + queryString : url;
};
</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= ($view ?? $this)->asset('css/app.css') ?>">

<?php if (!empty($forum['custom_css'])): ?>
<style><?= $forum['custom_css'] ?></style>
<?php endif; ?>
</head>
<body class="chitchat-app">

<!-- Global modals backdrop -->
<div class="modal-backdrop" id="modalBackdrop"></div>

<!-- Header -->
<header class="app-header" id="appHeader">
  <div class="header-inner">
    <div class="header-left">
      <button class="hamburger" id="sidebarToggle" aria-label="菜单">
        <span></span><span></span><span></span>
      </button>
      <a href="<?= \App\Helpers\Url::route() ?>" class="forum-logo">
        <?= \App\Helpers\ForumIcon::render($forum, 'forum-brand-icon') ?>
        <span class="forum-name"><?= htmlspecialchars($forum['forum_name'] ?? 'Chitchat') ?></span>
      </a>
    </div>

    <div class="header-center">
      <div class="search-bar">
        <form action="<?= \App\Helpers\Url::route('search') ?>" method="get" class="header-search-form" data-search-launcher="global">
          <input type="search" name="q" placeholder="搜标题、正文或作者，回车进入搜索页" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" aria-label="搜索讨论" enterkeyhint="search" autocomplete="off">
          <button type="submit" class="search-submit" aria-label="搜索讨论">
            <i class="fa fa-search"></i>
          </button>
          <span class="search-shortcut" aria-hidden="true">/</span>
        </form>
      </div>
    </div>

    <div class="header-right">
      <?php if ($currentUser): ?>
      <button class="icon-btn notification-btn" id="notifBtn" title="通知">
        <i class="fa fa-bell"></i>
        <span class="notif-badge" id="notifBadge" style="display:none">0</span>
      </button>
      <div class="user-menu" id="userMenu">
        <button class="avatar-btn" id="userMenuBtn">
          <img src="<?= \App\Forum\Models\User::getAvatarUrl($currentUser, 36) ?>"
               alt="<?= htmlspecialchars($currentUser['username']) ?>"
               class="user-avatar-sm"
               width="36"
               height="36">
          <span class="username-label"><?= htmlspecialchars($currentUser['username']) ?></span>
          <i class="fa fa-chevron-down"></i>
        </button>

        <div class="dropdown-menu" id="userDropdown">
          <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($currentUser['username'])) ?>" class="dropdown-item">
            <i class="fa fa-user"></i> 个人主页
          </a>
          <a href="<?= \App\Helpers\Url::route('settings') ?>" class="dropdown-item">
            <i class="fa fa-cog"></i> 账号设置
          </a>
          <?php if ($canEnterAdmin): ?>
          <div class="dropdown-divider"></div>
          <a href="<?= \App\Helpers\Url::route('admin') ?>" class="dropdown-item">
            <i class="fa fa-shield-halved"></i> 管理后台
          </a>
          <?php endif; ?>
          <div class="dropdown-divider"></div>
          <form action="<?= \App\Helpers\Url::route('logout') ?>" method="post" style="margin:0">
            <input type="hidden" name="_token" value="<?= $csrfToken ?>">
            <button type="submit" class="dropdown-item btn-logout">
              <i class="fa fa-sign-out-alt"></i> 退出登录
            </button>
          </form>
        </div>
      </div>
      <?php else: ?>
      <button class="btn btn-ghost" id="loginBtn">登录</button>
      <button class="btn btn-primary" id="signupBtn">注册</button>
      <?php endif; ?>
    </div>
  </div>
</header>

<!-- Notification panel -->
<div class="notif-panel" id="notifPanel">
  <div class="notif-panel-header">
    <span>通知</span>
    <button class="notif-mark-read" id="markAllRead">全部已读</button>
  </div>
  <div class="notif-list" id="notifList">
    <div class="notif-empty">暂无新通知</div>
  </div>
</div>

<!-- Login Modal -->
<div class="modal" id="loginModal">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>登录 <?= htmlspecialchars($forum['forum_name'] ?? 'Chitchat') ?></h3>
      <button class="modal-close" data-close="loginModal"><i class="fa fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="auth-error" id="loginError" style="display:none"></div>
      <form id="loginForm">
        <input type="hidden" name="_token" value="<?= $csrfToken ?>">
        <div class="form-group">
          <label>用户名 / 邮箱地址</label>
          <input type="text" name="login" placeholder="用户名或 your@email.com" required autocomplete="username">
        </div>
        <div class="form-group">
          <label>密码</label>
          <input type="password" name="password" placeholder="••••••••" required autocomplete="current-password">
        </div>

        <div class="auth-actions">
          <div class="form-check auth-remember">
            <label><input type="checkbox" name="remember"> 记住我</label>
          </div>
          <button
            type="button"
            class="auth-link-btn <?= !$smtpEnabled ? 'is-disabled tooltip-trigger' : '' ?>"
            id="forgotPasswordBtn"
            <?= !$smtpEnabled ? 'aria-disabled="true" data-tooltip="' . htmlspecialchars($smtpUnavailableMessage, ENT_QUOTES, 'UTF-8') . '" title="' . htmlspecialchars($smtpUnavailableMessage, ENT_QUOTES, 'UTF-8') . '"' : '' ?>
          >
            忘记密码？
          </button>
        </div>

        <button type="submit" class="btn btn-primary btn-block">登录</button>
      </form>
      <div class="auth-switch">
        还没有账号？<a href="#" id="switchToRegister">立即注册</a>
      </div>
    </div>
  </div>
</div>

<!-- Register Modal -->
<div class="modal" id="registerModal">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>加入 <?= htmlspecialchars($forum['forum_name'] ?? 'Chitchat') ?></h3>
      <button class="modal-close" data-close="registerModal"><i class="fa fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="auth-success" id="registerSuccess" style="display:none"></div>
      <div class="auth-error" id="registerError" style="display:none"></div>
      <form id="registerForm">
        <input type="hidden" name="_token" value="<?= $csrfToken ?>">
        <div class="form-group">
          <label>用户名</label>
          <input type="text" name="username" placeholder="3-30位字符，不能是邮箱" required autocomplete="username">
        </div>

        <div class="form-group">
          <label>邮箱地址</label>
          <input type="email" name="email" placeholder="your@email.com" required autocomplete="email">
        </div>

        <div class="form-group <?= $smtpEnabled ? '' : 'hidden' ?>" id="registerCodeGroup">
          <label>邮箱验证码</label>
          <div class="auth-inline-row">
            <input type="text" name="email_code" id="registerEmailCode" placeholder="请输入 6 位验证码" inputmode="numeric" maxlength="6" autocomplete="one-time-code">
            <button type="button" class="btn btn-ghost auth-code-btn" id="sendRegisterCodeBtn">发送验证码</button>
          </div>
          <div class="help-text" id="registerCodeHint"><?= $smtpEnabled ? '站点已启用邮件服务，注册前请先完成邮箱验证。' : '当前站点未启用邮件服务，可直接完成注册。' ?></div>
        </div>

        <div class="form-group">
          <label>密码</label>
          <input type="password" name="password" placeholder="至少6位" required autocomplete="new-password">
        </div>
        <button type="submit" class="btn btn-primary btn-block">创建账号</button>
      </form>
      <div class="auth-switch">
        已有账号？<a href="#" id="switchToLogin">立即登录</a>
      </div>
    </div>
  </div>
</div>

<!-- Forgot Password Modal -->
<div class="modal" id="forgotPasswordModal">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>重置登录密码</h3>
      <button class="modal-close" data-close="forgotPasswordModal"><i class="fa fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="auth-success" id="forgotPasswordSuccess" style="display:none"></div>
      <div class="auth-error" id="forgotPasswordError" style="display:none"></div>
      <form id="forgotPasswordForm">
        <input type="hidden" name="_token" value="<?= $csrfToken ?>">
        <div class="form-group">
          <label>注册邮箱</label>
          <input type="email" name="email" placeholder="请输入注册时使用的邮箱" required autocomplete="email">
        </div>
        <div class="form-group">
          <label>邮箱验证码</label>
          <div class="auth-inline-row">
            <input type="text" name="code" placeholder="请输入 6 位验证码" inputmode="numeric" maxlength="6" required autocomplete="one-time-code">
            <button type="button" class="btn btn-ghost auth-code-btn" id="sendResetCodeBtn">发送验证码</button>
          </div>
          <div class="help-text">验证码将发送到你的注册邮箱，请在收到后尽快完成重置。</div>
        </div>
        <div class="form-group">
          <label>新密码</label>
          <input type="password" name="password" placeholder="至少6位" required autocomplete="new-password">
        </div>
        <div class="form-group">
          <label>确认新密码</label>
          <input type="password" name="password_confirm" placeholder="再次输入新密码" required autocomplete="new-password">
        </div>
        <button type="submit" class="btn btn-primary btn-block">确认重置密码</button>
      </form>
      <div class="auth-switch">
        想起密码了？<a href="#" id="switchToLoginFromForgot">返回登录</a>
      </div>
    </div>
  </div>
</div>

<div class="app-wrapper">
