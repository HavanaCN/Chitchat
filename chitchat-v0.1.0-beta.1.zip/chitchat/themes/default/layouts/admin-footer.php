  </div><!-- admin-content -->
</div><!-- admin-main -->

<footer class="admin-footer" style="padding: 12px 20px; color: #6b7280; font-size: 13px;">
  Powered by <a href="https://github.com/HavanaCN/Chitchat" target="_blank" rel="noopener noreferrer">Chitchat</a> <?= htmlspecialchars($appVersion['tag'] ?? 'v0.0.0-dev') ?>
</footer>

<script src="<?= ($view ?? $this)->asset('js/admin.js') ?>"></script>


</body>
</html>
