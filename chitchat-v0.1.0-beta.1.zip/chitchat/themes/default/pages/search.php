<?php include __DIR__ . '/../layouts/header.php'; ?>
<div class="page-search" data-search-page="true" data-home-url="<?= htmlspecialchars(\App\Helpers\Url::route(), ENT_QUOTES, 'UTF-8') ?>">
  <div class="search-container">
    <div class="search-page-toolbar">
      <a href="<?= \App\Helpers\Url::route() ?>" class="search-back-link">
        <i class="fa fa-arrow-left"></i>
        <span>返回论坛主页</span>
      </a>
      <span class="search-toolbar-tip"><kbd>Esc</kbd> 快速返回主页</span>
    </div>

    <div class="search-hero">
      <form action="<?= \App\Helpers\Url::route('search') ?>" method="get" class="search-form-large" data-search-form="standalone">
        <div class="search-input-wrap">
          <i class="fa fa-search"></i>
          <input type="search" name="q" value="<?= htmlspecialchars($q ?? '') ?>" placeholder="搜索标题、正文、作者，回车进入结果页" autofocus autocomplete="off">
          <button type="submit" class="btn btn-primary">搜索</button>
        </div>

        <div class="search-form-meta">
          <p class="search-form-lead">这里是独立搜索页，你可以持续细化关键词，再按 <kbd>Esc</kbd> 随时返回论坛主页。</p>
        </div>

        <div class="search-form-filters">
          <div class="search-filter-field">
            <label for="search-author">作者</label>
            <input id="search-author" type="text" name="author" value="<?= htmlspecialchars($author ?? '') ?>" placeholder="按用户名筛选">
          </div>
          <div class="search-filter-field">
            <label for="search-tag">分类标签</label>
            <select id="search-tag" name="tag">
              <option value="">全部分类</option>
              <?php searchRenderTagOptions($tags ?? [], $selectedTagSlug ?? null); ?>
            </select>
          </div>
        </div>
      </form>
    </div>

    <?php if (($q ?? '') !== '' || ($author ?? '') !== '' || !empty($selectedTagSlug)): ?>
    <div class="search-results">
      <?php if (empty($results['data'])): ?>
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>未找到相关结果</h3>
        <p>
          当前条件下没有匹配的讨论
          <?php if (!empty($q)): ?>
            （关键词："<?= htmlspecialchars($q) ?>"）
          <?php endif; ?>
        </p>
      </div>
      <?php else: ?>
      <div class="results-header">
        <strong>共找到 <?= number_format($results['total'] ?? 0) ?> 条结果</strong>
        <div class="search-active-filters">
          <?php if (!empty($q)): ?>
          <span class="search-filter-chip">关键词：<?= htmlspecialchars($q) ?></span>
          <?php endif; ?>
          <?php if (!empty($author)): ?>
          <span class="search-filter-chip">作者：<?= htmlspecialchars($author) ?></span>
          <?php endif; ?>
          <?php if (!empty($currentTag)): ?>
          <span class="search-filter-chip">分类：<?= htmlspecialchars($currentTag['name']) ?></span>
          <?php endif; ?>
        </div>
      </div>
      <div class="discussion-list search-discussion-list">
        <?php foreach ($results['data'] as $d): ?>
        <div class="discussion-item <?= !empty($d['is_sticky']) ? 'is-sticky' : '' ?>">
          <div class="di-body" style="padding-left:0">
            <div class="di-title-row">
              <?php if (!empty($d['is_sticky'])): ?>
              <span class="badge badge-sticky"><i class="fa fa-thumbtack"></i> 置顶</span>
              <?php endif; ?>
              <?php if (!empty($d['is_featured'])): ?>
              <span class="badge badge-featured"><i class="fa fa-star"></i> 精品</span>
              <?php endif; ?>
              <?php if (!empty($d['is_locked'])): ?>
              <span class="badge badge-lock"><i class="fa fa-lock"></i> 已锁定</span>
              <?php endif; ?>
              <a href="<?= \App\Helpers\Url::route('d/' . $d['id']) ?>" class="di-title"><?= searchHighlight($d['title'] ?? '', $q ?? '') ?></a>
            </div>

            <?php if (!empty($d['search_excerpt'])): ?>
            <p class="search-snippet">
              <?php if (!empty($d['search_excerpt_source'])): ?>
              <span class="search-hit-source"><?= htmlspecialchars($d['search_excerpt_source']) ?></span>
              <?php endif; ?>
              <?= searchHighlight($d['search_excerpt'], $q ?? '') ?>
            </p>
            <?php endif; ?>

            <div class="di-meta">
              <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($d['username'])) ?>" class="di-author"><?= htmlspecialchars($d['username'] ?? '') ?></a>
              <span class="di-time" title="<?= htmlspecialchars($d['created_at'] ?? '') ?>">
                <?= searchTimeAgo($d['created_at'] ?? null) ?>
              </span>
              <?php if (!empty($d['tags'])): ?>
              <div class="di-tags">
                <?php foreach ($d['tags'] as $tag): ?>
                <a href="<?= \App\Helpers\Url::route('search', ['q' => $q ?: null, 'author' => $author ?: null, 'tag' => $tag['slug']]) ?>" class="di-tag"
                   style="background:<?= htmlspecialchars($tag['color']) ?>20;color:<?= htmlspecialchars($tag['color']) ?>">
                  <?= htmlspecialchars($tag['name']) ?>
                </a>
                <?php endforeach; ?>
              </div>
              <?php endif; ?>
            </div>
          </div>
          <div class="di-stats">
            <div class="di-stat">
              <i class="fa fa-comment"></i>
              <span><?= number_format($d['comment_count'] ?? 0) ?></span>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <?php if (($results['last_page'] ?? 1) > 1): ?>
      <div class="pagination">
        <?php for ($p = 1; $p <= $results['last_page']; $p++): ?>
        <a href="<?= \App\Helpers\Url::route('search', ['q' => $q ?: null, 'author' => $author ?: null, 'tag' => $selectedTagSlug ?: null, 'page' => $p]) ?>"
           class="page-btn <?= $p === ($results['current_page'] ?? 1) ? 'active' : '' ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
      <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="search-empty-guide">
      <div class="empty-state">
        <div class="empty-icon">⌨️</div>
        <h3>开始一次独立搜索</h3>
        <p>在上方输入关键词后回车进入结果页；如果想快速离开搜索，只要按一下 <kbd>Esc</kbd> 就能返回论坛主页。</p>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../layouts/footer.php'; ?>

<?php
function searchTimeAgo(?string $datetime): string
{
    if (!$datetime) return '';
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return '刚刚';
    if ($diff < 3600) return floor($diff / 60) . ' 分钟前';
    if ($diff < 86400) return floor($diff / 3600) . ' 小时前';
    if ($diff < 2592000) return floor($diff / 86400) . ' 天前';
    if ($diff < 31536000) return floor($diff / 2592000) . ' 个月前';
    return floor($diff / 31536000) . ' 年前';
}

function searchHighlight(?string $text, string $keyword): string
{
    $safe = htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
    $tokens = array_values(array_filter(array_unique(preg_split('/\s+/u', trim($keyword)) ?: [])));
    if ($safe === '' || $tokens === []) {
        return $safe;
    }

    usort($tokens, static fn (string $left, string $right): int => mb_strlen($right) <=> mb_strlen($left));
    $pattern = '/' . implode('|', array_map(static fn (string $token): string => preg_quote(htmlspecialchars($token, ENT_QUOTES, 'UTF-8'), '/'), $tokens)) . '/iu';

    return preg_replace($pattern, '<mark>$0</mark>', $safe) ?? $safe;
}

function searchRenderTagOptions(array $tags, ?string $selectedTagSlug = null, int $depth = 0): void
{
    foreach ($tags as $tag) {
        if (\App\Helpers\GroupPermission::isUncategorizedTag($tag)) {
            continue;
        }

        $prefix = str_repeat('— ', $depth);
        $isSelected = $selectedTagSlug === ($tag['slug'] ?? '') ? ' selected' : '';
        echo '<option value="' . htmlspecialchars($tag['slug'] ?? '', ENT_QUOTES, 'UTF-8') . '"' . $isSelected . '>'
            . htmlspecialchars($prefix . ($tag['name'] ?? ''), ENT_QUOTES, 'UTF-8')
            . '</option>';

        if (!empty($tag['children'])) {
            searchRenderTagOptions($tag['children'], $selectedTagSlug, $depth + 1);
        }
    }
}
