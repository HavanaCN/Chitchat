<?php include __DIR__ . '/../layouts/header.php'; ?>
<div class="page-error">
  <div class="error-card">
    <div class="error-code"><?= (int)($code ?? 500) ?></div>
    <h2><?= $code == 404 ? '页面未找到' : ($code == 403 ? '访问被拒绝' : '服务器错误') ?></h2>
    <p class="error-msg"><?= htmlspecialchars($message ?? '发生了未知错误') ?></p>
    <a href="<?= \App\Helpers\Url::route() ?>" class="btn btn-primary"><i class="fa fa-home"></i> 返回首页</a>


  </div>
</div>
<?php include __DIR__ . '/../layouts/footer.php'; ?>
