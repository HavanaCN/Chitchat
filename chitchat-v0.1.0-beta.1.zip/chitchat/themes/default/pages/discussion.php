<?php
if (!function_exists('timeAgo')) {
    function timeAgo(?string $datetime): string {
        if (!$datetime) return '';
        $diff = time() - strtotime($datetime);
        if ($diff < 60) return '刚刚';
        if ($diff < 3600) return floor($diff / 60) . ' 分钟前';
        if ($diff < 86400) return floor($diff / 3600) . ' 小时前';
        if ($diff < 2592000) return floor($diff / 86400) . ' 天前';
        if ($diff < 31536000) return floor($diff / 2592000) . ' 个月前';
        return floor($diff / 31536000) . ' 年前';
    }
}
function parseMarkdown(string $text): string {
    // Basic markdown to HTML
    $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    // Code blocks
    $text = preg_replace('/```(\w*)\n?([\s\S]*?)```/m', '<pre><code class="language-$1">$2</code></pre>', $text);
    // Inline code
    $text = preg_replace('/`([^`]+)`/', '<code>$1</code>', $text);
    // Headers
    $text = preg_replace('/^### (.+)$/m', '<h3>$1</h3>', $text);
    $text = preg_replace('/^## (.+)$/m', '<h2>$1</h2>', $text);
    $text = preg_replace('/^# (.+)$/m', '<h1>$1</h1>', $text);
    // Bold and italic
    $text = preg_replace('/\*\*\*(.+?)\*\*\*/', '<strong><em>$1</em></strong>', $text);
    $text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text);
    $text = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $text);
    // Blockquote
    $text = preg_replace('/^> (.+)$/m', '<blockquote>$1</blockquote>', $text);
    // Images
    $text = preg_replace('/!\[([^\]]*)\]\(([^)]+)\)/', '<img src="$2" alt="$1" class="post-image">', $text);
    // Links
    $text = preg_replace('/\[([^\]]+)\]\(([^)]+)\)/', '<a href="$2" target="_blank" rel="noopener">$1</a>', $text);

    // Horizontal rule
    $text = preg_replace('/^---$/m', '<hr>', $text);
    // @mentions
    $text = preg_replace_callback('/@(\w+)/', function ($matches) {
        $username = $matches[1];
        $url = \App\Helpers\Url::route('u/' . rawurlencode($username));

        return '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" class="mention">@' . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . '</a>';
    }, $text);

    // Line breaks
    $text = nl2br($text);
    return $text;
}
?>
<?php include __DIR__ . '/../layouts/header.php'; ?>

<div class="page-discussion">
  <!-- Back breadcrumb -->
  <div class="breadcrumb">
    <a href="<?= \App\Helpers\Url::route() ?>"><i class="fa fa-chevron-left"></i> 返回讨论列表</a>
  </div>




  <?php
  $canModerateDiscussion = $currentUser && (
      \App\Helpers\GroupPermission::has($currentUser['group_permissions'] ?? null, 'moderate')
      || \App\Helpers\GroupPermission::has($currentUser['group_permissions'] ?? null, 'admin')
      || in_array((int)($currentUser['group_id'] ?? 0), [1, 2], true)
  );
  $authorGroupLabel = trim((string)($discussion['group_display_name'] ?? $discussion['group_name'] ?? ''));
  ?>
  <div class="discussion-layout">
    <!-- Main discussion area -->
    <article class="discussion-main">

      <!-- Discussion header -->
      <div class="discussion-header">
        <h1 class="discussion-title">
          <?php if (!empty($discussion['is_sticky'])): ?>
          <span class="badge badge-sticky"><i class="fa fa-thumbtack"></i></span>
          <?php endif; ?>
          <?php if (!empty($discussion['is_featured'])): ?>
          <span class="badge badge-featured"><i class="fa fa-star"></i> 精品</span>
          <?php endif; ?>
          <?php if (!empty($discussion['is_locked'])): ?>
          <span class="badge badge-lock"><i class="fa fa-lock"></i></span>
          <?php endif; ?>
          <?= htmlspecialchars($discussion['title']) ?>
        </h1>
        <div class="discussion-tags">
          <?php foreach ($tags as $tag): ?>
          <a href="<?= \App\Helpers\Url::route('', ['tag' => $tag['slug']]) ?>" class="di-tag"
             style="background:<?= htmlspecialchars($tag['color']) ?>20;color:<?= htmlspecialchars($tag['color']) ?>">
            <?= htmlspecialchars($tag['name']) ?>
          </a>
          <?php endforeach; ?>
        </div>


        <!-- Admin controls -->
        <?php if ($canModerateDiscussion): ?>
        <div class="discussion-admin-bar">
          <button class="btn-sm btn-ghost" onclick="toggleSticky(<?= $discussion['id'] ?>)">
            <i class="fa fa-thumbtack"></i>
            <?= !empty($discussion['is_sticky']) ? '取消置顶' : '置顶' ?>
          </button>
          <button class="btn-sm btn-ghost" onclick="toggleFeatured(<?= $discussion['id'] ?>)">
            <i class="fa fa-star"></i>
            <?= !empty($discussion['is_featured']) ? '取消加精' : '加精' ?>
          </button>
          <button class="btn-sm btn-ghost" onclick="toggleLock(<?= $discussion['id'] ?>)">
            <i class="fa fa-<?= !empty($discussion['is_locked']) ? 'unlock' : 'lock' ?>"></i>
            <?= !empty($discussion['is_locked']) ? '解锁' : '锁定' ?>
          </button>
          <?php if ((int)$currentUser['id'] === (int)$discussion['user_id'] || $canModerateDiscussion): ?>
          <a href="<?= \App\Helpers\Url::route('d/' . $discussion['id'] . '/edit') ?>" class="btn-sm btn-ghost">
            <i class="fa fa-pen"></i> 编辑
          </a>
          <button class="btn-sm btn-danger-ghost" onclick="deleteDiscussion(<?= $discussion['id'] ?>)">
            <i class="fa fa-trash"></i> 删除
          </button>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Posts -->
      <div class="post-list" id="postList">
        <?php $postNum = ($page - 1) * 20; ?>
        <?php foreach ($posts['data'] as $post): $postNum++; ?>
        <?php $postGroupLabel = trim((string)($post['group_display_name'] ?? $post['group_name'] ?? '')); ?>
        <div class="post-item <?= $postNum === 1 ? 'post-first' : '' ?>" id="post-<?= $post['id'] ?>" data-post-id="<?= $post['id'] ?>">

          <div class="post-avatar">
            <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($post['username'])) ?>">
              <img src="<?= \App\Forum\Models\User::getAvatarUrl(['avatar' => $post['avatar'], 'email' => $post['user_email']], 48) ?>"
                   alt="<?= htmlspecialchars($post['username']) ?>" class="avatar-48">
            </a>
            <div class="post-number">#<?= $post['number'] ?></div>
          </div>
          <div class="post-body">
            <div class="post-meta">
              <div class="post-author-info">
                <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($post['username'])) ?>" class="post-author">
                  <?= htmlspecialchars($post['username']) ?>
                </a>
                <span class="uid-inline">UID #<?= (int)$post['user_id'] ?></span>
                <?php if ($postGroupLabel !== '' && !in_array($postGroupLabel, ['Members', '会员'], true)): ?>
                <span class="user-badge"><?= htmlspecialchars($postGroupLabel) ?></span>
                <?php endif; ?>
              </div>
              <span class="post-time" title="<?= $post['created_at'] ?>">

                <?= timeAgo($post['created_at']) ?>
                <?php if ($post['created_at'] !== $post['updated_at']): ?>
                <span class="edited-badge" title="<?= $post['updated_at'] ?>">已编辑</span>
                <?php endif; ?>
              </span>
            </div>

            <?php if ($post['reply_to']): ?>
            <div class="quote-preview" data-reply-to="<?= $post['reply_to'] ?>">
              <i class="fa fa-reply"></i> 引用了 <a href="#post-<?= $post['reply_to'] ?>">楼层</a>
            </div>
            <?php endif; ?>

            <div class="post-content markdown-body">
              <?= parseMarkdown($post['content']) ?>
            </div>

            <div class="post-actions">
              <button class="action-btn like-btn <?= !empty($post['is_liked']) ? 'liked' : '' ?>"
                      onclick="toggleLike(<?= $post['id'] ?>, this)"
                      <?= !$currentUser ? 'disabled title="请先登录"' : '' ?>>
                <i class="fa fa-heart"></i>
                <span class="like-count"><?= $post['like_count'] ?></span>
              </button>
              <?php if ($currentUser && !$discussion['is_locked']): ?>
              <button class="action-btn reply-quote-btn" onclick='quotePost(<?= $post['id'] ?>, <?= json_encode((string)$post['username'], JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>
                <i class="fa fa-reply"></i> 引用
              </button>
              <?php endif; ?>
              <?php if ($currentUser && ((int)$currentUser['id'] === (int)$post['user_id'] || $canModerateDiscussion)): ?>
              <button class="action-btn edit-post-btn" onclick="editPost(<?= $post['id'] ?>)">
                <i class="fa fa-pen"></i> 编辑
              </button>
              <button class="action-btn delete-post-btn" onclick="deletePost(<?= $post['id'] ?>)">
                <i class="fa fa-trash"></i>
              </button>
              <?php endif; ?>
            </div>

            <!-- Inline edit form -->
            <div class="edit-post-form" id="edit-form-<?= $post['id'] ?>" style="display:none">
              <textarea class="edit-textarea" id="edit-content-<?= $post['id'] ?>"><?= htmlspecialchars($post['content']) ?></textarea>
              <div class="edit-actions">
                <button class="btn btn-primary btn-sm" onclick="submitEditPost(<?= $post['id'] ?>)">保存</button>
                <button class="btn btn-ghost btn-sm" onclick="cancelEditPost(<?= $post['id'] ?>)">取消</button>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Post pagination -->
      <?php if (($posts['last_page'] ?? 1) > 1): ?>
      <div class="pagination">
        <?php for ($p = 1; $p <= $posts['last_page']; $p++): ?>
        <a href="<?= \App\Helpers\Url::route('d/' . $discussion['id'], ['page' => $p]) ?>" class="page-btn <?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>

      <!-- Reply box -->
      <?php if ($currentUser && !$discussion['is_locked']): ?>
      <div class="reply-box" id="replyBox">
        <div class="reply-avatar">
          <img src="<?= \App\Forum\Models\User::getAvatarUrl($currentUser, 40) ?>"
               alt="<?= htmlspecialchars($currentUser['username']) ?>" class="avatar-40">
        </div>
        <div class="reply-editor">
          <div id="quotePreview" style="display:none" class="quote-bar">
            <span id="quoteText"></span>
            <button onclick="clearQuote()"><i class="fa fa-times"></i></button>
          </div>
          <div class="editor-toolbar">
            <button type="button" onclick="insertMd('**', '**')" title="粗体"><i class="fa fa-bold"></i></button>
            <button type="button" onclick="insertMd('*', '*')" title="斜体"><i class="fa fa-italic"></i></button>
            <button type="button" onclick="insertMd('[', '](url)')" title="链接"><i class="fa fa-link"></i></button>
            <button type="button" id="replyImageUploadBtn" title="上传图片"><i class="fa fa-image"></i></button>

            <button type="button" onclick="insertMd('> ', '')" title="引用"><i class="fa fa-quote-left"></i></button>
            <button type="button" onclick="insertMd('`', '`')" title="代码"><i class="fa fa-code"></i></button>
            <button type="button" onclick="togglePreview()" title="预览"><i class="fa fa-eye"></i></button>
          </div>
          <input type="file" id="replyImageUploadInput" accept="image/jpeg,image/png,image/gif,image/webp" hidden>
          <textarea id="replyContent" class="reply-textarea" placeholder="写下你的回复，支持 Markdown..." rows="4"></textarea>

          <div id="replyPreview" class="reply-preview markdown-body" style="display:none"></div>
          <input type="hidden" id="replyTo" value="">
          <div class="reply-footer">
            <span class="reply-hint">支持 Markdown · @用户名 提及 · 图片上传（5MB 内）</span>

            <button class="btn btn-primary" onclick="submitReply()">
              <i class="fa fa-paper-plane"></i> 发布回复
            </button>
          </div>
        </div>
      </div>
      <?php elseif (!$currentUser): ?>
      <div class="login-to-reply">
        <button class="btn btn-primary" id="loginToReplyBtn">登录后参与讨论</button>
      </div>
      <?php elseif ($discussion['is_locked']): ?>
      <div class="locked-notice">
        <i class="fa fa-lock"></i> 该讨论已被锁定，无法继续回复
      </div>
      <?php endif; ?>
    </article>

    <!-- Discussion sidebar info -->
    <aside class="discussion-sidebar">
      <div class="d-info-card">
        <div class="d-info-author">
          <img src="<?= \App\Forum\Models\User::getAvatarUrl(['avatar' => $discussion['avatar'], 'email' => $discussion['user_email']], 56) ?>"
               alt="<?= htmlspecialchars($discussion['username']) ?>" class="avatar-56">
          <div>
            <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($discussion['username'])) ?>" class="d-info-name">
              <?= htmlspecialchars($discussion['username']) ?>
            </a>
            <div class="d-info-meta">
              <span class="uid-badge">UID #<?= (int)$discussion['user_id'] ?></span>
              <?php if ($authorGroupLabel !== '' && !in_array($authorGroupLabel, ['Members', '会员'], true)): ?>
              <span class="user-badge"><?= htmlspecialchars($authorGroupLabel) ?></span>
              <?php endif; ?>
            </div>
            <div class="d-info-joined">加入于 <?= date('Y年m月', strtotime($discussion['user_joined'] ?? $discussion['created_at'])) ?></div>
          </div>
        </div>

        <div class="d-info-stats">
          <div class="d-stat">
            <span class="d-stat-val"><?= number_format($discussion['comment_count']) ?></span>
            <span class="d-stat-lbl">回复</span>
          </div>
          <div class="d-stat d-stat-date">
            <span class="d-stat-val"><?= date('m/d', strtotime($discussion['created_at'])) ?></span>
            <span class="d-stat-sub"><?= date('Y年', strtotime($discussion['created_at'])) ?></span>
            <span class="d-stat-lbl">发帖日期</span>
          </div>

        </div>
      </div>
    </aside>
  </div>
</div>

<script>
const DISCUSSION_ID = <?= $discussion['id'] ?>;
const CSRF_TOKEN = '<?= $csrfToken ?>';
const IS_LOCKED = <?= $discussion['is_locked'] ? 'true' : 'false' ?>;
const replyContent = document.getElementById('replyContent');
const replyImageUploadBtn = document.getElementById('replyImageUploadBtn');
const replyImageUploadInput = document.getElementById('replyImageUploadInput');

function submitReply() {
  const content = replyContent.value.trim();
  const replyTo = document.getElementById('replyTo').value || null;
  if (!content) { alert('请输入回复内容'); return; }

  fetch(window.chitchatRoute('/d/' + DISCUSSION_ID + '/posts'), {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': CSRF_TOKEN},
    body: JSON.stringify({content, reply_to: replyTo ? parseInt(replyTo) : null, _token: CSRF_TOKEN})
  }).then(r => r.json()).then(data => {

    if (data.post) {
      appendPost(data.post);
      replyContent.value = '';
      clearQuote();
    } else if (data.error) {
      alert(data.error);
    } else if (data.errors) {
      alert(Object.values(data.errors).flat().join(', '));
    }
  }).catch(() => {
    alert('回复失败，请稍后重试');
  });
}

if (replyImageUploadBtn && replyImageUploadInput) {
  replyImageUploadBtn.addEventListener('click', () => {
    replyImageUploadInput.click();
  });

  replyImageUploadInput.addEventListener('change', async function() {
    const file = this.files[0];
    if (!file) return;

    const originalHtml = replyImageUploadBtn.innerHTML;
    replyImageUploadBtn.disabled = true;
    replyImageUploadBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';

    try {
      const formData = new FormData();
      formData.append('_token', CSRF_TOKEN);
      formData.append('image', file);

      const response = await fetch(window.chitchatRoute('/uploads/editor-image'), {
        method: 'POST',
        headers: {'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': CSRF_TOKEN},
        body: formData,
      });

      const result = await response.json();
      if (!response.ok || result.error || !result.markdown) {
        alert(result.error || '图片上传失败，请稍后重试');
        return;
      }

      insertTextAtCursor(replyContent, result.markdown + '\n');
    } catch (error) {
      alert('图片上传失败，请稍后重试');
    } finally {
      replyImageUploadBtn.disabled = false;
      replyImageUploadBtn.innerHTML = originalHtml;
      this.value = '';
    }
  });
}

function appendPost(post) {
  const avatarUrl = post.user_email
    ? `https://www.gravatar.com/avatar/${md5(post.user_email)}?s=48&d=identicon`
    : window.chitchatUrl('/themes/default/assets/images/default-avatar.png');
  const userUrl = window.chitchatRoute('/u/' + encodeURIComponent(post.username));
  const uploadedAvatarUrl = post.avatar ? window.chitchatUrl('/uploads/avatars/' + encodeURIComponent(post.avatar)) : avatarUrl;
  const groupLabel = String(post.group_display_name || post.group_name || '').trim();
  const showGroupBadge = groupLabel && !['Members', '会员'].includes(groupLabel);
  const html = `
    <div class="post-item" id="post-${post.id}" data-post-id="${post.id}">
      <div class="post-avatar">
        <a href="${userUrl}">
          <img src="${uploadedAvatarUrl}" class="avatar-48">
        </a>
        <div class="post-number">#${post.number}</div>
      </div>
      <div class="post-body">
        <div class="post-meta">
          <div class="post-author-info">
            <a href="${userUrl}" class="post-author">${escHtml(post.username)}</a>
            <span class="uid-inline">UID #${Number(post.user_id || 0)}</span>
            ${showGroupBadge ? `<span class="user-badge">${escHtml(groupLabel)}</span>` : ''}
          </div>
          <span class="post-time">刚刚</span>
        </div>

        ${post.reply_to ? `<div class="quote-preview" data-reply-to="${post.reply_to}"><i class="fa fa-reply"></i> 引用了 <a href="#post-${post.reply_to}">楼层</a></div>` : ''}
        <div class="post-content markdown-body">${renderMarkdown(post.content)}</div>
        <div class="post-actions">
          <button class="action-btn like-btn" onclick="toggleLike(${post.id}, this)">
            <i class="fa fa-heart"></i> <span class="like-count">0</span>
          </button>
          <button class="action-btn reply-quote-btn" onclick='quotePost(${post.id}, ${JSON.stringify(String(post.username || ''))})'>
            <i class="fa fa-reply"></i> 引用
          </button>
          <button class="action-btn edit-post-btn" onclick="editPost(${post.id})">
            <i class="fa fa-pen"></i> 编辑
          </button>
          <button class="action-btn delete-post-btn" onclick="deletePost(${post.id})">
            <i class="fa fa-trash"></i>
          </button>
        </div>
        <div class="edit-post-form" id="edit-form-${post.id}" style="display:none">
          <textarea class="edit-textarea" id="edit-content-${post.id}">${escHtml(post.content)}</textarea>
          <div class="edit-actions">
            <button class="btn btn-primary btn-sm" onclick="submitEditPost(${post.id})">保存</button>
            <button class="btn btn-ghost btn-sm" onclick="cancelEditPost(${post.id})">取消</button>
          </div>
        </div>
      </div>
    </div>`;
  document.getElementById('postList').insertAdjacentHTML('beforeend', html);
  document.getElementById(`post-${post.id}`).scrollIntoView({behavior: 'smooth'});
}

function toggleLike(postId, btn) {
  fetch(window.chitchatRoute('/posts/' + postId + '/like'), {
    method: 'POST',
    headers: {'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json'},
    body: JSON.stringify({_token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => {

    btn.classList.toggle('liked', d.liked);
    const span = btn.querySelector('.like-count');
    span.textContent = parseInt(span.textContent) + (d.liked ? 1 : -1);
  });
}

function escapeRegExp(text) {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function applyQuotedMention(username) {
  const safeUsername = String(username || '').trim();
  if (!safeUsername) return;

  const currentAutoMention = replyContent.dataset.autoMention || '';
  let value = replyContent.value;

  if (currentAutoMention) {
    const previousPrefix = '@' + currentAutoMention + ' ';
    if (value.startsWith(previousPrefix)) {
      value = value.slice(previousPrefix.length);
    }
  }

  const mentionPattern = new RegExp('(^|\\s)@' + escapeRegExp(safeUsername) + '(?=\\s|$)');
  if (!mentionPattern.test(value)) {
    value = '@' + safeUsername + (value ? ' ' + value.replace(/^\s+/, '') : ' ');
    replyContent.value = value;
    replyContent.dataset.autoMention = safeUsername;
    return;
  }

  replyContent.value = value;
  delete replyContent.dataset.autoMention;
}

function quotePost(postId, username) {
  document.getElementById('replyTo').value = postId;
  document.getElementById('quotePreview').style.display = 'flex';
  document.getElementById('quoteText').textContent = '引用 @' + username + ' 的内容';
  applyQuotedMention(username);
  replyContent.focus();
  replyContent.setSelectionRange(replyContent.value.length, replyContent.value.length);
  document.getElementById('replyBox').scrollIntoView({behavior: 'smooth'});
}

function clearQuote() {
  document.getElementById('replyTo').value = '';
  document.getElementById('quotePreview').style.display = 'none';
  delete replyContent.dataset.autoMention;
}

function editPost(postId) {
  document.getElementById('edit-form-' + postId).style.display = 'block';
  document.querySelector('#post-' + postId + ' .post-content').style.display = 'none';
}

function cancelEditPost(postId) {
  document.getElementById('edit-form-' + postId).style.display = 'none';
  document.querySelector('#post-' + postId + ' .post-content').style.display = 'block';
}

function submitEditPost(postId) {
  const content = document.getElementById('edit-content-' + postId).value.trim();
  if (!content) return;
  fetch(window.chitchatRoute('/posts/' + postId + '/update'), {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({content, _token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => {

    if (d.content) {
      document.querySelector('#post-' + postId + ' .post-content').innerHTML = renderMarkdown(d.content);
      cancelEditPost(postId);
    }
  });
}

function deletePost(postId) {
  if (!confirm('确认删除这条回复吗？')) return;
  fetch(window.chitchatRoute('/posts/' + postId + '/delete'), {
    method: 'POST',
    headers: {'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json'},
    body: JSON.stringify({_token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => {
    if (d.redirect) {
      location.href = d.redirect;
      return;
    }

    if (d.success) {
      const el = document.getElementById('post-' + postId);
      el.style.opacity = '0.5';
      el.querySelector('.post-content').innerHTML = '<em style="color:#999">此内容已被删除</em>';
    }
  });
}


function toggleSticky(id) {
  fetch(window.chitchatRoute('/d/' + id + '/sticky'), {method:'POST',headers:{'X-CSRF-Token':CSRF_TOKEN,'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:JSON.stringify({_token:CSRF_TOKEN})})
    .then(r=>r.json()).then(()=>location.reload());
}

function toggleFeatured(id) {
  fetch(window.chitchatRoute('/d/' + id + '/featured'), {method:'POST',headers:{'X-CSRF-Token':CSRF_TOKEN,'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:JSON.stringify({_token:CSRF_TOKEN})})
    .then(r=>r.json()).then(()=>location.reload());
}

function toggleLock(id) {
  fetch(window.chitchatRoute('/d/' + id + '/lock'), {method:'POST',headers:{'X-CSRF-Token':CSRF_TOKEN,'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:JSON.stringify({_token:CSRF_TOKEN})})
    .then(r=>r.json()).then(()=>location.reload());
}

function deleteDiscussion(id) {
  if (!confirm('确认删除该讨论？此操作不可恢复。')) return;
  fetch(window.chitchatRoute('/d/' + id + '/delete'), {method:'POST',headers:{'X-CSRF-Token':CSRF_TOKEN,'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:JSON.stringify({_token:CSRF_TOKEN})})
    .then(r=>r.json()).then(d=>{if(d.redirect) location.href=d.redirect;});
}



function togglePreview() {
  const pv = document.getElementById('replyPreview');
  if (pv.style.display === 'none') {
    pv.innerHTML = renderMarkdown(replyContent.value);
    pv.style.display = 'block';
    replyContent.style.display = 'none';
  } else {
    pv.style.display = 'none';
    replyContent.style.display = 'block';
  }
}

function insertMd(before, after) {
  const start = replyContent.selectionStart;
  const end = replyContent.selectionEnd;
  const selected = replyContent.value.substring(start, end);
  replyContent.value = replyContent.value.substring(0, start) + before + selected + after + replyContent.value.substring(end);
  replyContent.focus();
  replyContent.setSelectionRange(start + before.length, start + before.length + selected.length);
}

function insertTextAtCursor(textarea, text) {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  textarea.value = textarea.value.substring(0, start) + text + textarea.value.substring(end);
  textarea.focus();
  textarea.setSelectionRange(start + text.length, start + text.length);
  textarea.dispatchEvent(new Event('input'));
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderMarkdown(text) {
  text = escHtml(text);
  text = text.replace(/```[\s\S]*?```/g, m => m);
  text = text.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" class="post-image">');
  text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
  text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  text = text.replace(/@(\w+)/g, (_, username) => `<a href="${window.chitchatRoute('/u/' + encodeURIComponent(username))}" class="mention">@${username}</a>`);

  text = text.replace(/\n/g, '<br>');
  return text;
}

// Fake md5 for demo (real one loaded from app.js)
function md5(s) { return '00000000000000000000000000000000'; }

document.getElementById('loginToReplyBtn') && document.getElementById('loginToReplyBtn').addEventListener('click', () => {
  document.getElementById('loginModal') && (document.getElementById('loginModal').classList.add('open'), document.getElementById('modalBackdrop').classList.add('open'));
});
</script>


<?php include __DIR__ . '/../layouts/footer.php'; ?>
