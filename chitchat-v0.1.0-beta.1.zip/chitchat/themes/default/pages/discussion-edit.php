<?php include __DIR__ . '/../layouts/header.php'; ?>
<div class="page-new-discussion">
  <div class="editor-container">
    <div class="editor-card">
      <h2 class="editor-title"><i class="fa fa-pen"></i> 编辑讨论</h2>
      <form id="editDiscussionForm">
        <input type="hidden" name="_token" value="<?= $csrfToken ?>">
        <div class="form-group">
          <input type="text" name="title" id="discussionTitle"
                 value="<?= htmlspecialchars($discussion['title']) ?>"
                 class="title-input" required maxlength="200">
        </div>
        <div class="form-group">
          <label class="form-label">分类标签</label>
          <div class="help-text" style="margin-bottom:10px">
            普通分类统一按发帖权限开放；如不选择任何分类，系统会自动归入“未分类”。公告分类仍只允许管理员与版主使用。
          </div>
          <div class="tags-selector">


            <?php
            $selectedTagIds = array_column($discussionTags, 'id');
            foreach ($tags as $tag):
            ?>
            <label class="tag-option">
              <input type="checkbox" name="tags[]" value="<?= $tag['id'] ?>"
                     <?= in_array($tag['id'], $selectedTagIds) ? 'checked' : '' ?>>
              <span class="tag-pill" style="background:<?= htmlspecialchars($tag['color']) ?>20;color:<?= htmlspecialchars($tag['color']) ?>;border:1px solid <?= htmlspecialchars($tag['color']) ?>40">
                <?= htmlspecialchars($tag['name']) ?>
              </span>
            </label>
            <?php if (!empty($tag['children'])): ?>
            <?php foreach ($tag['children'] as $child): ?>
            <label class="tag-option">
              <input type="checkbox" name="tags[]" value="<?= $child['id'] ?>"
                     <?= in_array($child['id'], $selectedTagIds) ? 'checked' : '' ?>>
              <span class="tag-pill" style="background:<?= htmlspecialchars($child['color']) ?>20;color:<?= htmlspecialchars($child['color']) ?>;border:1px solid <?= htmlspecialchars($child['color']) ?>40">
                <?= htmlspecialchars($child['name']) ?>
              </span>
            </label>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="form-group">
          <div class="editor-toolbar">
            <button type="button" onclick="insertMdEdit('**','**')"><i class="fa fa-bold"></i></button>
            <button type="button" onclick="insertMdEdit('*','*')"><i class="fa fa-italic"></i></button>
            <button type="button" onclick="insertMdEdit('[','](url)')"><i class="fa fa-link"></i></button>
            <button type="button" onclick="insertMdEdit('> ','')"><i class="fa fa-quote-left"></i></button>
            <button type="button" onclick="insertMdEdit('`','`')"><i class="fa fa-code"></i></button>
          </div>
          <textarea name="content" id="editContent" class="main-editor" rows="16" required><?= htmlspecialchars($firstPost['content'] ?? '') ?></textarea>
        </div>
        <div id="editError" class="alert-error" style="display:none"></div>
        <div class="editor-footer">
          <a href="<?= \App\Helpers\Url::route('d/' . $discussion['id']) ?>" class="btn btn-ghost">取消</a>
          <button type="submit" class="btn btn-primary btn-lg"><i class="fa fa-save"></i> 保存更改</button>


        </div>


      </form>
    </div>
  </div>
</div>
<script>
const CSRF_TOKEN = '<?= $csrfToken ?>';
const DISCUSSION_ID = <?= $discussion['id'] ?>;
document.getElementById('editDiscussionForm').addEventListener('submit', function(e) {


  e.preventDefault();
  const title = document.getElementById('discussionTitle').value.trim();
  const content = document.getElementById('editContent').value.trim();
  const tags = Array.from(document.querySelectorAll('input[name="tags[]"]:checked')).map(i => i.value);
  if (title.length < 3) { showErr('标题至少3个字符'); return; }
  fetch(window.chitchatRoute('/d/' + DISCUSSION_ID + '/update'), {

    method:'POST',
    headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF_TOKEN,'X-Requested-With':'XMLHttpRequest'},
    body:JSON.stringify({title,content,tags,_token:CSRF_TOKEN})
  }).then(r=>r.json()).then(d=>{ if(d.redirect) location.href=d.redirect; else if(d.error) showErr(d.error); });

});
function showErr(msg){ const el=document.getElementById('editError'); el.textContent='⚠️ '+msg; el.style.display='block'; }
function insertMdEdit(before,after){ const ta=document.getElementById('editContent'); const s=ta.selectionStart,e=ta.selectionEnd; const sel=ta.value.substring(s,e); ta.value=ta.value.substring(0,s)+before+sel+after+ta.value.substring(e); ta.focus(); }
</script>
<?php include __DIR__ . '/../layouts/footer.php'; ?>
