<?php
// Home page - discussion list
$view = \App\Core\Application::getInstance()->make('view');
?>
<?php include __DIR__ . '/../layouts/header.php'; ?>

<div class="page-home">
  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-inner">
      <!-- New Discussion Button -->
      <?php if ($currentUser): ?>
      <a href="<?= \App\Helpers\Url::route('new-discussion') ?>" class="btn btn-primary btn-new-discussion">
        <i class="fa fa-pen"></i> 发起新讨论
      </a>

      <?php else: ?>
      <button class="btn btn-primary btn-new-discussion" id="loginBtn2">
        <i class="fa fa-pen"></i> 发起新讨论
      </button>
      <?php endif; ?>

      <!-- Tags list -->
      <nav class="sidebar-nav">
        <div class="sidebar-section-title">分类标签</div>
        <a href="<?= \App\Helpers\Url::route() ?>" class="nav-item <?= !isset($currentTag) || !$currentTag ? 'active' : '' ?>">
          <i class="fa fa-fire"></i>
          <span>全部讨论</span>
        </a>
        <?php foreach ($tags as $tag): ?>
        <?php if (\App\Helpers\GroupPermission::isUncategorizedTag($tag)) continue; ?>
        <a href="<?= \App\Helpers\Url::route('', ['tag' => $tag['slug']]) ?>"
           class="nav-item <?= (isset($currentTag) && $currentTag && $currentTag['id'] == $tag['id']) ? 'active' : '' ?>"
           style="--tag-color: <?= htmlspecialchars($tag['color']) ?>">
          <span class="tag-dot" style="background:<?= htmlspecialchars($tag['color']) ?>"></span>
          <span><?= htmlspecialchars($tag['name']) ?></span>
          <?php if (isset($tagCounts[$tag['id']])): ?>
          <span class="tag-count"><?= $tagCounts[$tag['id']] ?></span>
          <?php endif; ?>
        </a>
        <?php if (!empty($tag['children'])): ?>
          <?php foreach ($tag['children'] as $child): ?>
          <?php if (\App\Helpers\GroupPermission::isUncategorizedTag($child)) continue; ?>
          <a href="<?= \App\Helpers\Url::route('', ['tag' => $child['slug']]) ?>"
             class="nav-item nav-item-child <?= (isset($currentTag) && $currentTag && $currentTag['id'] == $child['id']) ? 'active' : '' ?>">
            <span class="tag-dot" style="background:<?= htmlspecialchars($child['color']) ?>"></span>
            <span><?= htmlspecialchars($child['name']) ?></span>
          </a>
          <?php endforeach; ?>
        <?php endif; ?>
        <?php endforeach; ?>
      </nav>
    </div>
  </aside>

  <!-- Main content -->
  <main class="main-content">
    <!-- Sort bar -->
    <div class="sort-bar">
      <div class="sort-left">
        <?php if (isset($currentTag) && $currentTag): ?>
        <div class="tag-header">
          <span class="tag-badge" style="background:<?= htmlspecialchars($currentTag['color']) ?>">
            <?= htmlspecialchars($currentTag['name']) ?>
          </span>
          <?php if ($currentTag['description']): ?>
          <span class="tag-desc"><?= htmlspecialchars($currentTag['description']) ?></span>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
      <div class="sort-right">
        <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'last_reply'])) ?>"
           class="sort-btn <?= ($sort ?? 'last_reply') === 'last_reply' ? 'active' : '' ?>">
          最近回复
        </a>
        <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'created'])) ?>"
           class="sort-btn <?= ($sort ?? '') === 'created' ? 'active' : '' ?>">
          最新发布
        </a>
        <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'hot'])) ?>"
           class="sort-btn <?= ($sort ?? '') === 'hot' ? 'active' : '' ?>">
          最多回复
        </a>
      </div>
    </div>

    <!-- Discussion list -->
    <div class="discussion-list" id="discussionList">
      <?php if (empty($discussions['data'])): ?>
      <div class="empty-state">
        <div class="empty-icon">💬</div>
        <h3>还没有讨论</h3>
        <p>成为第一个发起讨论的人！</p>
        <?php if ($currentUser): ?>
        <a href="<?= \App\Helpers\Url::route('new-discussion') ?>" class="btn btn-primary">发起讨论</a>
        <?php else: ?>
        <button class="btn btn-primary" id="loginBtn3">登录后发起讨论</button>
        <?php endif; ?>
      </div>
      <?php else: ?>
      <?php foreach ($discussions['data'] as $d): ?>
      <div class="discussion-item <?= !empty($d['is_sticky']) ? 'is-sticky' : '' ?>">
        <div class="di-avatar">
          <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($d['username'])) ?>">
            <img src="<?= \App\Forum\Models\User::getAvatarUrl(['avatar' => $d['avatar'], 'email' => $d['user_email']], 40) ?>"
                 alt="<?= htmlspecialchars($d['username']) ?>" class="avatar-40">
          </a>
        </div>

        <div class="di-body">
          <div class="di-title-row">
            <?php if (!empty($d['is_sticky'])): ?>
            <span class="badge badge-sticky"><i class="fa fa-thumbtack"></i> 置顶</span>
            <?php endif; ?>
            <?php if (!empty($d['is_featured'])): ?>
            <span class="badge badge-featured"><i class="fa fa-star"></i> 精品</span>
            <?php endif; ?>
            <?php if (!empty($d['is_locked'])): ?>
            <span class="badge badge-lock"><i class="fa fa-lock"></i> 已锁定</span>
            <?php endif; ?>
            <a href="<?= \App\Helpers\Url::route('d/' . $d['id']) ?>" class="di-title"><?= htmlspecialchars($d['title']) ?></a>
          </div>
          <div class="di-meta">
            <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($d['username'])) ?>" class="di-author"><?= htmlspecialchars($d['username']) ?></a>

            <span class="di-time" title="<?= $d['created_at'] ?>">
              <?= timeAgo($d['created_at']) ?>
            </span>
            <?php if (!empty($d['tags'])): ?>
            <div class="di-tags">
              <?php foreach ($d['tags'] as $tag): ?>
              <a href="<?= \App\Helpers\Url::route('', ['tag' => $tag['slug']]) ?>" class="di-tag"
                 style="background:<?= htmlspecialchars($tag['color']) ?>20;color:<?= htmlspecialchars($tag['color']) ?>">

                <?= htmlspecialchars($tag['name']) ?>
              </a>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>
        </div>
        <div class="di-stats">
          <div class="di-stat">
            <i class="fa fa-comment"></i>
            <span><?= number_format($d['comment_count']) ?></span>
          </div>
          <?php if ($d['last_user_name']): ?>
          <div class="di-last-reply">
            <img src="<?= \App\Forum\Models\User::getAvatarUrl(['avatar' => $d['last_user_avatar'], 'email' => ''], 24) ?>"
                 alt="<?= htmlspecialchars($d['last_user_name']) ?>" class="avatar-24">
            <span class="di-last-time"><?= timeAgo($d['last_posted_at'] ?? $d['created_at']) ?></span>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if (($discussions['last_page'] ?? 1) > 1): ?>
    <div class="pagination">
      <?php for ($p = 1; $p <= $discussions['last_page']; $p++): ?>
      <a href="?<?= http_build_query(array_merge($_GET, ['page' => $p])) ?>"
         class="page-btn <?= $p === ($page ?? 1) ? 'active' : '' ?>"><?= $p ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  </main>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>

<?php
function timeAgo(?string $datetime): string
{
    if (!$datetime) return '';
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return '刚刚';
    if ($diff < 3600) return floor($diff / 60) . ' 分钟前';
    if ($diff < 86400) return floor($diff / 3600) . ' 小时前';
    if ($diff < 2592000) return floor($diff / 86400) . ' 天前';
    if ($diff < 31536000) return floor($diff / 2592000) . ' 个月前';
    return floor($diff / 31536000) . ' 年前';
}
?>
