<?php
$profileGroupLabel = trim((string)($profileUser['group_display_name'] ?? $profileUser['group_name'] ?? ''));
include __DIR__ . '/../layouts/header.php';
?>


<div class="page-profile">
  <div class="profile-hero">
    <div class="profile-hero-inner">
      <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="<?= htmlspecialchars($profileUser['username']) ?>" class="profile-avatar">
      <div class="profile-info">
        <h1 class="profile-username"><?= htmlspecialchars($profileUser['username']) ?></h1>
        <div class="profile-badge-row">
          <span class="uid-badge">UID #<?= (int)$profileUser['id'] ?></span>
          <?php if ($profileGroupLabel !== ''): ?>
          <span class="user-badge"><?= htmlspecialchars($profileGroupLabel) ?></span>
          <?php endif; ?>
        </div>
        <?php if ($profileUser['bio']): ?>
        <p class="profile-bio"><?= htmlspecialchars($profileUser['bio']) ?></p>
        <?php endif; ?>
        <div class="profile-meta">
          <span><i class="fa fa-calendar"></i> 加入于 <?= date('Y年m月d日', strtotime($profileUser['created_at'])) ?></span>
          <span><i class="fa fa-hashtag"></i> 注册顺位 <?= (int)$profileUser['id'] ?></span>
        </div>
      </div>

      <?php if ($currentUser && $currentUser['id'] == $profileUser['id']): ?>
      <a href="<?= \App\Helpers\Url::route('settings') ?>" class="btn btn-ghost profile-edit-btn"><i class="fa fa-pen"></i> 编辑资料</a>
      <?php endif; ?>

    </div>
  </div>

  <div class="profile-body">
    <!-- Stats -->
    <div class="profile-stats">
      <div class="stat-card">
        <div class="stat-num"><?= number_format($stats['discussion_count']) ?></div>
        <div class="stat-lbl">发起的讨论</div>
      </div>
      <div class="stat-card">
        <div class="stat-num"><?= number_format($stats['post_count']) ?></div>
        <div class="stat-lbl">回复数量</div>
      </div>
    </div>

    <!-- Recent discussions -->
    <div class="profile-section">
      <h3 class="section-title">最近的讨论</h3>
      <?php if (empty($recentDiscussions)): ?>
      <p class="text-muted">还没有发起过讨论</p>
      <?php else: ?>
      <div class="profile-discussion-list">
        <?php foreach ($recentDiscussions as $d): ?>
        <div class="profile-discussion-item">
          <a href="<?= \App\Helpers\Url::route('d/' . $d['id']) ?>" class="pd-title"><?= htmlspecialchars($d['title']) ?></a>


          <span class="pd-time"><?= date('Y-m-d', strtotime($d['created_at'])) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
