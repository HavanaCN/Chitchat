<?php include __DIR__ . '/../layouts/header.php'; ?>

<div class="page-new-discussion">
  <div class="editor-container">
    <div class="editor-card">
      <h2 class="editor-title"><i class="fa fa-pen"></i> 发起新讨论</h2>
      
      <form id="newDiscussionForm">
        <input type="hidden" name="_token" value="<?= $csrfToken ?>">
        
        <div class="form-group">
          <input type="text" name="title" id="discussionTitle" 
                 placeholder="讨论标题（5-200字）" class="title-input" required
                 maxlength="200">
        </div>

        <!-- Tags selector -->
        <div class="form-group">
          <label class="form-label">选择分类标签</label>
          <div class="help-text">
            普通分类现在统一按“允许发起讨论”权限开放；公告分类仍只允许管理员与版主发布。如暂时不选分类，系统会自动归入“未分类”。
          </div>
          <div class="tags-selector" id="tagsSelector">




            <?php foreach ($tags as $tag): ?>
            <label class="tag-option">
              <input type="checkbox" name="tags[]" value="<?= $tag['id'] ?>">
              <span class="tag-pill" style="background:<?= htmlspecialchars($tag['color']) ?>20;color:<?= htmlspecialchars($tag['color']) ?>;border:1px solid <?= htmlspecialchars($tag['color']) ?>40">
                <?= htmlspecialchars($tag['name']) ?>
              </span>
            </label>
            <?php if (!empty($tag['children'])): ?>
            <?php foreach ($tag['children'] as $child): ?>
            <label class="tag-option">
              <input type="checkbox" name="tags[]" value="<?= $child['id'] ?>">
              <span class="tag-pill" style="background:<?= htmlspecialchars($child['color']) ?>20;color:<?= htmlspecialchars($child['color']) ?>;border:1px solid <?= htmlspecialchars($child['color']) ?>40">
                <?= htmlspecialchars($child['name']) ?>
              </span>
            </label>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Editor -->
        <div class="form-group">
          <div class="editor-toolbar">
            <button type="button" onclick="insertMdNew('**','**')" title="粗体"><i class="fa fa-bold"></i></button>
            <button type="button" onclick="insertMdNew('*','*')" title="斜体"><i class="fa fa-italic"></i></button>
            <button type="button" onclick="insertMdNew('[','](url)')" title="链接"><i class="fa fa-link"></i></button>
            <button type="button" id="newImageUploadBtn" title="上传图片"><i class="fa fa-image"></i></button>

            <button type="button" onclick="insertMdNew('> ','')" title="引用"><i class="fa fa-quote-left"></i></button>
            <button type="button" onclick="insertMdNew('```\n','\n```')" title="代码块"><i class="fa fa-code"></i></button>
            <button type="button" onclick="insertMdNew('# ','')" title="标题"><i class="fa fa-heading"></i></button>
            <button type="button" id="previewToggle" onclick="toggleNewPreview()"><i class="fa fa-eye"></i> 预览</button>
          </div>
          <input type="file" id="newImageUploadInput" accept="image/jpeg,image/png,image/gif,image/webp" hidden>
          <textarea name="content" id="newContent" class="main-editor" 

                    placeholder="在这里写下你的内容，支持 Markdown 格式...&#10;&#10;例如：**粗体**、*斜体*、[链接](url)、@用户名" rows="16" required></textarea>
          <div id="newPreview" class="reply-preview markdown-body" style="display:none;min-height:200px"></div>
        </div>

        <div id="formError" class="alert-error" style="display:none"></div>

        <div class="editor-footer">
          <a href="<?= \App\Helpers\Url::route() ?>" class="btn btn-ghost">取消</a>
          <button type="submit" class="btn btn-primary btn-lg">
            <i class="fa fa-paper-plane"></i> 发布讨论
          </button>
        </div>

      </form>
    </div>
  </div>
</div>

<script>
const CSRF_TOKEN = '<?= $csrfToken ?>';
const newDiscussionForm = document.getElementById('newDiscussionForm');
const newContent = document.getElementById('newContent');
const newImageUploadBtn = document.getElementById('newImageUploadBtn');
const newImageUploadInput = document.getElementById('newImageUploadInput');


document.getElementById('newDiscussionForm').addEventListener('submit', function(e) {

  e.preventDefault();
  const title = document.getElementById('discussionTitle').value.trim();
  const content = newContent.value.trim();
  const tags = Array.from(document.querySelectorAll('input[name="tags[]"]:checked')).map(i => i.value);

  if (title.length < 3) { showError('标题至少需要3个字符'); return; }
  if (content.length < 10) { showError('内容至少需要10个字符'); return; }




  const btn = this.querySelector('[type=submit]');

  btn.disabled = true; btn.textContent = '发布中...';

  fetch(window.chitchatRoute('/discussions'), {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': CSRF_TOKEN},
    body: JSON.stringify({title, content, tags, _token: CSRF_TOKEN})
  }).then(r => r.json()).then(data => {


    if (data.redirect) location.href = data.redirect;
    else if (data.errors) {
      showError(Object.values(data.errors).flat().join(', '));
      btn.disabled = false;
      btn.innerHTML = '<i class="fa fa-paper-plane"></i> 发布讨论';
    } else if (data.error) {
      showError(data.error);
      btn.disabled = false;
      btn.innerHTML = '<i class="fa fa-paper-plane"></i> 发布讨论';
    }
  }).catch(() => {
    showError('发布失败，请稍后重试');
    btn.disabled = false;
    btn.innerHTML = '<i class="fa fa-paper-plane"></i> 发布讨论';
  });
});

newImageUploadBtn.addEventListener('click', () => {
  newImageUploadInput.click();
});

newImageUploadInput.addEventListener('change', async function() {
  const file = this.files[0];
  if (!file) return;

  const originalHtml = newImageUploadBtn.innerHTML;
  newImageUploadBtn.disabled = true;
  newImageUploadBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';

  try {
    const formData = new FormData();
    formData.append('_token', CSRF_TOKEN);
    formData.append('image', file);

    const response = await fetch(window.chitchatRoute('/uploads/editor-image'), {
      method: 'POST',
      headers: {'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': CSRF_TOKEN},
      body: formData,
    });

    const result = await response.json();
    if (!response.ok || result.error || !result.markdown) {
      showError(result.error || '图片上传失败，请稍后重试');
      return;
    }

    insertTextAtCursor(newContent, result.markdown + '\n');
  } catch (error) {
    showError('图片上传失败，请稍后重试');
  } finally {
    newImageUploadBtn.disabled = false;
    newImageUploadBtn.innerHTML = originalHtml;
    this.value = '';
  }
});

function showError(msg) {
  const el = document.getElementById('formError');
  el.textContent = '⚠️ ' + msg;
  el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 5000);
}

function insertMdNew(before, after) {
  const ta = newContent;
  const s = ta.selectionStart, e = ta.selectionEnd;
  const sel = ta.value.substring(s, e);
  ta.value = ta.value.substring(0, s) + before + sel + after + ta.value.substring(e);
  ta.focus();
  ta.setSelectionRange(s + before.length, s + before.length + sel.length);
}

function insertTextAtCursor(textarea, text) {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  textarea.value = textarea.value.substring(0, start) + text + textarea.value.substring(end);
  textarea.focus();
  textarea.setSelectionRange(start + text.length, start + text.length);
  textarea.dispatchEvent(new Event('input'));
}

function toggleNewPreview() {
  const ta = newContent;
  const pv = document.getElementById('newPreview');
  if (pv.style.display === 'none') {
    pv.innerHTML = renderMarkdownBasic(ta.value);
    pv.style.display = 'block';
    ta.style.display = 'none';
  } else {
    pv.style.display = 'none';
    ta.style.display = 'block';
  }
}

function renderMarkdownBasic(text) {
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  text = esc(text);
  text = text.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" class="post-image">');
  text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
  text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  text = text.replace(/@(\w+)/g, (_, username) => `<a href="${window.chitchatRoute('/u/' + encodeURIComponent(username))}" class="mention">@${username}</a>`);

  text = text.replace(/\n/g, '<br>');
  return text;
}
</script>
<?php include __DIR__ . '/../layouts/footer.php'; ?>
