<?php include __DIR__ . '/../layouts/header.php'; ?>

<div class="page-settings">
  <div class="settings-container">
    <h2><i class="fa fa-cog"></i> 账号设置</h2>
    
    <div id="settingsAlert" class="alert-success" style="display:none"></div>
    <div id="settingsError" class="alert-error" style="display:none"></div>

    <form id="settingsForm" enctype="multipart/form-data">
      <input type="hidden" name="_token" value="<?= $csrfToken ?>">
      
      <!-- Avatar section -->
      <div class="settings-section">
        <h3>头像</h3>
        <div class="avatar-section">
          <div class="avatar-preview-card">
            <img src="<?= htmlspecialchars($avatarUrl) ?>" alt="头像" class="avatar-80" id="avatarPreview">
          </div>
          <div class="avatar-actions">
            <label class="btn btn-ghost btn-sm" for="avatarInput">
              <i class="fa fa-upload"></i> 更换头像
            </label>
            <input type="file" name="avatar" id="avatarInput" accept="image/jpeg,image/png,image/gif,image/webp" style="display:none">
            <p class="help-text">支持 JPG、PNG、GIF、WEBP，最大 2MB。选择后直接保存即可。</p>
            <div class="avatar-status is-empty" id="avatarStatus">尚未选择新头像</div>
          </div>
        </div>
      </div>

      <!-- Profile section -->
      <div class="settings-section">
        <h3>个人资料</h3>
        <div class="form-group">
          <label>用户名（不可修改）</label>
          <input type="text" value="<?= htmlspecialchars($profileUser['username']) ?>" disabled>
        </div>
        <div class="form-group">
          <label>邮箱（不可修改）</label>
          <input type="email" value="<?= htmlspecialchars($profileUser['email']) ?>" disabled>
        </div>
        <div class="form-group">
          <label>个人简介</label>
          <textarea name="bio" rows="4" placeholder="写点什么介绍自己..."><?= htmlspecialchars($profileUser['bio'] ?? '') ?></textarea>
        </div>
      </div>

      <!-- Password section -->
      <div class="settings-section">
        <h3>修改密码</h3>
        <div class="form-group">
          <label>当前密码</label>
          <input type="password" name="current_password" placeholder="输入当前密码" autocomplete="current-password">
        </div>
        <div class="form-group">
          <label>新密码</label>
          <input type="password" name="new_password" placeholder="至少6位" autocomplete="new-password">
        </div>
        <p class="help-text">不修改密码则留空</p>
      </div>

      <div class="settings-footer">
        <button type="submit" class="btn btn-primary">
          <i class="fa fa-save"></i> 保存更改
        </button>
      </div>
    </form>
  </div>
</div>

<script>
const CSRF_TOKEN = '<?= $csrfToken ?>';
const settingsForm = document.getElementById('settingsForm');
const settingsAlert = document.getElementById('settingsAlert');
const settingsError = document.getElementById('settingsError');
const avatarInput = document.getElementById('avatarInput');
const avatarPreview = document.getElementById('avatarPreview');
const avatarStatus = document.getElementById('avatarStatus');

let committedAvatarUrl = <?= json_encode($avatarUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
let selectedAvatarObjectUrl = null;

function showSettingsError(message) {
  settingsAlert.style.display = 'none';
  settingsError.textContent = '⚠️ ' + message;
  settingsError.style.display = 'block';
}

function showSettingsSuccess(message) {
  settingsError.style.display = 'none';
  settingsAlert.textContent = message;
  settingsAlert.style.display = 'block';
  setTimeout(() => settingsAlert.style.display = 'none', 3000);
}

function updateAvatarStatus(message, isEmpty = false) {
  avatarStatus.textContent = message;
  avatarStatus.classList.toggle('is-empty', isEmpty);
}

function clearSelectedAvatarPreview() {
  if (selectedAvatarObjectUrl) {
    URL.revokeObjectURL(selectedAvatarObjectUrl);
    selectedAvatarObjectUrl = null;
  }
}

avatarInput.addEventListener('change', () => {
  const file = avatarInput.files && avatarInput.files[0];

  if (!file) {
    clearSelectedAvatarPreview();
    avatarPreview.src = committedAvatarUrl;
    updateAvatarStatus('尚未选择新头像', true);
    return;
  }

  if (file.size > 2 * 1024 * 1024) {
    avatarInput.value = '';
    clearSelectedAvatarPreview();
    avatarPreview.src = committedAvatarUrl;
    updateAvatarStatus('尚未选择新头像', true);
    showSettingsError('图片大小不能超过 2MB');
    return;
  }

  clearSelectedAvatarPreview();
  selectedAvatarObjectUrl = URL.createObjectURL(file);
  avatarPreview.src = selectedAvatarObjectUrl;
  updateAvatarStatus('已选择新头像，保存后生效');
});

settingsForm.addEventListener('submit', function(e) {
  e.preventDefault();

  const hasSelectedAvatar = !!(avatarInput.files && avatarInput.files[0]);
  const formData = new FormData(this);

  fetch(window.chitchatRoute('/settings/update'), {

    method: 'POST',
    headers: {'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: formData
  }).then(r => r.json()).then(data => {

    if (data.success) {
      showSettingsSuccess(data.message || '保存成功！');

      if (data.avatar_url) {
        committedAvatarUrl = data.avatar_url;
        clearSelectedAvatarPreview();
        avatarPreview.src = committedAvatarUrl;
        document.querySelectorAll('.user-avatar-sm').forEach(img => {
          img.src = committedAvatarUrl;
          img.width = 36;
          img.height = 36;
        });
      }

      if (hasSelectedAvatar) {
        avatarInput.value = '';
        updateAvatarStatus('头像已更新');
      }
    } else if (data.error) {
      showSettingsError(data.error);
    }
  }).catch(() => {
    showSettingsError('网络错误，请稍后重试');
  });
});

window.addEventListener('beforeunload', clearSelectedAvatarPreview);
</script>

<?php include __DIR__ . '/../layouts/footer.php'; ?>

