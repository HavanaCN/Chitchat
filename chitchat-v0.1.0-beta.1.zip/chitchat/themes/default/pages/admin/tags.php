<?php
$pageTitle = '分类管理';
$activePage = 'tags';
include __DIR__ . '/../../layouts/admin-header.php';
?>

<div class="admin-grid-2">
  <!-- Tags list -->
  <div class="admin-card">
    <div class="admin-card-header">
      <div>
        <h3>分类标签列表</h3>
        <div class="admin-card-subtitle">默认“公告”和“未分类”会被系统保护，不能删除。</div>
      </div>
    </div>
    <div id="tagsAlert" style="display:none" class="alert-success"></div>
    <table class="admin-table">
      <thead><tr><th>名称</th><th>Slug</th><th>颜色</th><th>父分类</th><th>操作</th></tr></thead>
      <tbody id="tagTableBody">
        <?php foreach ($tags as $tag): ?>
        <tr id="tag-row-<?= $tag['id'] ?>">
          <td><span class="tag-dot" style="background:<?= htmlspecialchars($tag['color']) ?>"></span> <?= htmlspecialchars($tag['name']) ?></td>
          <td><code><?= htmlspecialchars($tag['slug']) ?></code></td>
          <td><input type="color" value="<?= htmlspecialchars($tag['color']) ?>" onchange="updateTagColor(<?= $tag['id'] ?>, this.value)" title="修改颜色"></td>
          <td><?= $tag['parent_id'] ? '#' . $tag['parent_id'] : '—' ?></td>
          <td>
            <?php if (\App\Helpers\GroupPermission::isProtectedTag($tag)): ?>
            <span class="badge badge-featured">系统默认</span>
            <?php else: ?>
            <button class="btn btn-xs btn-danger" onclick="deleteTag(<?= $tag['id'] ?>)">
              <i class="fa fa-trash"></i>
            </button>
            <?php endif; ?>
          </td>
        </tr>
        <?php if (!empty($tag['children'])): ?>
        <?php foreach ($tag['children'] as $child): ?>
        <tr id="tag-row-<?= $child['id'] ?>" style="background:#fafafa">
          <td style="padding-left:32px"><span class="tag-dot" style="background:<?= htmlspecialchars($child['color']) ?>"></span> <?= htmlspecialchars($child['name']) ?></td>
          <td><code><?= htmlspecialchars($child['slug']) ?></code></td>
          <td><input type="color" value="<?= htmlspecialchars($child['color']) ?>" onchange="updateTagColor(<?= $child['id'] ?>, this.value)"></td>
          <td><?= htmlspecialchars($tag['name']) ?></td>
          <td>
            <?php if (\App\Helpers\GroupPermission::isProtectedTag($child)): ?>
            <span class="badge badge-featured">系统默认</span>
            <?php else: ?>
            <button class="btn btn-xs btn-danger" onclick="deleteTag(<?= $child['id'] ?>)">
              <i class="fa fa-trash"></i>
            </button>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Add tag form -->
  <div class="admin-card">
    <div class="admin-card-header"><h3>添加新分类</h3></div>
    <form id="addTagForm" style="padding:0 20px 20px">
      <input type="hidden" name="_token" value="<?= $csrfToken ?>">
      <div class="form-group">
        <label>分类名称 *</label>
        <input type="text" name="name" required placeholder="例如：技术交流">
      </div>
      <div class="form-group">
        <label>Slug（URL标识）</label>
        <input type="text" name="slug" placeholder="留空自动生成">
      </div>
      <div class="form-group">
        <label>描述</label>
        <input type="text" name="description" placeholder="简短描述">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>颜色</label>
          <input type="color" name="color" value="#0077cc">
        </div>
        <div class="form-group">
          <label>父分类</label>
          <select name="parent_id">
            <option value="">无（顶级分类）</option>
            <?php foreach ($tags as $tag): ?>
            <?php if (!$tag['parent_id']): ?>
            <option value="<?= $tag['id'] ?>"><?= htmlspecialchars($tag['name']) ?></option>
            <?php endif; ?>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">添加分类</button>
    </form>
  </div>
</div>

<script>
const CSRF_TOKEN = '<?= $csrfToken ?>';

document.getElementById('addTagForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(this));
  fetch(window.chitchatRoute('/admin/tags'), {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({...data, _token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => {
    if (d.success) {
      showAlert('分类已添加');
      this.reset();
      setTimeout(() => location.reload(), 1000);
    } else if (d.error) {
      showAlert(d.error, true);
    }
  });
});

function deleteTag(id) {
  if (!confirm('删除该分类？相关标记将被移除。')) return;
  fetch(window.chitchatRoute('/admin/tags/' + id + '/delete'), {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({_token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => {
    if (d.success) {
      document.getElementById('tag-row-' + id)?.remove();
      showAlert('分类已删除');
    } else if (d.error) {
      showAlert(d.error, true);
    }
  });
}

function updateTagColor(id, color) {
  fetch(window.chitchatRoute('/admin/tags/' + id + '/update'), {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({color, _token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => {
    if (d && d.error) {
      showAlert(d.error, true);
    }
  });
}

function showAlert(msg, isError = false) {
  const el = document.getElementById('tagsAlert');
  el.className = isError ? 'alert-error' : 'alert-success';
  el.textContent = (isError ? '⚠ ' : '✓ ') + msg;
  el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 3000);
}
</script>

<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
