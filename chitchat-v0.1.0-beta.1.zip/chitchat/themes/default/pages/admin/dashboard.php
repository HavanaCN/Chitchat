<?php
$pageTitle = '仪表盘';
$activePage = 'dashboard';
include __DIR__ . '/../../layouts/admin-header.php';
?>

<div class="stats-grid">
  <div class="stat-widget">
    <div class="stat-icon users"><i class="fa fa-users"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= number_format($stats['users']) ?></div>
      <div class="stat-label">注册用户</div>
    </div>
  </div>
  <div class="stat-widget">
    <div class="stat-icon discussions"><i class="fa fa-comments"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= number_format($stats['discussions']) ?></div>
      <div class="stat-label">讨论总数</div>
    </div>
  </div>
  <div class="stat-widget">
    <div class="stat-icon posts"><i class="fa fa-comment"></i></div>
    <div class="stat-info">
      <div class="stat-value"><?= number_format($stats['posts']) ?></div>
      <div class="stat-label">帖子总数</div>
    </div>
  </div>
</div>

<div class="admin-grid-2">
  <div class="admin-card">
    <div class="admin-card-header">
      <h3>最近注册用户</h3>
    </div>
    <table class="admin-table">
      <thead><tr><th>用户名</th><th>邮箱</th><th>注册时间</th></tr></thead>
      <tbody>
        <?php foreach ($recentUsers as $u): ?>
        <tr>
          <td><a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($u['username'])) ?>"><?= htmlspecialchars($u['username']) ?></a></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td><?= date('m-d H:i', strtotime($u['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>

      </tbody>
    </table>
  </div>

  <div class="admin-card">
    <div class="admin-card-header">
      <h3>最近讨论</h3>
    </div>
    <table class="admin-table">
      <thead><tr><th>标题</th><th>作者</th><th>时间</th></tr></thead>
      <tbody>
        <?php foreach ($recentDiscussions as $d): ?>
        <tr>
          <td><a href="<?= \App\Helpers\Url::route('d/' . $d['id']) ?>"><?= htmlspecialchars(mb_strimwidth($d['title'], 0, 30, '...')) ?></a></td>

          <td><?= htmlspecialchars($d['username']) ?></td>
          <td><?= date('m-d H:i', strtotime($d['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>

      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
