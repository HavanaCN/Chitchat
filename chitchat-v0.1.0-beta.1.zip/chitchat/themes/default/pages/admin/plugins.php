<?php
$pageTitle = '插件管理';
$activePage = 'plugins';
include __DIR__ . '/../../layouts/admin-header.php';
?>

<div class="admin-card">
  <div class="admin-card-header">
    <h3>已安装插件</h3>
    <button class="btn btn-primary btn-sm" onclick="document.getElementById('uploadPluginForm').classList.toggle('hidden')">
      <i class="fa fa-upload"></i> 上传插件
    </button>
  </div>

  <div id="uploadPluginForm" class="upload-form hidden" style="padding:16px;border-bottom:1px solid #eee">
    <form enctype="multipart/form-data" id="pluginUploadForm">
      <input type="hidden" name="_token" value="<?= $csrfToken ?>">
      <div style="display:flex;gap:12px;align-items:center">
        <input type="file" name="plugin" accept=".zip" required>
        <button type="submit" class="btn btn-primary btn-sm">安装</button>
      </div>
    </form>
  </div>

  <div id="pluginsAlert" style="display:none" class="alert-success"></div>

  <?php if (empty($plugins)): ?>
  <div class="empty-state" style="padding:40px">
    <div class="empty-icon">🧩</div>
    <h3>还没有安装任何插件</h3>
    <p>上传 ZIP 插件包来扩展论坛功能</p>
  </div>
  <?php else: ?>
  <table class="admin-table">
    <thead><tr><th>插件名</th><th>版本</th><th>状态</th><th>安装时间</th><th>操作</th></tr></thead>
    <tbody>
      <?php foreach ($plugins as $p): ?>
      <tr id="plugin-row-<?= htmlspecialchars($p['slug']) ?>">
        <td><strong><?= htmlspecialchars($p['name']) ?></strong><br><small style="color:#999"><?= htmlspecialchars($p['slug']) ?></small></td>
        <td><?= htmlspecialchars($p['version']) ?></td>
        <td>
          <?php if ($p['is_active']): ?>
          <span class="badge-success">已激活</span>
          <?php else: ?>
          <span class="badge-warning">未激活</span>
          <?php endif; ?>
        </td>
        <td><?= date('Y-m-d', strtotime($p['installed_at'])) ?></td>
        <td>
          <?php if ($p['is_active']): ?>
          <button class="btn btn-xs btn-warning" onclick="deactivatePlugin('<?= htmlspecialchars($p['slug']) ?>')">停用</button>
          <?php else: ?>
          <button class="btn btn-xs btn-success" onclick="activatePlugin('<?= htmlspecialchars($p['slug']) ?>')">激活</button>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<script>
const CSRF_TOKEN = '<?= $csrfToken ?>';

function activatePlugin(slug) {
  fetch(window.chitchatRoute('/admin/plugins/' + slug + '/activate'), {
    method: 'POST',
    headers: {'X-CSRF-Token': CSRF_TOKEN, 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({_token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => { if (d.success) location.reload(); });
}

function deactivatePlugin(slug) {
  fetch(window.chitchatRoute('/admin/plugins/' + slug + '/deactivate'), {
    method: 'POST',
    headers: {'X-CSRF-Token': CSRF_TOKEN, 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({_token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => { if (d.success) location.reload(); });
}

document.getElementById('pluginUploadForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch(window.chitchatRoute('/admin/plugins/upload'), {

    method: 'POST',
    headers: {'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: formData
  }).then(r => r.json()).then(d => {

    if (d.success) { showAlert('插件安装成功'); setTimeout(() => location.reload(), 1000); }
    else showAlert('安装失败: ' + (d.error || '未知错误'));
  });
});

function showAlert(msg) {
  const el = document.getElementById('pluginsAlert');
  el.textContent = msg; el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 3000);
}
</script>

<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
