<?php
$pageTitle = '邮件服务';
$activePage = 'mail';
include __DIR__ . '/../../layouts/admin-header.php';
?>

<?php if (!empty($flashSuccess)): ?>
<div class="alert-success" style="margin-bottom:16px"><?= htmlspecialchars($flashSuccess) ?></div>
<?php endif; ?>
<?php if (!empty($flashError)): ?>
<div class="alert-error" style="margin-bottom:16px"><?= htmlspecialchars($flashError) ?></div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-header">
    <div>
      <h3>SMTP 与邮件模板</h3>
      <div class="admin-card-subtitle">统一管理站点邮件发送能力，注册验证和找回密码会直接读取这里的模板。</div>
      <div class="mail-status-note"><?= htmlspecialchars($smtpStatus['description'] ?? '') ?></div>
      <?php if (!empty($smtpLastTestedAt)): ?>
      <div class="mail-status-meta">
        最近验证：<?= htmlspecialchars($smtpLastTestedAt) ?>
        <?php if (!empty($smtpLastTestRecipient)): ?>
          · 测试收件箱：<?= htmlspecialchars($smtpLastTestRecipient) ?>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
    <span class="mail-status-badge <?= htmlspecialchars($smtpStatus['class'] ?? 'is-disabled') ?>" id="smtpSavedStatusBadge">
      <?= htmlspecialchars($smtpStatus['label'] ?? '未启用') ?>
    </span>
  </div>

  <form id="adminMailForm" method="post" action="<?= \App\Helpers\Url::route('admin/mail') ?>" style="padding:20px" data-smtp-verified="<?= !empty($smtpVerified) ? '1' : '0' ?>">
    <input type="hidden" name="_token" value="<?= $csrfToken ?>">

    <div class="settings-sections">
      <div class="settings-group">
        <h4>服务开关</h4>
        <div class="form-group inline-toggle-group">
          <label>启用邮件服务</label>
          <label class="toggle-switch">
            <input type="checkbox" name="smtp_enabled" value="1" <?= !empty($settings['smtp_enabled']) ? 'checked' : '' ?>>
            <span class="toggle-slider"></span>
          </label>
        </div>
        <small class="form-help">关闭后，注册将不再要求邮箱验证，忘记密码入口也会自动停用；开启时必须先完成 SMTP 测试验证。</small>
      </div>

      <div class="settings-group">
        <h4>SMTP 配置</h4>
        <div class="form-row">
          <div class="form-group">
            <label>SMTP 服务器</label>
            <input type="text" name="smtp_host" value="<?= htmlspecialchars($settings['smtp_host'] ?? '') ?>" placeholder="smtp.example.com">
          </div>
          <div class="form-group">
            <label>SMTP 端口</label>
            <input type="number" name="smtp_port" value="<?= htmlspecialchars($settings['smtp_port'] ?? '587') ?>" min="1">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>SMTP 用户名</label>
            <input type="text" name="smtp_user" value="<?= htmlspecialchars($settings['smtp_user'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>SMTP 密码</label>
            <input type="password" name="smtp_pass" placeholder="留空则保持当前已保存的密码">
            <small class="form-help">出于安全原因，这里不会回显已保存密码。</small>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>发件人邮箱</label>
            <input type="email" name="smtp_from" value="<?= htmlspecialchars($settings['smtp_from'] ?? '') ?>" placeholder="no-reply@example.com">
          </div>
          <div class="form-group">
            <label>发件人名称</label>
            <input type="text" name="smtp_from_name" value="<?= htmlspecialchars($settings['smtp_from_name'] ?? ($forum['forum_name'] ?? 'Chitchat')) ?>" placeholder="<?= htmlspecialchars($forum['forum_name'] ?? 'Chitchat') ?>">
          </div>
        </div>
        <div class="form-group">
          <label>连接加密</label>
          <select name="smtp_encryption">
            <option value="tls" <?= ($settings['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : '' ?>>TLS（推荐）</option>
            <option value="ssl" <?= ($settings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL</option>
            <option value="none" <?= ($settings['smtp_encryption'] ?? '') === 'none' ? 'selected' : '' ?>>不加密</option>
          </select>
        </div>

        <div class="mail-test-panel">
          <div class="mail-test-panel-head">
            <div>
              <h5>发送测试邮件</h5>
              <p>先向一个收件邮箱发送测试邮件，确认 SMTP 连接、认证和投递指令成功后，才能保存启用状态。</p>
            </div>
            <span class="mail-test-state <?= !empty($smtpVerified) ? 'is-verified' : 'is-pending' ?>" id="smtpTestState">
              <?= !empty($smtpVerified) ? '当前配置已验证' : '当前配置未验证' ?>
            </span>
          </div>

          <div id="smtpTestSuccess" class="alert-success" style="display:none;margin-bottom:16px"></div>
          <div id="smtpTestError" class="alert-error" style="display:none;margin-bottom:16px"></div>

          <div class="form-row">
            <div class="form-group">
              <label>测试收件邮箱</label>
              <input type="email" name="smtp_test_email" id="smtpTestEmail" value="<?= htmlspecialchars($smtpLastTestRecipient ?: ($settings['smtp_from'] ?? '')) ?>" placeholder="example@qq.com">
              <small class="form-help">测试接口会真实发送一封邮件到这里，建议先填写你自己可收件的邮箱。</small>
            </div>
            <div class="form-group">
              <label>测试操作</label>
              <div class="mail-test-actions">
                <button type="button" class="btn btn-ghost" id="smtpTestButton"><i class="fa fa-paper-plane"></i> 发送测试邮件</button>
                <div class="mail-test-inline-note" id="smtpTestHint">
                  <?= !empty($smtpVerified)
                    ? '当前保存的 SMTP 配置已经通过验证，如仅修改邮件模板，可直接保存。'
                    : '只要修改了 SMTP 服务器、端口、用户名、密码、发件人邮箱或加密方式，就需要重新测试。' ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="settings-group">
        <h4>注册验证码邮件模板</h4>
        <div class="form-group">
          <label>邮件标题</label>
          <input type="text" name="mail_register_verify_subject" value="<?= htmlspecialchars($settings['mail_register_verify_subject'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>邮件正文</label>
          <textarea name="mail_register_verify_body" rows="9" style="font-family:monospace;font-size:.84rem"><?= htmlspecialchars($settings['mail_register_verify_body'] ?? '') ?></textarea>
        </div>
      </div>

      <div class="settings-group">
        <h4>找回密码邮件模板</h4>
        <div class="form-group">
          <label>邮件标题</label>
          <input type="text" name="mail_reset_password_subject" value="<?= htmlspecialchars($settings['mail_reset_password_subject'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>邮件正文</label>
          <textarea name="mail_reset_password_body" rows="9" style="font-family:monospace;font-size:.84rem"><?= htmlspecialchars($settings['mail_reset_password_body'] ?? '') ?></textarea>
        </div>
        <small class="form-help">可用变量：<code>{{forum_name}}</code>、<code>{{username}}</code>、<code>{{code}}</code>、<code>{{expires_minutes}}</code>、<code>{{site_url}}</code></small>
      </div>
    </div>

    <div class="mail-save-actions">
      <button type="submit" class="btn btn-primary" id="mailSaveButton"><i class="fa fa-save"></i> 保存邮件配置</button>
      <small class="form-help" id="mailSaveHint">启用邮件服务时，必须先完成测试邮件验证后才能保存。</small>
    </div>
  </form>
</div>

<div class="smtp-test-dialog" id="smtpTestDialog" hidden>
  <div class="smtp-test-dialog-backdrop" id="smtpTestDialogBackdrop"></div>
  <div class="smtp-test-dialog-card" role="dialog" aria-modal="true" aria-labelledby="smtpTestDialogTitle">
    <div class="smtp-test-dialog-icon is-pending" id="smtpTestDialogIcon"><i class="fa fa-paper-plane"></i></div>
    <div class="smtp-test-dialog-body">
      <h4 id="smtpTestDialogTitle">SMTP 测试结果</h4>
      <p id="smtpTestDialogMessage">请先发送测试邮件。</p>
      <div class="smtp-test-dialog-meta" id="smtpTestDialogMeta"></div>
    </div>
    <div class="smtp-test-dialog-actions">
      <button type="button" class="btn btn-primary" id="smtpTestDialogClose">我知道了</button>
    </div>
  </div>
</div>

<script>

(() => {
  const mailForm = document.getElementById('adminMailForm');
  if (!mailForm) {
    return;
  }

  const smtpEnabledInput = mailForm.querySelector('input[name="smtp_enabled"]');
  const saveButton = document.getElementById('mailSaveButton');
  const saveHint = document.getElementById('mailSaveHint');
  const testButton = document.getElementById('smtpTestButton');
  const testEmailInput = document.getElementById('smtpTestEmail');
  const testSuccess = document.getElementById('smtpTestSuccess');
  const testError = document.getElementById('smtpTestError');
  const testState = document.getElementById('smtpTestState');
  const testHint = document.getElementById('smtpTestHint');
  const csrfTokenInput = mailForm.querySelector('input[name="_token"]');
  const testDialog = document.getElementById('smtpTestDialog');
  const testDialogBackdrop = document.getElementById('smtpTestDialogBackdrop');
  const testDialogClose = document.getElementById('smtpTestDialogClose');
  const testDialogIcon = document.getElementById('smtpTestDialogIcon');
  const testDialogMessage = document.getElementById('smtpTestDialogMessage');
  const testDialogMeta = document.getElementById('smtpTestDialogMeta');

  const smtpInputs = [
    mailForm.querySelector('input[name="smtp_host"]'),
    mailForm.querySelector('input[name="smtp_port"]'),
    mailForm.querySelector('input[name="smtp_user"]'),
    mailForm.querySelector('input[name="smtp_pass"]'),
    mailForm.querySelector('input[name="smtp_from"]'),
    mailForm.querySelector('select[name="smtp_encryption"]'),
  ].filter(Boolean);

  let verifiedSnapshot = mailForm.dataset.smtpVerified === '1' ? getSmtpSnapshot() : '';

  function getSmtpSnapshot() {
    return JSON.stringify({
      smtp_host: mailForm.querySelector('input[name="smtp_host"]')?.value.trim() || '',
      smtp_port: mailForm.querySelector('input[name="smtp_port"]')?.value.trim() || '',
      smtp_user: mailForm.querySelector('input[name="smtp_user"]')?.value.trim() || '',
      smtp_pass: mailForm.querySelector('input[name="smtp_pass"]')?.value || '',
      smtp_from: mailForm.querySelector('input[name="smtp_from"]')?.value.trim() || '',
      smtp_encryption: mailForm.querySelector('select[name="smtp_encryption"]')?.value || 'tls',
    });
  }

  function isVerified() {
    return verifiedSnapshot !== '' && verifiedSnapshot === getSmtpSnapshot();
  }

  function isMailEnabled() {
    return !!(smtpEnabledInput && smtpEnabledInput.checked);
  }

  function hasRequiredSmtpFields() {
    const host = mailForm.querySelector('input[name="smtp_host"]')?.value.trim() || '';
    const port = mailForm.querySelector('input[name="smtp_port"]')?.value.trim() || '';
    const user = mailForm.querySelector('input[name="smtp_user"]')?.value.trim() || '';
    const from = mailForm.querySelector('input[name="smtp_from"]')?.value.trim() || '';
    return host !== '' && port !== '' && user !== '' && from !== '';
  }

  function showMessage(target, message) {
    if (!target) {
      return;
    }
    target.textContent = message || '';
    target.style.display = message ? 'block' : 'none';
  }

  function clearMessages() {
    showMessage(testSuccess, '');
    showMessage(testError, '');
  }

  function closeResultDialog() {
    if (!testDialog) {
      return;
    }
    testDialog.hidden = true;
    document.body.classList.remove('smtp-test-dialog-open');
  }

  function openResultDialog(type, message, meta) {
    if (!testDialog || !testDialogIcon || !testDialogMessage || !testDialogMeta) {
      return;
    }

    testDialog.hidden = false;
    document.body.classList.add('smtp-test-dialog-open');
    testDialogIcon.classList.remove('is-success', 'is-error', 'is-pending');
    testDialogIcon.classList.add(type === 'success' ? 'is-success' : 'is-error');
    testDialogIcon.innerHTML = type === 'success'
      ? '<i class="fa fa-check-circle"></i>'
      : '<i class="fa fa-exclamation-triangle"></i>';

    testDialogMessage.textContent = message || (type === 'success' ? 'SMTP 测试通过。' : 'SMTP 测试失败。');
    testDialogMeta.textContent = meta || (type === 'success'
      ? '请记得继续点击“保存邮件配置”，让注册验证码和忘记密码功能真正生效。'
      : '请检查 SMTP 服务器、端口、用户名、授权码和发件邮箱后再重试。');
  }

  function extractErrorMessageFromHtml(html) {

    if (!html) {
      return '';
    }

    try {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const candidates = ['.alert-error', '.error-msg', 'h1', 'h2', 'title'];
      for (const selector of candidates) {
        const node = doc.querySelector(selector);
        const text = node ? node.textContent.trim() : '';
        if (text) {
          return text;
        }
      }
      return doc.body ? doc.body.textContent.replace(/\s+/g, ' ').trim().slice(0, 180) : '';
    } catch (error) {
      return '';
    }
  }

  async function parseResponse(response) {
    const rawText = await response.text();
    let payload = null;

    if (rawText) {
      try {
        payload = JSON.parse(rawText);
      } catch (error) {
        payload = null;
      }
    }

    if (!response.ok) {
      throw new Error(
        (payload && (payload.error || payload.message))
        || extractErrorMessageFromHtml(rawText)
        || `测试失败（HTTP ${response.status}）`
      );
    }

    if (payload && payload.error) {
      throw new Error(payload.error);
    }

    return payload || {};
  }

  function updateVerificationUi(message) {
    const verified = isVerified();
    if (testState) {
      testState.textContent = verified ? '当前配置已验证' : '当前配置未验证';
      testState.classList.toggle('is-verified', verified);
      testState.classList.toggle('is-pending', !verified);
    }

    if (testHint) {
      if (message) {
        testHint.textContent = message;
      } else if (verified) {
        testHint.textContent = '当前 SMTP 配置已经通过测试，可以保存启用状态或继续仅修改邮件模板。';
      } else {
        testHint.textContent = '只要修改了 SMTP 服务器、端口、用户名、密码、发件人邮箱或加密方式，就需要重新测试。';
      }
    }
  }

  function updateSaveState() {
    const verified = isVerified();
    const canSave = !isMailEnabled() || verified;

    if (saveButton) {
      saveButton.disabled = !canSave;
    }

    if (saveHint) {
      if (!isMailEnabled()) {
        saveHint.textContent = '当前邮件服务处于关闭状态，可以直接保存；保存后注册验证码和忘记密码会同步停用。';
      } else if (verified) {
        saveHint.textContent = '当前 SMTP 配置已通过测试，可以保存启用状态。';
      } else if (!hasRequiredSmtpFields()) {
        saveHint.textContent = '请先补全 SMTP 服务器、端口、用户名和发件人邮箱，再发送测试邮件。';
      } else {
        saveHint.textContent = '当前 SMTP 配置尚未验证，请先发送测试邮件，通过后才能保存启用状态。';
      }
    }
  }

  smtpInputs.forEach((input) => {
    input.addEventListener('input', () => {
      clearMessages();
      updateVerificationUi(isVerified() ? '' : 'SMTP 配置已变更，请重新发送测试邮件后再保存。');
      updateSaveState();
    });
    input.addEventListener('change', () => {
      clearMessages();
      updateVerificationUi(isVerified() ? '' : 'SMTP 配置已变更，请重新发送测试邮件后再保存。');
      updateSaveState();
    });
  });

  if (smtpEnabledInput) {
    smtpEnabledInput.addEventListener('change', () => {
      clearMessages();
      updateVerificationUi();
      updateSaveState();
    });
  }

  if (testDialogClose) {
    testDialogClose.addEventListener('click', closeResultDialog);
  }

  if (testDialogBackdrop) {
    testDialogBackdrop.addEventListener('click', closeResultDialog);
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && testDialog && !testDialog.hidden) {
      closeResultDialog();
    }
  });

  if (testButton) {
    testButton.addEventListener('click', async () => {

      clearMessages();

      const testEmail = testEmailInput ? testEmailInput.value.trim() : '';
      if (!testEmail) {
        showMessage(testError, '请先填写用于接收测试邮件的邮箱地址');
        testEmailInput?.focus();
        return;
      }

      if (!hasRequiredSmtpFields()) {
        showMessage(testError, '请先补全 SMTP 服务器、端口、用户名和发件人邮箱');
        updateSaveState();
        return;
      }

      const originalHtml = testButton.innerHTML;
      testButton.disabled = true;
      testButton.innerHTML = '<i class="fa fa-spinner fa-spin"></i> 测试中...';

      try {
        const formData = new FormData(mailForm);
        formData.set('smtp_test_email', testEmail);

        const response = await fetch(window.chitchatRoute('/admin/mail/test'), {
          method: 'POST',
          headers: {
            'X-CSRF-Token': csrfTokenInput ? csrfTokenInput.value : '',
            'X-Requested-With': 'XMLHttpRequest',
          },
          body: formData,
        });

        const result = await parseResponse(response);
        verifiedSnapshot = getSmtpSnapshot();
        const successMessage = result.message || '测试邮件已发送，当前 SMTP 配置验证通过。';
        const successMeta = [
          result.tested_at ? `验证时间：${result.tested_at}` : '',
          testEmail ? `测试收件箱：${testEmail}` : '',
        ].filter(Boolean).join(' · ');
        showMessage(testSuccess, successMessage);
        updateVerificationUi(result.tested_at ? `${successMessage}（${result.tested_at}）` : successMessage);
        openResultDialog('success', successMessage, successMeta);
      } catch (error) {
        const message = error instanceof Error ? error.message : '测试失败，请稍后重试';
        showMessage(testError, message);
        updateVerificationUi(message);
        openResultDialog('error', message, '请检查 SMTP 服务器、端口、用户名、密码/授权码、发件邮箱以及加密方式后再试。');
      } finally {

        testButton.disabled = false;
        testButton.innerHTML = originalHtml;
        updateSaveState();
      }
    });
  }

  mailForm.addEventListener('submit', (event) => {
    if (isMailEnabled() && !isVerified()) {
      event.preventDefault();
      clearMessages();
      const message = '请先发送测试邮件并验证成功，再保存启用状态。';
      showMessage(testError, message);
      updateVerificationUi(message);
      updateSaveState();
    }
  });

  updateVerificationUi();
  updateSaveState();
})();
</script>

<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
