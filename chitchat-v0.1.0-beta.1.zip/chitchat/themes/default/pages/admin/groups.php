<?php
$pageTitle = '用户组管理';
$activePage = 'groups';
include __DIR__ . '/../../layouts/admin-header.php';
?>

<?php if (!empty($flashSuccess)): ?>
<div class="alert-success" style="margin-bottom:16px"><?= htmlspecialchars($flashSuccess) ?></div>
<?php endif; ?>
<?php if (!empty($flashError)): ?>
<div class="alert-error" style="margin-bottom:16px"><?= htmlspecialchars($flashError) ?></div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-header">
    <h3>用户组权限</h3>
    <div class="admin-card-subtitle">在这里维护用户组的外显名称和基础能力。公告分类的发帖权限固定为仅管理员与版主可用。</div>
  </div>

  <div class="group-card-list">
    <?php foreach ($groups as $group): ?>
    <?php $permissions = $group['permissions_payload'] ?? []; ?>
    <form class="group-card" method="post" action="<?= \App\Helpers\Url::route('admin/groups/' . $group['id']) ?>">
      <input type="hidden" name="_token" value="<?= $csrfToken ?>">

      <div class="group-card-head">
        <div>
          <h4><?= htmlspecialchars($group['group_display_name']) ?></h4>
          <p>系统 ID：<?= (int)$group['id'] ?> · 当前内部标识：<code><?= htmlspecialchars($group['name']) ?></code></p>
        </div>
        <span class="badge-success">已启用</span>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>内部标识名</label>
          <input type="text" name="name" value="<?= htmlspecialchars($group['name']) ?>" required>
          <small class="form-help">用于后台区分用户组，建议保持简洁稳定。</small>
        </div>
        <div class="form-group">
          <label>外显名称</label>
          <input type="text" name="display_name" value="<?= htmlspecialchars($group['group_display_name']) ?>" required>
          <small class="form-help">前台用户资料、帖子徽章等位置优先展示这个名称。</small>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>颜色</label>
          <input type="text" name="color" value="<?= htmlspecialchars($group['color'] ?? '#666666') ?>" placeholder="#666666">
        </div>
        <div class="form-group">
          <label>图标类名</label>
          <input type="text" name="icon" value="<?= htmlspecialchars($group['icon'] ?? '') ?>" placeholder="例如：fa-user-shield">
        </div>
      </div>

      <div class="permission-grid">
        <label class="permission-pill">
          <input type="checkbox" name="perm_admin" value="1" <?= !empty($permissions['admin']) ? 'checked' : '' ?>>
          <span>后台管理权限</span>
        </label>
        <label class="permission-pill">
          <input type="checkbox" name="perm_moderate" value="1" <?= !empty($permissions['moderate']) ? 'checked' : '' ?>>
          <span>版务操作权限</span>
        </label>
        <label class="permission-pill">
          <input type="checkbox" name="perm_post" value="1" <?= !empty($permissions['post']) ? 'checked' : '' ?>>
          <span>允许发起讨论</span>
        </label>
        <label class="permission-pill">
          <input type="checkbox" name="perm_reply" value="1" <?= !empty($permissions['reply']) ? 'checked' : '' ?>>
          <span>允许回复讨论</span>
        </label>
      </div>

      <div class="form-group">
        <label>分类发帖规则</label>
        <small class="form-help">分类单独授权功能已取消。现在只保留统一规则：拥有“允许发起讨论”的用户组可在普通分类发帖；公告分类固定仅管理员与版主可发。</small>
      </div>

      <div class="group-card-actions">
        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> 保存该用户组</button>
      </div>
    </form>
    <?php endforeach; ?>
  </div>
</div>

<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
