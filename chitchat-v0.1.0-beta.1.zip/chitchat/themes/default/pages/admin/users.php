<?php
$pageTitle = '用户管理';
$activePage = 'users';
include __DIR__ . '/../../layouts/admin-header.php';
?>

<div class="admin-card">
  <div class="admin-card-header">
    <h3>用户列表</h3>
    <form class="search-mini" action="<?= \App\Helpers\Url::route('admin/users') ?>" method="get">
      <input type="text" name="q" value="<?= htmlspecialchars($q ?? '') ?>" placeholder="搜索用户...">
      <button type="submit" class="btn btn-sm btn-primary">搜索</button>
    </form>
  </div>


  <div id="adminAlert" style="display:none" class="alert-success"></div>

  <table class="admin-table">
    <thead>
      <tr><th>UID</th><th>用户名</th><th>邮箱</th><th>用户组</th><th>注册时间</th><th>状态</th><th>操作</th></tr>

    </thead>
    <tbody>
      <?php foreach ($users as $u): ?>
      <tr id="user-row-<?= $u['id'] ?>">
        <td><?= $u['id'] ?></td>
        <td>
          <a href="<?= \App\Helpers\Url::route('u/' . rawurlencode($u['username'])) ?>" class="user-link">
            <?= htmlspecialchars($u['username']) ?>
          </a>
          <div class="user-cell-meta">UID #<?= (int)$u['id'] ?></div>
        </td>


        <td><?= htmlspecialchars($u['email']) ?></td>
        <td>
          <select class="mini-select" onchange="updateUser(<?= $u['id'] ?>, {group_id: this.value})">
            <?php foreach ($groups as $g): ?>
            <option value="<?= $g['id'] ?>" <?= $u['group_id'] == $g['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($g['group_label'] ?? $g['name']) ?>
            </option>

            <?php endforeach; ?>
          </select>
        </td>
        <td><?= date('Y-m-d', strtotime($u['created_at'])) ?></td>
        <td>
          <?php if ($u['suspended_until'] && strtotime($u['suspended_until']) > time()): ?>
          <span class="badge-danger">已封禁</span>
          <?php else: ?>
          <span class="badge-success">正常</span>
          <?php endif; ?>
        </td>
        <td class="actions-cell">
          <button class="btn btn-xs btn-warning" onclick="suspendUser(<?= $u['id'] ?>)" title="封禁">
            <i class="fa fa-ban"></i>
          </button>
          <button class="btn btn-xs btn-danger" onclick="deleteUser(<?= $u['id'] ?>)" title="删除"
                  <?= $u['id'] == $currentUser['id'] ? 'disabled' : '' ?>>
            <i class="fa fa-trash"></i>
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <?php if ($lastPage > 1): ?>
  <div class="pagination" style="padding:16px">
    <?php for ($p = 1; $p <= $lastPage; $p++): ?>
    <a href="<?= \App\Helpers\Url::route('admin/users', ['page' => $p, 'q' => $q ?: null]) ?>"
       class="page-btn <?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<script>
const CSRF_TOKEN = '<?= $csrfToken ?>';

function updateUser(id, data) {
  data._token = CSRF_TOKEN;
  fetch(window.chitchatRoute('/admin/users/' + id), {
    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify(data)
  }).then(r => r.json()).then(d => {
    if (d.success) showAlert('用户信息已更新');
  });
}


function suspendUser(id) {
  const days = prompt('封禁天数（0 = 解封，-1 = 永久）：');
  if (days === null) return;
  let suspendedUntil = '';
  if (parseInt(days) === -1) suspendedUntil = '2099-12-31 00:00:00';
  else if (parseInt(days) > 0) {
    const d = new Date(); d.setDate(d.getDate() + parseInt(days));
    suspendedUntil = d.toISOString().slice(0,19).replace('T',' ');
  }
  updateUser(id, {suspended_until: suspendedUntil});
}

function deleteUser(id) {
  if (!confirm('确认删除该用户？')) return;
  fetch(window.chitchatRoute('/admin/users/' + id + '/delete'), {

    method: 'POST',
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({_token: CSRF_TOKEN})
  }).then(r => r.json()).then(d => {
    if (d.success) { document.getElementById('user-row-' + id).remove(); showAlert('用户已删除'); }
  });
}


function showAlert(msg) {
  const el = document.getElementById('adminAlert');
  el.textContent = '✓ ' + msg; el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 3000);
}
</script>

<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
