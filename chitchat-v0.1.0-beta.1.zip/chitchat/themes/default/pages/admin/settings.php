<?php
$pageTitle = '论坛设置';
$activePage = 'settings';
$currentTimezone = $settings['timezone'] ?? 'Asia/Shanghai';
$resolvedForumIcon = $resolvedForumIcon ?? \App\Helpers\ForumIcon::resolve($settings);
$currentIconType = $settings['forum_icon_type'] ?? ($resolvedForumIcon['type'] === 'upload' ? 'upload' : 'preset');
$currentIconPreset = $settings['forum_icon_preset'] ?? ($resolvedForumIcon['preset'] ?? \App\Helpers\ForumIcon::defaultPreset());
include __DIR__ . '/../../layouts/admin-header.php';
?>

<div class="admin-card">
  <div class="admin-card-header"><h3>基础设置</h3></div>
  <div id="settingsAlertSuccess" style="display:none;margin:0 20px 12px" class="alert-success"></div>
  <div id="settingsAlertError" style="display:none;margin:0 20px 12px" class="alert-error"></div>

  <form id="adminSettingsForm" style="padding:20px" enctype="multipart/form-data">
    <input type="hidden" name="_token" value="<?= $csrfToken ?>">

    <div class="settings-sections">
      <div class="settings-group">
        <h4>论坛信息</h4>
        <div class="form-group">
          <label>论坛名称</label>
          <input type="text" name="forum_name" value="<?= htmlspecialchars($settings['forum_name'] ?? '') ?>" maxlength="12" required>
          <small class="form-help">最多 12 个汉字</small>
        </div>
        <div class="form-group">
          <label>论坛描述</label>
          <input type="text" name="forum_description" value="<?= htmlspecialchars($settings['forum_description'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>网站备案信息</label>
          <input type="text" name="icp_filing" value="<?= htmlspecialchars($settings['icp_filing'] ?? '') ?>" placeholder="例如：粤ICP备12345678号-1">
          <small class="form-help">非必填，填写后会显示在站点底部</small>
        </div>
        <div class="form-group">
          <label>允许注册</label>
          <label class="toggle-switch">
            <input type="checkbox" name="allow_registration" value="1" <?= !empty($settings['allow_registration']) ? 'checked' : '' ?>>
            <span class="toggle-slider"></span>
          </label>
        </div>
        <div class="form-group">
          <label>时区</label>
          <select name="timezone">
            <?php foreach (($timezoneGroups ?? []) as $group => $timezones): ?>
            <optgroup label="<?= htmlspecialchars($group) ?>">
              <?php foreach ($timezones as $tz): ?>
              <option value="<?= htmlspecialchars($tz) ?>" <?= $currentTimezone === $tz ? 'selected' : '' ?>><?= htmlspecialchars($tz) ?></option>
              <?php endforeach; ?>
            </optgroup>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="settings-group">
        <h4>论坛图标</h4>
        <div class="icon-current-preview">
          <div id="forumIconCurrentPreview"><?= \App\Helpers\ForumIcon::render($settings, 'icon-preview-box') ?></div>
          <div>
            <strong>当前显示图标</strong>
            <span id="forumIconCurrentModeText"><?= $resolvedForumIcon['type'] === 'upload' ? '使用自定义 64×64 PNG 图标' : '使用 SVG 预设图标' ?></span>
          </div>
        </div>

        <div class="icon-mode-grid">
          <label class="icon-mode-option">
            <input type="radio" name="forum_icon_type" value="preset" <?= $currentIconType !== 'upload' ? 'checked' : '' ?>>
            <span>
              <span class="icon-mode-title">使用 SVG 预设</span>
              <span class="icon-mode-desc">内置多款矢量图标，缩放清晰，适合论坛标题左侧展示。</span>
            </span>
          </label>
          <label class="icon-mode-option">
            <input type="radio" name="forum_icon_type" value="upload" <?= $currentIconType === 'upload' ? 'checked' : '' ?>>
            <span>
              <span class="icon-mode-title">上传 PNG 图标</span>
              <span class="icon-mode-desc">仅支持 64×64 PNG，前台显示尺寸会和 SVG 保持一致。</span>
            </span>
          </label>
        </div>

        <input type="hidden" name="forum_icon_preset" id="forumIconPresetInput" value="<?= htmlspecialchars($currentIconPreset) ?>">
        <div class="icon-preset-grid" id="forumIconPresetGrid">
          <?php foreach (($iconPresets ?? []) as $presetKey => $preset): ?>
          <button
            type="button"
            class="icon-preset-card <?= $currentIconPreset === $presetKey ? 'is-active' : '' ?>"
            data-preset-key="<?= htmlspecialchars($presetKey) ?>"
            data-preset-label="<?= htmlspecialchars($preset['label']) ?>"
            aria-pressed="<?= $currentIconPreset === $presetKey ? 'true' : 'false' ?>"
          >
            <span class="icon-preset-card-check"><i class="fa fa-check"></i></span>
            <span class="icon-choice-preview"><?= $preset['svg'] ?></span>
            <span class="icon-preset-meta">
              <span class="icon-preset-name"><?= htmlspecialchars($preset['label']) ?></span>
              <span class="icon-preset-key"><?= htmlspecialchars($presetKey) ?></span>
            </span>
          </button>
          <?php endforeach; ?>
        </div>
        <div class="icon-selection-status" id="forumIconPresetStatus">
          当前预设：<?= htmlspecialchars(($iconPresets[$currentIconPreset]['label'] ?? $currentIconPreset)) ?>
        </div>
        <small class="form-help">点击任意 SVG 卡片会立即选中并自动切回“使用 SVG 预设”；切换到 SVG 时不会删除你之前上传的 PNG 图标。</small>

        <div class="icon-upload-panel">
          <input type="file" name="forum_icon_file" id="forumIconFile" accept="image/png">
          <div class="icon-upload-status" id="forumIconStatus">
            <?php if (!empty($settings['forum_icon_upload'])): ?>
            当前已上传：<?= htmlspecialchars($settings['forum_icon_upload']) ?>
            <?php else: ?>
            尚未上传自定义 PNG 图标
            <?php endif; ?>
          </div>
          <small class="form-help">上传新 PNG 后会覆盖旧文件记录；如果当前模式选的是“上传 PNG 图标”，则必须至少保留一张可用图片。</small>
        </div>
      </div>

      <div class="settings-group">
        <h4>外观</h4>
        <div class="form-group">
          <label>每页显示数量</label>
          <input type="number" name="items_per_page" value="<?= $settings['items_per_page'] ?? 20 ?>" min="5" max="100">
        </div>
        <div class="form-group">
          <label>自定义 CSS</label>
          <textarea name="custom_css" rows="8" style="font-family:monospace;font-size:.85rem" placeholder="/* 自定义样式 */"><?= htmlspecialchars($settings['custom_css'] ?? '') ?></textarea>
        </div>
      </div>

      <div class="settings-group">
        <h4>邮件服务已迁移</h4>
        <div class="settings-inline-tip">
          SMTP 开关、服务器参数以及注册/找回密码邮件模板，现已统一移动到左侧栏的“邮件服务”中单独维护。
          <a href="<?= \App\Helpers\Url::route('admin/mail') ?>">立即前往邮件服务页</a>
        </div>
      </div>
    </div>

    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> 保存设置</button>
  </form>
</div>

<div class="settings-error-dialog" id="settingsErrorDialog" aria-hidden="true">
  <div class="settings-error-dialog-backdrop" data-settings-error-dialog-close></div>
  <div class="settings-error-dialog-panel" role="dialog" aria-modal="true" aria-labelledby="settingsErrorDialogTitle">
    <div class="settings-error-dialog-header">
      <div>
        <div class="settings-error-dialog-eyebrow">保存未完成</div>
        <h3 id="settingsErrorDialogTitle">保存失败</h3>
      </div>
      <button type="button" class="settings-error-dialog-close" data-settings-error-dialog-close aria-label="关闭">
        <i class="fa fa-times"></i>
      </button>
    </div>
    <div class="settings-error-dialog-body">
      <p id="settingsErrorDialogMessage">保存失败，请稍后重试。</p>
    </div>
    <div class="settings-error-dialog-actions">
      <button type="button" class="btn btn-primary" data-settings-error-dialog-close>我知道了</button>
    </div>
  </div>
</div>

<script>

const CSRF_TOKEN = '<?= $csrfToken ?>';
const settingsForm = document.getElementById('adminSettingsForm');
const settingsSuccess = document.getElementById('settingsAlertSuccess');
const settingsError = document.getElementById('settingsAlertError');
const settingsErrorDialog = document.getElementById('settingsErrorDialog');
const settingsErrorDialogTitle = document.getElementById('settingsErrorDialogTitle');
const settingsErrorDialogMessage = document.getElementById('settingsErrorDialogMessage');
const settingsErrorDialogClosers = Array.from(document.querySelectorAll('[data-settings-error-dialog-close]'));
const forumIconFile = document.getElementById('forumIconFile');
const forumIconStatus = document.getElementById('forumIconStatus');
const forumIconCurrentPreview = document.getElementById('forumIconCurrentPreview');
const forumIconCurrentModeText = document.getElementById('forumIconCurrentModeText');
const forumIconPresetInput = document.getElementById('forumIconPresetInput');
const forumIconPresetStatus = document.getElementById('forumIconPresetStatus');
let initialForumIconStatus = forumIconStatus ? forumIconStatus.textContent.trim() : '';
const presetModeInput = document.querySelector('input[name="forum_icon_type"][value="preset"]');
const uploadModeInput = document.querySelector('input[name="forum_icon_type"][value="upload"]');
const presetCards = Array.from(document.querySelectorAll('.icon-preset-card'));
const presetLabelMap = new Map(
  presetCards.map((card) => [card.dataset.presetKey || '', card.dataset.presetLabel || card.dataset.presetKey || ''])
);

function closeSettingsErrorDialog() {
  if (!settingsErrorDialog) {
    return;
  }

  settingsErrorDialog.classList.remove('is-open');
  settingsErrorDialog.setAttribute('aria-hidden', 'true');
}

function openSettingsErrorDialog(message, title = '保存失败') {
  if (settingsError) {
    settingsError.textContent = message;
    settingsError.style.display = 'none';
  }
  if (!settingsErrorDialog) {
    return;
  }

  if (settingsErrorDialogTitle) {
    settingsErrorDialogTitle.textContent = title;
  }
  if (settingsErrorDialogMessage) {
    settingsErrorDialogMessage.textContent = message;
  }
  settingsErrorDialog.classList.add('is-open');
  settingsErrorDialog.setAttribute('aria-hidden', 'false');
}

settingsErrorDialogClosers.forEach((button) => {
  button.addEventListener('click', closeSettingsErrorDialog);
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && settingsErrorDialog && settingsErrorDialog.classList.contains('is-open')) {
    closeSettingsErrorDialog();
  }
});

function showSettingsMessage(type, message) {
  if (settingsSuccess) {
    settingsSuccess.style.display = 'none';
  }
  if (settingsError) {
    settingsError.style.display = 'none';
  }

  if (type === 'error') {
    openSettingsErrorDialog(message, '保存失败');
    return;
  }

  if (!settingsSuccess) {
    return;
  }

  settingsSuccess.textContent = message;
  settingsSuccess.style.display = 'block';
  setTimeout(() => {
    settingsSuccess.style.display = 'none';
  }, 3000);
}

function extractErrorMessageFromHtml(html) {
  if (!html) {
    return '';
  }

  try {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const candidates = [
      '.error-msg',
      '.alert-error',
      'h1',
      'h2',
      'title',
    ];

    for (const selector of candidates) {
      const node = doc.querySelector(selector);
      const text = node ? node.textContent.trim() : '';
      if (text) {
        return text;
      }
    }

    const bodyText = doc.body ? doc.body.textContent.replace(/\s+/g, ' ').trim() : '';
    return bodyText.slice(0, 180);
  } catch (error) {
    return '';
  }
}

async function parseSettingsResponse(response) {
  const rawText = await response.text();
  let payload = null;

  if (rawText) {
    try {
      payload = JSON.parse(rawText);
    } catch (error) {
      payload = null;
    }
  }

  if (!response.ok) {
    const fallbackMessage = extractErrorMessageFromHtml(rawText);
    throw new Error(
      (payload && (payload.error || payload.message))
      || fallbackMessage
      || `保存失败（HTTP ${response.status}）`
    );
  }

  if (payload && payload.error) {
    throw new Error(payload.error);
  }

  if (payload) {
    return payload;
  }

  const fallbackMessage = extractErrorMessageFromHtml(rawText);
  throw new Error(fallbackMessage || '服务器返回了无法识别的内容，请稍后重试');
}


function setPresetSelection(presetKey, statusPrefix = '待保存 SVG 预设：') {
  if (!presetKey) {
    return;
  }

  presetCards.forEach((card) => {
    const isActive = card.dataset.presetKey === presetKey;
    card.classList.toggle('is-active', isActive);
    card.setAttribute('aria-pressed', isActive ? 'true' : 'false');
  });

  if (forumIconPresetInput) {
    forumIconPresetInput.value = presetKey;
  }

  if (forumIconPresetStatus) {
    forumIconPresetStatus.textContent = statusPrefix + (presetLabelMap.get(presetKey) || presetKey);
  }
}

presetCards.forEach((card) => {
  card.addEventListener('click', () => {
    const presetKey = card.dataset.presetKey || '';
    setPresetSelection(presetKey);
    if (presetModeInput) {
      presetModeInput.checked = true;
    }
  });
});

if (forumIconFile && forumIconStatus) {
  forumIconFile.addEventListener('change', function() {
    const file = this.files && this.files[0];
    if (!file) {
      forumIconStatus.textContent = initialForumIconStatus || '尚未选择新的 PNG 图标';
      return;
    }

    forumIconStatus.textContent = '已选择：' + file.name + '（保存设置后生效）';
    if (uploadModeInput) {
      uploadModeInput.checked = true;
    }
  });
}

settingsForm.addEventListener('submit', async function(e) {
  e.preventDefault();

  const formData = new FormData(this);
  const allowRegistrationInput = document.querySelector('input[name="allow_registration"]');
  if (allowRegistrationInput && !allowRegistrationInput.checked) {
    formData.set('allow_registration', '');
  }

  const checkedIconMode = document.querySelector('input[name="forum_icon_type"]:checked');
  if (checkedIconMode) {
    formData.set('forum_icon_type', checkedIconMode.value);
  }

  if (forumIconPresetInput && forumIconPresetInput.value) {
    formData.set('forum_icon_preset', forumIconPresetInput.value);
  }

  try {
    closeSettingsErrorDialog();

    const response = await fetch(window.chitchatRoute('/admin/settings'), {
      method: 'POST',
      headers: {'X-CSRF-Token': CSRF_TOKEN, 'X-Requested-With': 'XMLHttpRequest'},
      body: formData
    });

    const result = await parseSettingsResponse(response);
    showSettingsMessage('success', result.message || '设置已保存');


    if (typeof result.icon_html === 'string' && forumIconCurrentPreview) {
      forumIconCurrentPreview.innerHTML = result.icon_html;
    }
    if (result.icon_description && forumIconCurrentModeText) {
      forumIconCurrentModeText.textContent = result.icon_description;
    }
    if (result.icon_preset) {
      const statusPrefix = result.icon_type === 'preset' ? '当前预设：' : '当前使用上传 PNG 图标，保留 SVG 预设：';
      setPresetSelection(result.icon_preset, statusPrefix);
    }
    if (forumIconStatus) {
      initialForumIconStatus = result.icon_upload_filename
        ? '当前已上传：' + result.icon_upload_filename
        : '尚未上传自定义 PNG 图标';
      forumIconStatus.textContent = initialForumIconStatus;
    }
    if (forumIconFile) {
      forumIconFile.value = '';
    }
  } catch (error) {
    showSettingsMessage('error', error instanceof Error ? error.message : '保存失败，请稍后重试');
  }
});
</script>


<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
