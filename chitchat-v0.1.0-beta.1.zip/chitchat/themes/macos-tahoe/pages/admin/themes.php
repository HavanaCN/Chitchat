<?php
$pageTitle = '主题模板';
$activePage = 'themes';
include __DIR__ . '/../../layouts/admin-header.php';
?>

<div class="themes-grid">
  <?php foreach ($themes as $theme): ?>
  <?php
    $previewPng = CHITCHAT_ROOT . '/themes/' . $theme['slug'] . '/assets/images/preview.png';
    $previewSvg = CHITCHAT_ROOT . '/themes/' . $theme['slug'] . '/assets/images/preview.svg';
    $previewUrl = null;

    if (file_exists($previewPng)) {
        $previewUrl = \App\Helpers\Url::path('themes/' . $theme['slug'] . '/assets/images/preview.png');
    } elseif (file_exists($previewSvg)) {
        $previewUrl = \App\Helpers\Url::path('themes/' . $theme['slug'] . '/assets/images/preview.svg');
    }
  ?>
  <div class="theme-card <?= $theme['slug'] === $currentTheme ? 'theme-active' : '' ?>">
    <div class="theme-preview <?= $previewUrl ? '' : 'theme-preview--placeholder' ?>">
      <?php if ($previewUrl): ?>
      <img src="<?= $previewUrl ?>" alt="<?= htmlspecialchars(($theme['name'] ?? $theme['slug']) . ' 预览') ?>">
      <?php else: ?>
      <div class="theme-no-preview">🎨</div>
      <?php endif; ?>
    </div>
    <div class="theme-info">
      <div class="theme-name"><?= htmlspecialchars($theme['name'] ?? $theme['slug']) ?></div>
      <div class="theme-meta">
        <?php if ($theme['author'] ?? ''): ?>作者：<?= htmlspecialchars($theme['author']) ?> · <?php endif; ?>
        v<?= htmlspecialchars($theme['version'] ?? '1.0') ?>
      </div>
      <?php if (!empty($theme['description'])): ?>
      <div class="theme-description"><?= htmlspecialchars($theme['description']) ?></div>
      <?php endif; ?>
      <div class="theme-slug">标识：<?= htmlspecialchars($theme['slug']) ?></div>
      <div class="theme-actions">
        <?php if ($theme['slug'] === $currentTheme): ?>
        <span class="badge-success">当前使用</span>
        <?php else: ?>
        <form method="post" action="<?= \App\Helpers\Url::route('admin/settings') ?>" style="margin:0">
          <input type="hidden" name="_token" value="<?= $csrfToken ?>">
          <input type="hidden" name="theme" value="<?= htmlspecialchars($theme['slug']) ?>">
          <button type="submit" class="btn btn-sm btn-primary">启用此主题</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<?php include __DIR__ . '/../../layouts/admin-footer.php'; ?>
