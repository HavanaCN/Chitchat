<?php
/**
 * Chitchat Installation Wizard
 * Step-by-step setup: welcome → check → database → forum settings → install
 */

define('CHITCHAT_ROOT', dirname(__DIR__));
define('CONFIG_PATH', CHITCHAT_ROOT . '/config');
define('INSTALL_PATH', __DIR__);

function installerBaseUrl(): string
{
    $scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $basePath = rtrim(dirname($scriptName), '/');

    if ($basePath === '' || $basePath === '.' || $basePath === '/') {
        return '';
    }

    $basePath = preg_replace('#/install$#', '', $basePath);
    return ($basePath === '' || $basePath === '/') ? '' : rtrim($basePath, '/');
}

function installerUrl(string $path = ''): string
{
    $baseUrl = installerBaseUrl();
    $relative = ltrim($path, '/');

    if ($relative === '') {
        return $baseUrl !== '' ? $baseUrl : '/';
    }

    return ($baseUrl !== '' ? $baseUrl : '') . '/' . $relative;
}

function installerRouteUrl(string $route = ''): string
{
    $entry = installerUrl('index.php');
    $route = ltrim(trim($route), '/');

    if ($route === '') {
        return $entry;
    }

    return $entry . '?route=' . rawurlencode($route);
}

function normalizeBaseUrlInput(?string $value): string

{
    $value = trim((string)$value);
    if ($value === '' || $value === '/' || $value === '.') {
        return '';
    }

    if (preg_match('#^https?://#i', $value)) {
        return rtrim($value, '/');
    }

    $value = str_replace('\\', '/', $value);
    $path = parse_url($value, PHP_URL_PATH);
    $path = is_string($path) ? $path : $value;
    $path = '/' . trim($path, '/');

    return $path === '/' ? '' : rtrim($path, '/');
}

// Already installed?
if (file_exists(INSTALL_PATH . '/install.lock')) {
    header('Location: ' . installerUrl());
    exit;
}


session_start();

$step    = (int)($_GET['step'] ?? $_SESSION['install_step'] ?? 1);
$errors  = [];
$success = false;

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'check_env':
            $_SESSION['install_step'] = 3;
            header('Location: index.php?step=3');
            exit;

        case 'save_db':
            $dbConfig = [
                'host' => trim($_POST['db_host'] ?? 'localhost'),
                'port' => (int)($_POST['db_port'] ?? 3306),
                'name' => trim($_POST['db_name'] ?? ''),
                'user' => trim($_POST['db_user'] ?? ''),
                'pass' => $_POST['db_pass'] ?? '',
            ];
            // Test connection
            try {
                $dsn = sprintf('mysql:host=%s;port=%d;charset=utf8mb4', $dbConfig['host'], $dbConfig['port']);
                $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                // Try to select/create database
                $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . str_replace('`', '', $dbConfig['name']) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                $pdo->exec('USE `' . str_replace('`', '', $dbConfig['name']) . '`');
                $_SESSION['db_config'] = $dbConfig;
                $_SESSION['install_step'] = 4;
                header('Location: index.php?step=4');
            } catch (PDOException $e) {
                $errors[] = '数据库连接失败：' . $e->getMessage();
                $step = 3;
            }
            break;

        case 'save_forum':
            $_SESSION['forum_config'] = [
                'name'       => trim($_POST['forum_name'] ?? 'Chitchat'),
                'base_url'   => normalizeBaseUrlInput($_POST['base_url'] ?? installerBaseUrl()),
                'admin_user' => trim($_POST['admin_user'] ?? ''),
                'admin_email' => trim($_POST['admin_email'] ?? ''),
                'admin_pass'  => $_POST['admin_pass'] ?? '',
            ];

            $fc = $_SESSION['forum_config'];
            if (!$fc['name']) $errors[] = '请填写论坛名称';
            if (mb_strlen($fc['name'], 'UTF-8') > 12) $errors[] = '论坛名称不可超过12个汉字';
            if (strlen($fc['admin_user']) < 3) $errors[] = '管理员用户名至少3位';
            if (filter_var($fc['admin_user'], FILTER_VALIDATE_EMAIL)) $errors[] = '管理员用户名不能使用邮箱地址';
            if (!filter_var($fc['admin_email'], FILTER_VALIDATE_EMAIL)) $errors[] = '请填写有效邮箱';

            if (strlen($fc['admin_pass']) < 6) $errors[] = '密码至少6位';


            if (!$errors) {
                $_SESSION['install_step'] = 5;
                header('Location: index.php?step=5');
            } else {
                $step = 4;
            }
            break;

        case 'run_install':
            $result = runInstallation();
            if ($result === true) {
                $success = true;
                $step = 6;
                file_put_contents(INSTALL_PATH . '/install.lock', date('Y-m-d H:i:s'));
                unset($_SESSION['install_step'], $_SESSION['db_config'], $_SESSION['forum_config']);
            } else {
                $errors[] = $result;
                $step = 5;
            }
            break;
    }
}

function runInstallation(): bool|string
{
    $dbConf = $_SESSION['db_config'] ?? null;
    $fc     = $_SESSION['forum_config'] ?? null;
    if (!$dbConf || !$fc) return '安装数据不完整，请重新开始';

    try {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $dbConf['host'], $dbConf['port'], $dbConf['name']);
        $pdo = new PDO($dsn, $dbConf['user'], $dbConf['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

        // Create tables - execute statement by statement
        $sql = file_get_contents(CHITCHAT_ROOT . '/database/schema.sql');
        // Strip comments and split by semicolon
        $sql = preg_replace('/--[^\n]*\n/', "\n", $sql);
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        $statements = array_filter(
            array_map('trim', explode(';', $sql)),
            fn($s) => $s !== ''
        );
        foreach ($statements as $stmt) {
            $pdo->exec($stmt);
        }

        // Create admin
        $hash = password_hash($fc['admin_pass'], PASSWORD_DEFAULT);
        $now  = date('Y-m-d H:i:s');
        $pdo->prepare('INSERT INTO users (username, email, password, group_id, created_at) VALUES (?, ?, ?, 1, ?)')
            ->execute([$fc['admin_user'], $fc['admin_email'], $hash, $now]);

        // Insert default settings
        $settings = [
            ['forum_name', $fc['name']],
            ['forum_description', 'Welcome to Chitchat!'],
            ['allow_registration', '1'],
            ['theme', 'default'],
            ['forum_url', $fc['base_url'] ?? ''],
            ['smtp_enabled', '0'],
            ['smtp_host', ''],
            ['smtp_port', '587'],
            ['smtp_user', ''],
            ['smtp_pass', ''],
            ['smtp_from', ''],
            ['smtp_from_name', $fc['name']],
            ['smtp_encryption', 'tls'],
            ['mail_register_verify_subject', '【{{forum_name}}】注册验证码'],
            ['mail_register_verify_body', "你好 {{username}}：\n\n欢迎注册 {{forum_name}}。\n你的邮箱验证码是：{{code}}\n\n该验证码将在 {{expires_minutes}} 分钟后失效，请尽快完成验证。\n\n如果这不是你的操作，请忽略本邮件。\n\n{{forum_name}}\n{{site_url}}"],
            ['mail_reset_password_subject', '【{{forum_name}}】密码重置验证码'],
            ['mail_reset_password_body', "你好 {{username}}：\n\n你正在为 {{forum_name}} 重置登录密码。\n本次密码重置验证码是：{{code}}\n\n该验证码将在 {{expires_minutes}} 分钟后失效。若并非你本人操作，请尽快联系站点管理员。\n\n{{forum_name}}\n{{site_url}}"],
        ];

        $stmt = $pdo->prepare('INSERT IGNORE INTO settings (`key`, `value`) VALUES (?, ?)');
        foreach ($settings as [$k, $v]) $stmt->execute([$k, $v]);

        // Default groups
        $pdo->exec("
            INSERT IGNORE INTO `groups` (id, name, display_name, permissions) VALUES
            (1, 'Administrators', '管理员', '{\"admin\":true,\"moderate\":true,\"post\":true,\"reply\":true}'),
            (2, 'Moderators', '版主', '{\"moderate\":true,\"post\":true,\"reply\":true}'),
            (3, 'Members', '会员', '{\"post\":true,\"reply\":true}'),
            (4, 'Restricted', '受限用户', '{}')
        ");

        // Default tags
        $pdo->exec("
            INSERT IGNORE INTO tags (name, slug, description, color, icon, position) VALUES
            ('公告', 'announcements', '论坛公告', '#dc3545', 'fa-bullhorn', 0),
            ('综合讨论', 'general', '日常话题', '#0077cc', 'fa-comments', 1),
            ('技术交流', 'tech', '技术相关讨论', '#28a745', 'fa-code', 2),
            ('未分类', 'uncategorized', '未选择分类的讨论会自动归档到这里', '#64748b', 'fa-inbox', 999)
        ");


        // Write config
        $configContent = '<?php return ' . var_export([
            'app' => [
                'name'     => $fc['name'],
                'base_url' => $fc['base_url'] ?? installerBaseUrl(),
                'theme'    => 'default',
                'debug'    => false,
                'timezone' => 'Asia/Shanghai',
            ],

            'database' => $dbConf,
        ], true) . ';';
        file_put_contents(CONFIG_PATH . '/config.php', $configContent);

        return true;
    } catch (Exception $e) {
        return '安装失败：' . $e->getMessage();
    }
}

function checkEnv(): array
{
    $checks = [];
    $checks['php_version'] = [
        'label' => 'PHP 版本 (需要 8.0+)',
        'pass'  => version_compare(PHP_VERSION, '8.0.0', '>='),
        'value' => PHP_VERSION,
    ];
    foreach (['pdo', 'pdo_mysql', 'json', 'gd', 'mbstring'] as $ext) {
        $checks[$ext] = [
            'label' => "PHP 扩展: {$ext}",
            'pass'  => extension_loaded($ext),
            'value' => extension_loaded($ext) ? '已安装' : '缺少',
        ];
    }

    $checks['fileinfo_optional'] = [
        'label' => 'PHP 扩展: fileinfo（可选）',
        'pass'  => true,
        'value' => extension_loaded('fileinfo') ? '已安装' : '未安装（已使用其他方式替代）',
    ];
    $dirs = [
        CHITCHAT_ROOT . '/storage'  => 'storage/ 目录',
        CHITCHAT_ROOT . '/uploads'  => 'uploads/ 目录',
        CHITCHAT_ROOT . '/config'   => 'config/ 目录',
    ];
    foreach ($dirs as $path => $label) {
        if (!is_dir($path)) @mkdir($path, 0755, true);
        $checks[$path] = [
            'label' => "{$label} 可写",
            'pass'  => is_writable($path),
            'value' => is_writable($path) ? '可写' : '不可写',
        ];
    }
    return $checks;
}

$envChecks  = $step >= 2 ? checkEnv() : [];
$allPassed  = $step >= 2 && !in_array(false, array_column($envChecks, 'pass'));
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>安装 Chitchat 轻聊论坛</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f0f4f8;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.install-card{background:#fff;border-radius:16px;box-shadow:0 8px 40px rgba(0,0,0,.12);width:100%;max-width:620px;overflow:hidden}
.install-header{background:linear-gradient(135deg,#0077cc,#005fa3);color:#fff;padding:36px 40px 28px;text-align:center}
.install-header h1{font-size:2rem;font-weight:800;letter-spacing:-0.5px}
.install-header p{opacity:.85;margin-top:6px;font-size:.95rem}
.steps{display:flex;background:#e8f4fd;padding:0 40px}
.step-item{flex:1;padding:12px 8px;text-align:center;font-size:.75rem;color:#888;border-bottom:3px solid transparent;cursor:default;transition:.2s}
.step-item.active{color:#0077cc;border-bottom-color:#0077cc;font-weight:600}
.step-item.done{color:#28a745}
.install-body{padding:36px 40px}
h2{font-size:1.2rem;font-weight:700;margin-bottom:20px;color:#1a1a2e}
.alert{padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:.9rem}
.alert-error{background:#fff0f0;border:1px solid #ffcccc;color:#c0392b}
.alert-success{background:#f0fff4;border:1px solid #c3e6cb;color:#276749}
.check-list{list-style:none;margin-bottom:24px}
.check-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:8px;margin-bottom:6px;font-size:.9rem}
.check-item.pass{background:#f0fff4;color:#276749}
.check-item.fail{background:#fff0f0;color:#c0392b}
.check-icon{font-size:1rem;flex-shrink:0}
.form-group{margin-bottom:18px}
label{display:block;font-size:.88rem;font-weight:600;color:#444;margin-bottom:6px}
input[type=text],input[type=email],input[type=password],input[type=number]{width:100%;padding:10px 14px;border:1.5px solid #ddd;border-radius:8px;font-size:.95rem;transition:.2s;outline:none}
input:focus{border-color:#0077cc;box-shadow:0 0 0 3px rgba(0,119,204,.15)}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:12px 28px;border-radius:8px;border:none;font-size:.95rem;font-weight:600;cursor:pointer;transition:.2s;text-decoration:none}
.btn-primary{background:#0077cc;color:#fff}
.btn-primary:hover{background:#005fa3}
.btn-secondary{background:#f0f4f8;color:#444;border:1.5px solid #ddd}
.btn-secondary:hover{background:#e0e8f0}
.btn-group{display:flex;gap:12px;margin-top:24px}
.welcome-icon{font-size:4rem;margin-bottom:16px;display:block;text-align:center}
.welcome-features{list-style:none;margin:16px 0}
.welcome-features li{padding:8px 0;display:flex;align-items:center;gap:10px;color:#555;font-size:.93rem;border-bottom:1px solid #f5f5f5}
.welcome-features li:last-child{border-bottom:none}
.welcome-features .icon{color:#0077cc;font-size:1rem}
.install-complete{text-align:center;padding:20px 0}
.install-complete .big-check{font-size:4rem;margin-bottom:16px;display:block}
.install-complete h3{font-size:1.5rem;font-weight:700;color:#276749;margin-bottom:8px}
.install-complete p{color:#666;margin-bottom:24px}
</style>
</head>
<body>
<div class="install-card">
  <div class="install-header">
    <h1>🗨️ Chitchat</h1>
    <p>轻聊论坛安装向导</p>
  </div>

  <!-- Steps indicator -->
  <div class="steps">
    <?php $stepLabels = ['欢迎', '环境检查', '数据库', '论坛设置', '安装', '完成']; ?>
    <?php foreach ($stepLabels as $i => $label): $n = $i + 1; ?>
    <div class="step-item <?= $n === $step ? 'active' : ($n < $step ? 'done' : '') ?>">
      <?= $n < $step ? '✓' : $n ?> <?= $label ?>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="install-body">
    <?php if ($errors): ?>
    <div class="alert alert-error">
      <?php foreach ($errors as $e): ?><p>⚠️ <?= htmlspecialchars($e) ?></p><?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ($step === 1): ?>
    <!-- STEP 1: Welcome -->
    <span class="welcome-icon">🎉</span>
    <h2>欢迎安装 Chitchat 轻聊论坛</h2>
    <p style="color:#666;margin-bottom:16px;font-size:.93rem">Chitchat 是一个现代化、轻量级的 PHP 论坛程序，仿 Flarum 风格设计，开箱即用。</p>
    <ul class="welcome-features">
      <li><span class="icon">✓</span> 简洁现代的 Flarum 风格 UI</li>
      <li><span class="icon">✓</span> 讨论、回帖、标签分类、点赞系统</li>
      <li><span class="icon">✓</span> 用户注册登录、权限管理</li>
      <li><span class="icon">✓</span> 灵活的模板系统与插件扩展</li>
      <li><span class="icon">✓</span> 完善的管理后台</li>
    </ul>
    <form method="post" action="index.php?step=2">
      <input type="hidden" name="action" value="check_env">
      <div class="btn-group">
        <button class="btn btn-primary" type="submit">开始安装 →</button>
      </div>
    </form>

    <?php elseif ($step === 2): ?>
    <!-- STEP 2: Environment Check -->
    <h2>🔍 环境检查</h2>
    <ul class="check-list">
      <?php foreach ($envChecks as $check): ?>
      <li class="check-item <?= $check['pass'] ? 'pass' : 'fail' ?>">
        <span class="check-icon"><?= $check['pass'] ? '✓' : '✗' ?></span>
        <span><?= htmlspecialchars($check['label']) ?></span>
        <span style="margin-left:auto;font-size:.8rem"><?= htmlspecialchars($check['value']) ?></span>
      </li>
      <?php endforeach; ?>
    </ul>
    <?php if ($allPassed): ?>
    <div class="alert alert-success">所有检查通过，可以继续安装！</div>
    <form method="post" action="index.php?step=3">
      <input type="hidden" name="action" value="check_env">
      <div class="btn-group">
        <a href="index.php?step=1" class="btn btn-secondary">← 上一步</a>
        <button class="btn btn-primary" type="submit">下一步 →</button>
      </div>
    </form>
    <?php else: ?>
    <div class="alert alert-error">请修复上述问题后刷新页面。</div>
    <div class="btn-group"><a href="index.php?step=2" class="btn btn-secondary">刷新检查</a></div>
    <?php endif; ?>

    <?php elseif ($step === 3): ?>
    <!-- STEP 3: Database -->
    <h2>🗄️ 数据库配置</h2>
    <form method="post" action="index.php?step=3">
      <input type="hidden" name="action" value="save_db">
      <div class="form-row">
        <div class="form-group">
          <label>数据库主机</label>
          <input type="text" name="db_host" value="localhost" required>
        </div>
        <div class="form-group">
          <label>端口</label>
          <input type="number" name="db_port" value="3306" required>
        </div>
      </div>
      <div class="form-group">
        <label>数据库名称</label>
        <input type="text" name="db_name" value="chitchat" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>用户名</label>
          <input type="text" name="db_user" value="root" required>
        </div>
        <div class="form-group">
          <label>密码</label>
          <input type="password" name="db_pass" placeholder="(留空表示无密码)">
        </div>
      </div>
      <div class="btn-group">
        <a href="index.php?step=2" class="btn btn-secondary">← 上一步</a>
        <button class="btn btn-primary" type="submit">测试并继续 →</button>
      </div>
    </form>

    <?php elseif ($step === 4): ?>
    <!-- STEP 4: Forum Settings -->
    <h2>⚙️ 论坛基本设置</h2>
    <form method="post" action="index.php?step=4">
      <input type="hidden" name="action" value="save_forum">
      <div class="form-group">
        <label>论坛名称</label>
        <input type="text" name="forum_name" value="<?= htmlspecialchars($_SESSION['forum_config']['name'] ?? '轻聊论坛') ?>" maxlength="12" required>

        <small style="display:block;margin-top:6px;color:#6b7280;">论坛名称最多 12 个汉字</small>

      </div>
      <div class="form-group">
        <label>站点基础路径（base_url）</label>
        <input type="text" name="base_url" value="<?= htmlspecialchars($_SESSION['forum_config']['base_url'] ?? installerBaseUrl()) ?>" placeholder="例如：/chitchatbbs">
        <small style="display:block;margin-top:6px;color:#6b7280;">如果论坛安装在子目录，请填写类似 /chitchatbbs；根目录安装可留空。</small>
      </div>
      <div class="form-group">
        <label>管理员用户名</label>

        <input type="text" name="admin_user" placeholder="admin" required>
      </div>
      <div class="form-group">
        <label>管理员邮箱</label>
        <input type="email" name="admin_email" placeholder="admin@example.com" required>
      </div>
      <div class="form-group">
        <label>管理员密码</label>
        <input type="password" name="admin_pass" placeholder="至少6位" required>
      </div>
      <div class="btn-group">
        <a href="index.php?step=3" class="btn btn-secondary">← 上一步</a>
        <button class="btn btn-primary" type="submit">下一步 →</button>
      </div>
    </form>

    <?php elseif ($step === 5): ?>
    <!-- STEP 5: Install -->
    <h2>🚀 执行安装</h2>
    <p style="color:#666;margin-bottom:20px;font-size:.93rem">
      一切就绪！点击下方按钮开始创建数据库表、写入配置并初始化论坛。
    </p>
    <div style="background:#f8faff;border-radius:8px;padding:16px;margin-bottom:20px;font-size:.88rem;color:#555">
      <strong>安装摘要：</strong><br>
      📌 数据库：<?= htmlspecialchars(($_SESSION['db_config']['host'] ?? '') . ':' . ($_SESSION['db_config']['name'] ?? '')) ?><br>
      📌 论坛名：<?= htmlspecialchars($_SESSION['forum_config']['name'] ?? '') ?><br>
      📌 基础路径：<?= htmlspecialchars(($_SESSION['forum_config']['base_url'] ?? '') !== '' ? ($_SESSION['forum_config']['base_url'] ?? '') : '/') ?><br>
      📌 管理员：<?= htmlspecialchars($_SESSION['forum_config']['admin_user'] ?? '') ?>
    </div>

    <form method="post" action="index.php?step=5">
      <input type="hidden" name="action" value="run_install">
      <div class="btn-group">
        <a href="index.php?step=4" class="btn btn-secondary">← 上一步</a>
        <button class="btn btn-primary" type="submit">🚀 立即安装</button>
      </div>
    </form>

    <?php elseif ($step === 6): ?>
    <!-- STEP 6: Done -->
    <div class="install-complete">
      <span class="big-check">🎊</span>
      <h3>安装成功！</h3>
      <p>Chitchat 轻聊论坛已成功安装，现在可以开始使用了。</p>
      <div class="btn-group" style="justify-content:center">
        <a href="<?= installerUrl() ?>" class="btn btn-primary">访问论坛首页 →</a>
        <a href="<?= installerRouteUrl('admin') ?>" class="btn btn-secondary">进入管理后台</a>

      </div>

    </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
