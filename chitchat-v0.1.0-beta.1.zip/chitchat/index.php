<?php
/**
 * Chitchat Forum - Front Entry Point
 */

define('CHITCHAT_ROOT', __DIR__);
define('APP_PATH', CHITCHAT_ROOT . '/app');
define('CONFIG_PATH', CHITCHAT_ROOT . '/config');
define('THEMES_PATH', CHITCHAT_ROOT . '/themes');
define('PLUGINS_PATH', CHITCHAT_ROOT . '/plugins');
define('STORAGE_PATH', CHITCHAT_ROOT . '/storage');
define('PUBLIC_PATH', __DIR__);

// Check installation
$configFile  = CONFIG_PATH . '/config.php';
$installLock = CHITCHAT_ROOT . '/install/install.lock';

if (!file_exists($configFile) || !file_exists($installLock)) {
    // Redirect to installer
    $installUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    $base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    header('Location: ' . $installUrl . $base . '/install/index.php');
    exit;
}

// Autoloader
require_once APP_PATH . '/autoload.php';

$app = new \App\Core\Application(CHITCHAT_ROOT);
$app->boot();
$app->run();
