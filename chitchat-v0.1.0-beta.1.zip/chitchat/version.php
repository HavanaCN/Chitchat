<?php
return [
    'name' => 'Chitchat',
    'version' => '0.1.0-beta.1',
    'tag' => 'v0.1.0-beta.1',
    'channel' => 'beta',
    'release_date' => '2026-04-06',
];
