<?php
namespace App\Core;

class QueryBuilder
{
    protected Database $db;
    protected string $table;
    protected array $conditions = [];
    protected array $bindings   = [];
    protected array $orders     = [];
    protected ?int  $limitVal   = null;
    protected ?int  $offsetVal  = null;
    protected array $selects    = ['*'];
    protected array $joins      = [];

    public function __construct(Database $db, string $table)
    {
        $this->db    = $db;
        $this->table = $table;
    }

    public function select(string ...$columns): static
    {
        $this->selects = $columns;
        return $this;
    }

    public function where(string $column, mixed $operator, mixed $value = null): static
    {
        if ($value === null) { $value = $operator; $operator = '='; }
        $this->conditions[] = "{$column} {$operator} ?";
        $this->bindings[]   = $value;
        return $this;
    }

    public function whereIn(string $column, array $values): static
    {
        if (empty($values)) {
            $this->conditions[] = '1=0';
            return $this;
        }
        $placeholders = implode(',', array_fill(0, count($values), '?'));
        $this->conditions[] = "{$column} IN ({$placeholders})";
        $this->bindings = array_merge($this->bindings, $values);
        return $this;
    }

    public function orderBy(string $column, string $direction = 'ASC'): static
    {
        $direction = strtoupper($direction) === 'DESC' ? 'DESC' : 'ASC';
        $this->orders[] = "{$column} {$direction}";
        return $this;
    }

    public function limit(int $limit): static { $this->limitVal = $limit; return $this; }
    public function offset(int $offset): static { $this->offsetVal = $offset; return $this; }

    public function join(string $table, string $on, string $type = 'INNER'): static
    {
        $this->joins[] = "{$type} JOIN {$table} ON {$on}";
        return $this;
    }

    public function leftJoin(string $table, string $on): static
    {
        return $this->join($table, $on, 'LEFT');
    }

    protected function buildSelect(): string
    {
        $sql = 'SELECT ' . implode(', ', $this->selects) . ' FROM ' . $this->table;
        if ($this->joins) $sql .= ' ' . implode(' ', $this->joins);
        if ($this->conditions) $sql .= ' WHERE ' . implode(' AND ', $this->conditions);
        if ($this->orders) $sql .= ' ORDER BY ' . implode(', ', $this->orders);
        if ($this->limitVal !== null) $sql .= ' LIMIT ' . $this->limitVal;
        if ($this->offsetVal !== null) $sql .= ' OFFSET ' . $this->offsetVal;
        return $sql;
    }

    public function get(): array { return $this->db->select($this->buildSelect(), $this->bindings); }
    public function first(): ?array { return $this->limit(1)->db->selectOne($this->buildSelect(), $this->bindings); }
    public function count(): int
    {
        $this->selects = ['COUNT(*) as cnt'];
        $row = $this->db->selectOne($this->buildSelect(), $this->bindings);
        return (int)($row['cnt'] ?? 0);
    }

    public function insert(array $data): int
    {
        $cols = array_keys($data);
        $placeholders = array_fill(0, count($cols), '?');
        $sql = 'INSERT INTO ' . $this->table . ' (' . implode(',', $cols) . ') VALUES (' . implode(',', $placeholders) . ')';
        return $this->db->insert($sql, array_values($data));
    }

    public function update(array $data): int
    {
        $sets = array_map(fn($col) => "{$col} = ?", array_keys($data));
        $sql  = 'UPDATE ' . $this->table . ' SET ' . implode(', ', $sets);
        if ($this->conditions) $sql .= ' WHERE ' . implode(' AND ', $this->conditions);
        $bindings = array_merge(array_values($data), $this->bindings);
        return $this->db->update($sql, $bindings);
    }

    public function delete(): int
    {
        $sql = 'DELETE FROM ' . $this->table;
        if ($this->conditions) $sql .= ' WHERE ' . implode(' AND ', $this->conditions);
        return $this->db->delete($sql, $this->bindings);
    }

    public function paginate(int $perPage = 20, int $page = 1): array
    {
        $total = $this->count();
        // Reset count modifiers
        $this->selects = ['*'];
        $this->limitVal = $perPage;
        $this->offsetVal = ($page - 1) * $perPage;
        $items = $this->db->select($this->buildSelect(), $this->bindings);
        return [
            'data'         => $items,
            'total'        => $total,
            'per_page'     => $perPage,
            'current_page' => $page,
            'last_page'    => (int)ceil($total / $perPage),
        ];
    }
}
