<?php
namespace App\Core;

class EventDispatcher
{
    protected array $listeners = [];

    public function listen(string $event, callable $listener): void
    {
        $this->listeners[$event][] = $listener;
    }

    public function dispatch(object|string $event, mixed $payload = null): void
    {
        $eventName = is_object($event) ? get_class($event) : $event;
        foreach ($this->listeners[$eventName] ?? [] as $listener) {
            $listener($event, $payload);
        }
    }

    public function filter(string $hook, mixed $value, ...$args): mixed
    {
        foreach ($this->listeners['filter:' . $hook] ?? [] as $listener) {
            $value = $listener($value, ...$args);
        }
        return $value;
    }

    public function addFilter(string $hook, callable $listener): void
    {
        $this->listeners['filter:' . $hook][] = $listener;
    }
}
