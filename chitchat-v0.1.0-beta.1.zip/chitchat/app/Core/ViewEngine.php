<?php
namespace App\Core;

use App\Helpers\Url;

class ViewEngine
{
    protected string $themesPath;
    protected Config $config;
    protected array $globals = [];

    public function __construct(string $themesPath, Config $config)
    {
        $this->themesPath = $themesPath;
        $this->config     = $config;
    }

    public function share(string $key, mixed $value): void
    {
        $this->globals[$key] = $value;
    }

    public function render(string $view, array $data = []): string
    {
        $theme = $this->config->get('app.theme', 'default');
        $data  = array_merge($this->globals, $data);

        // Convert dot notation to path
        $viewPath = str_replace('.', '/', $view);
        $file     = $this->themesPath . '/' . $theme . '/' . $viewPath . '.php';

        if (!file_exists($file)) {
            // Fallback to default theme
            $file = $this->themesPath . '/default/' . $viewPath . '.php';
        }

        if (!file_exists($file)) {
            throw new \RuntimeException("View [{$view}] not found at {$file}");
        }

        // Render with output buffering
        return $this->renderFile($file, $data);
    }

    protected function renderFile(string $file, array $data): string
    {
        extract($data, EXTR_SKIP);
        ob_start();
        include $file;
        return ob_get_clean();
    }

    public function asset(string $path, ?string $theme = null): string
    {
        $theme        = $theme ?? $this->config->get('app.theme', 'default');
        $relativePath = ltrim($path, '/');
        $assetUrl     = Url::path('themes/' . $theme . '/assets/' . $relativePath);
        $assetPath    = $this->themesPath . '/' . $theme . '/assets/' . $relativePath;

        if (!file_exists($assetPath) && $theme !== 'default') {
            $fallbackPath = $this->themesPath . '/default/assets/' . $relativePath;
            if (file_exists($fallbackPath)) {
                $assetPath = $fallbackPath;
                $assetUrl  = Url::path('themes/default/assets/' . $relativePath);
            }
        }

        if (file_exists($assetPath)) {
            $assetUrl .= '?v=' . filemtime($assetPath);
        }

        return $assetUrl;
    }


}
