<?php
namespace App\Core;

/**
 * Chitchat Application Bootstrap
 */
class Application
{
    protected static Application $instance;
    protected string $basePath;
    protected Container $container;
    protected Router $router;
    protected EventDispatcher $events;

    public function __construct(string $basePath)
    {
        $this->basePath = rtrim($basePath, '/\\');
        static::$instance = $this;
        $this->container = new Container();
        $this->events = new EventDispatcher();
        $this->router = new Router($this->container);
        $this->registerBindings();
    }

    public static function getInstance(): static
    {
        return static::$instance;
    }

    protected function registerBindings(): void
    {
        $this->container->instance('app', $this);
        $this->container->instance('events', $this->events);
        $this->container->instance('router', $this->router);

        // Config
        $config = new Config($this->basePath . '/config/config.php');
        $this->container->instance('config', $config);

        // Database
        $this->container->singleton('db', function () use ($config) {
            return new Database($config->get('database'));
        });

        // Session
        $this->container->singleton('session', function () {
            return new Session();
        });

        // View
        $this->container->singleton('view', function () {
            return new ViewEngine($this->basePath . '/themes', $this->container->make('config'));
        });

        // Version
        $this->container->singleton('version', function () {
            return new Version($this->basePath);
        });

        // Auth

        $this->container->singleton('auth', function () {
            return new Auth($this->container->make('db'), $this->container->make('session'));
        });
    }

    public function boot(): void
    {
        // Start session
        $this->container->make('session')->start();

        SchemaManager::sync($this->container->make('db'));
        $this->applyTimezone();

        // Load plugins
        $pluginManager = new PluginManager($this->basePath . '/plugins', $this->container, $this->events);
        $this->container->instance('plugins', $pluginManager);
        $pluginManager->loadActive();

        // Register routes
        $this->registerRoutes();
    }



    protected function applyTimezone(): void
    {
        $timezone = $this->container->make('config')->get('app.timezone', 'Asia/Shanghai');

        try {
            $row = $this->container->make('db')->selectOne("SELECT `value` FROM settings WHERE `key` = 'timezone' LIMIT 1");
            if (!empty($row['value']) && in_array($row['value'], \DateTimeZone::listIdentifiers(), true)) {
                $timezone = $row['value'];
            }
        } catch (\Throwable $e) {
            // Ignore and fall back to config/php defaults.
        }

        if (!in_array($timezone, \DateTimeZone::listIdentifiers(), true)) {
            $timezone = 'Asia/Shanghai';
        }

        date_default_timezone_set($timezone);
    }

    protected function registerRoutes(): void
    {
        require_once $this->basePath . '/app/routes.php';
    }


    public function run(): void
    {
        $request = Request::capture();
        $this->container->instance('request', $request);

        try {
            $response = $this->router->dispatch($request);
            $response->send();
        } catch (\Throwable $e) {
            $this->handleException($e);
        }
    }

    protected function handleException(\Throwable $e): void
    {
        $code = $e->getCode() ?: 500;
        if ($code < 100 || $code > 599) {
            $code = 500;
        }

        $message = trim((string)$e->getMessage()) ?: '服务器错误';
        $request = null;
        try {
            $request = $this->container->make('request');
        } catch (\Throwable $ignored) {
            $request = null;
        }

        if ($request instanceof Request && ($request->isAjax() || $request->isJson())) {
            Response::json([
                'success' => false,
                'error' => $message,
            ], $code)->send();
            return;
        }

        http_response_code($code);

        $view = $this->container->make('view');
        echo $view->render('pages/error', [
            'code'    => $code,
            'message' => $message,
        ]);
    }


    public function make(string $abstract)
    {
        return $this->container->make($abstract);
    }

    public function getBasePath(): string
    {
        return $this->basePath;
    }
}
