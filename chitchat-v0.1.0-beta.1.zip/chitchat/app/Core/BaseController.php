<?php
namespace App\Core;

use App\Helpers\Url;

abstract class BaseController
{
    protected Application $app;
    protected ViewEngine $view;
    protected Auth $auth;
    protected Session $session;
    protected Database $db;
    protected EventDispatcher $events;

    public function __construct()
    {
        $this->app     = Application::getInstance();
        $this->view    = $this->app->make('view');
        $this->auth    = $this->app->make('auth');
        $this->session = $this->app->make('session');
        $this->db      = $this->app->make('db');
        $this->events  = $this->app->make('events');

        try {
            $appVersion = $this->app->make('version')->all();
        } catch (\Throwable $e) {
            $appVersion = [
                'name' => 'Chitchat',
                'version' => '0.0.0-dev',
                'tag' => 'v0.0.0-dev',
                'channel' => 'dev',
                'release_date' => null,
            ];
        }

        // Share common data with all views
        $this->view->share('currentUser', $this->auth->user());
        $this->view->share('forum', $this->getForumSettings());
        $this->view->share('csrfToken', $this->session->token());
        $this->view->share('basePath', Url::baseUrl());
        $this->view->share('appVersion', $appVersion);

    }


    protected function getForumSettings(): array
    {
        try {
            $rows = $this->db->select('SELECT `key`, `value` FROM settings');
            $settings = [];
            foreach ($rows as $row) {
                $settings[$row['key']] = $row['value'];
            }
            return $settings;
        } catch (\Exception $e) {
            return ['name' => 'Chitchat', 'description' => ''];
        }
    }

    protected function render(string $view, array $data = []): Response
    {
        $html = $this->view->render($view, $data);
        return Response::html($html);
    }

    protected function json(mixed $data, int $status = 200): Response
    {
        return Response::json($data, $status);
    }

    protected function redirect(string $url): Response
    {
        return Response::redirect($url);
    }

    protected function requireAuth(): void
    {
        if (!$this->auth->check()) {
            throw new \RuntimeException('Authentication required.', 401);
        }
    }

    protected function requireAdmin(): void
    {
        if (!$this->auth->isAdmin()) {
            throw new \RuntimeException('Admin access required.', 403);
        }
    }

    protected function validateCsrf(Request $request): void
    {
        $token = $request->input('_token') ?? $request->header('X-CSRF-Token', '');
        if (!$this->session->verifyToken($token)) {
            throw new \RuntimeException('CSRF token mismatch.', 403);
        }
    }
}
