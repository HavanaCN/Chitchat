<?php
namespace App\Core;

class Version
{
    protected string $basePath;
    protected array $version;

    public function __construct(string $basePath)
    {
        $this->basePath = rtrim($basePath, '/\\');
        $this->version = $this->load();
    }

    protected function load(): array
    {
        $defaults = [
            'name' => 'Chitchat',
            'version' => '0.0.0-dev',
            'tag' => 'v0.0.0-dev',
            'channel' => 'dev',
            'release_date' => null,
        ];

        $file = $this->basePath . '/version.php';
        if (!is_file($file)) {
            return $defaults;
        }

        $data = require $file;
        if (!is_array($data)) {
            return $defaults;
        }

        return array_merge($defaults, $data);
    }

    public function all(): array
    {
        return $this->version;
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->version[$key] ?? $default;
    }
}
