<?php
namespace App\Core;

use App\Helpers\Settings;

class SchemaManager
{
    protected static bool $synced = false;

    public static function sync(Database $db): void
    {
        if (self::$synced) {
            return;
        }

        self::$synced = true;

        try {
            self::ensureGroupDisplayName($db);
            self::ensureDiscussionFeatured($db);
            self::ensureEmailCodesTable($db);
            self::ensureSettingDefaults($db);
            self::ensureUncategorizedTag($db);
            self::cleanupHiddenDiscussionTags($db);
            self::attachUncategorizedTagToLegacyDiscussions($db);
            self::syncDefaultGroups($db);

        } catch (\Throwable $e) {
            // 安装未完成或旧环境不支持时静默跳过，避免阻塞站点访问。
        }
    }

    protected static function ensureGroupDisplayName(Database $db): void
    {
        if (!self::hasColumn($db, 'groups', 'display_name')) {
            $db->query('ALTER TABLE `groups` ADD COLUMN `display_name` VARCHAR(80) DEFAULT NULL AFTER `name`');
        }

        $db->query('UPDATE `groups` SET `display_name` = `name` WHERE `display_name` IS NULL OR TRIM(`display_name`) = ""');
    }

    protected static function ensureDiscussionFeatured(Database $db): void
    {
        if (!self::hasColumn($db, 'discussions', 'is_featured')) {
            $db->query('ALTER TABLE `discussions` ADD COLUMN `is_featured` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_locked`');
        }
    }

    protected static function ensureEmailCodesTable(Database $db): void
    {
        if (self::hasTable($db, 'email_codes')) {
            return;
        }

        $db->query(
            'CREATE TABLE `email_codes` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `email` VARCHAR(150) NOT NULL,
                `purpose` VARCHAR(50) NOT NULL,
                `code` VARCHAR(12) NOT NULL,
                `expires_at` DATETIME NOT NULL,
                `used_at` DATETIME DEFAULT NULL,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX `idx_email_purpose` (`email`, `purpose`),
                INDEX `idx_expires_at` (`expires_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }

    protected static function ensureSettingDefaults(Database $db): void
    {
        $defaults = [
            'smtp_enabled' => '0',
            'smtp_host' => '',
            'smtp_port' => '587',
            'smtp_user' => '',
            'smtp_pass' => '',
            'smtp_from' => '',
            'smtp_from_name' => '',
            'smtp_encryption' => 'tls',
        ];

        foreach (Settings::defaultMailTemplates() as $key => $value) {
            $defaults[$key] = $value;
        }

        foreach ($defaults as $key => $value) {
            $row = $db->selectOne('SELECT `key` FROM settings WHERE `key` = ? LIMIT 1', [$key]);
            if (!$row) {
                $db->query('INSERT INTO settings (`key`, `value`) VALUES (?, ?)', [$key, $value]);
            }
        }
    }

    protected static function ensureUncategorizedTag(Database $db): void
    {
        $tag = $db->selectOne('SELECT id FROM tags WHERE slug = ? LIMIT 1', ['uncategorized']);
        if ($tag) {
            return;
        }

        $db->table('tags')->insert([
            'name' => '未分类',
            'slug' => 'uncategorized',
            'description' => '未选择分类的讨论会自动归档到这里',
            'color' => '#64748b',
            'icon' => 'fa-inbox',
            'parent_id' => null,
            'position' => 999,
            'is_hidden' => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    protected static function cleanupHiddenDiscussionTags(Database $db): void
    {
        $db->query(
            'DELETE dt
             FROM discussion_tag dt
             INNER JOIN discussions d ON d.id = dt.discussion_id
             WHERE d.is_hidden = 1'
        );

        $db->query(
            'DELETE l
             FROM likes l
             INNER JOIN posts p ON p.id = l.post_id
             INNER JOIN discussions d ON d.id = p.discussion_id
             WHERE d.is_hidden = 1'
        );

        $db->query(
            'DELETE n
             FROM notifications n
             LEFT JOIN discussions d ON JSON_UNQUOTE(JSON_EXTRACT(n.data, "$.discussion_id")) = CAST(d.id AS CHAR)
             LEFT JOIN posts p ON JSON_UNQUOTE(JSON_EXTRACT(n.data, "$.post_id")) = CAST(p.id AS CHAR)
             LEFT JOIN discussions pd ON pd.id = p.discussion_id
             WHERE (d.id IS NOT NULL AND d.is_hidden = 1)
                OR (pd.id IS NOT NULL AND pd.is_hidden = 1)'
        );
    }


    protected static function attachUncategorizedTagToLegacyDiscussions(Database $db): void
    {
        $tag = $db->selectOne('SELECT id FROM tags WHERE slug = ? LIMIT 1', ['uncategorized']);
        if (!$tag) {
            return;
        }

        $db->query(
            'INSERT IGNORE INTO discussion_tag (discussion_id, tag_id)
             SELECT d.id, ?
             FROM discussions d
             LEFT JOIN discussion_tag dt ON dt.discussion_id = d.id
             WHERE d.is_hidden = 0 AND dt.discussion_id IS NULL',
            [(int)$tag['id']]
        );
    }

    protected static function syncDefaultGroups(Database $db): void

    {
        $defaults = [
            1 => [
                'name' => 'Administrators',
                'display_name' => '管理员',
                'permissions' => json_encode(['admin' => true, 'moderate' => true, 'post' => true, 'reply' => true], JSON_UNESCAPED_UNICODE),
            ],
            2 => [
                'name' => 'Moderators',
                'display_name' => '版主',
                'permissions' => json_encode(['moderate' => true, 'post' => true, 'reply' => true], JSON_UNESCAPED_UNICODE),
            ],
            3 => [
                'name' => 'Members',
                'display_name' => '会员',
                'permissions' => json_encode(['post' => true, 'reply' => true], JSON_UNESCAPED_UNICODE),
            ],
            4 => [
                'name' => 'Restricted',
                'display_name' => '受限用户',
                'permissions' => json_encode([], JSON_UNESCAPED_UNICODE),
            ],
        ];

        foreach ($defaults as $id => $payload) {
            $exists = $db->selectOne('SELECT id, display_name, permissions FROM `groups` WHERE id = ? LIMIT 1', [$id]);
            if (!$exists) {
                $db->table('groups')->insert([
                    'id' => $id,
                    'name' => $payload['name'],
                    'display_name' => $payload['display_name'],
                    'permissions' => $payload['permissions'],
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                continue;
            }

            if (trim((string)($exists['display_name'] ?? '')) === '') {
                $db->query('UPDATE `groups` SET `display_name` = ? WHERE id = ?', [$payload['display_name'], $id]);
            }

            if (trim((string)($exists['permissions'] ?? '')) === '') {
                $db->query('UPDATE `groups` SET `permissions` = ? WHERE id = ?', [$payload['permissions'], $id]);
            }
        }
    }

    protected static function hasTable(Database $db, string $table): bool
    {
        $row = $db->selectOne(
            'SELECT COUNT(*) AS cnt FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?',
            [$table]
        );

        return (int)($row['cnt'] ?? 0) > 0;
    }

    protected static function hasColumn(Database $db, string $table, string $column): bool
    {
        $row = $db->selectOne(
            'SELECT COUNT(*) AS cnt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
            [$table, $column]
        );

        return (int)($row['cnt'] ?? 0) > 0;
    }
}
