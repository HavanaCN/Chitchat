<?php
namespace App\Core;

abstract class BaseModel
{
    protected static string $table = '';
    protected static string $primaryKey = 'id';
    protected Database $db;

    public function __construct()
    {
        $this->db = Application::getInstance()->make('db');
    }

    protected static function db(): Database
    {
        return Application::getInstance()->make('db');
    }

    public static function find(int $id): ?array
    {
        return static::db()->selectOne(
            'SELECT * FROM ' . static::$table . ' WHERE ' . static::$primaryKey . ' = ?',
            [$id]
        );
    }

    public static function all(string $orderBy = 'id', string $dir = 'ASC'): array
    {
        return static::db()->select(
            'SELECT * FROM ' . static::$table . ' ORDER BY ' . $orderBy . ' ' . ($dir === 'DESC' ? 'DESC' : 'ASC')
        );
    }

    public static function create(array $data): int
    {
        return static::db()->table(static::$table)->insert($data);
    }

    public static function update(int $id, array $data): int
    {
        return static::db()->table(static::$table)
            ->where(static::$primaryKey, $id)
            ->update($data);
    }

    public static function delete(int $id): int
    {
        return static::db()->table(static::$table)
            ->where(static::$primaryKey, $id)
            ->delete();
    }

    public static function where(string $col, mixed $val): QueryBuilder
    {
        return static::db()->table(static::$table)->where($col, $val);
    }

    public static function query(): QueryBuilder
    {
        return static::db()->table(static::$table);
    }
}
