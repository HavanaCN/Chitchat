<?php
namespace App\Core;

use App\Helpers\Url;

class Response
{
    protected int $statusCode;
    protected array $headers;
    protected string $body;

    public function __construct(string $body = '', int $status = 200, array $headers = [])
    {
        $this->body       = $body;
        $this->statusCode = $status;
        $this->headers    = $headers;
    }

    public static function json(mixed $data, int $status = 200): static
    {
        $instance = new static(json_encode($data, JSON_UNESCAPED_UNICODE), $status, [
            'Content-Type' => 'application/json; charset=UTF-8',
        ]);
        return $instance;
    }

    public static function redirect(string $url, int $status = 302): static
    {
        return new static('', $status, ['Location' => Url::prependIfRelativeRoot($url)]);
    }


    public static function html(string $html, int $status = 200): static
    {
        return new static($html, $status, ['Content-Type' => 'text/html; charset=UTF-8']);
    }

    public function withHeader(string $name, string $value): static
    {
        $this->headers[$name] = $value;
        return $this;
    }

    public function send(): void
    {
        if (!headers_sent()) {
            http_response_code($this->statusCode);
            foreach ($this->headers as $name => $value) {
                header("{$name}: {$value}");
            }
        }
        echo $this->body;
    }
}
