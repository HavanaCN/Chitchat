<?php
namespace App\Core;

class Router
{
    protected array $routes = [];
    protected Container $container;
    protected string $prefix = '';
    protected array $middlewares = [];

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    public function get(string $path, array|callable $handler, array $middleware = []): void
    {
        $this->addRoute('GET', $path, $handler, $middleware);
    }

    public function post(string $path, array|callable $handler, array $middleware = []): void
    {
        $this->addRoute('POST', $path, $handler, $middleware);
    }

    public function put(string $path, array|callable $handler, array $middleware = []): void
    {
        $this->addRoute('PUT', $path, $handler, $middleware);
    }

    public function delete(string $path, array|callable $handler, array $middleware = []): void
    {
        $this->addRoute('DELETE', $path, $handler, $middleware);
    }

    public function group(array $options, callable $callback): void
    {
        $prevPrefix = $this->prefix;
        $prevMiddlewares = $this->middlewares;

        $this->prefix .= ($options['prefix'] ?? '');
        if (isset($options['middleware'])) {
            $this->middlewares = array_merge($this->middlewares, (array)$options['middleware']);
        }

        $callback($this);

        $this->prefix = $prevPrefix;
        $this->middlewares = $prevMiddlewares;
    }

    protected function addRoute(string $method, string $path, array|callable $handler, array $middleware = []): void
    {
        $fullPath = $this->prefix . $path;
        $fullMiddleware = array_merge($this->middlewares, $middleware);
        $this->routes[] = [
            'method'     => $method,
            'path'       => $fullPath,
            'pattern'    => $this->compilePattern($fullPath),
            'handler'    => $handler,
            'middleware' => $fullMiddleware,
        ];
    }

    protected function compilePattern(string $path): string
    {
        $pattern = preg_replace('/\{(\w+)\}/', '(?P<$1>[^/]+)', $path);
        return '#^' . $pattern . '$#';
    }

    public function dispatch(Request $request): Response
    {
        $method = $request->getMethod();
        $uri    = $request->getPath();

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) continue;
            if (!preg_match($route['pattern'], $uri, $matches)) continue;

            // Extract named params
            $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
            $request->setParams($params);

            // Run middleware chain
            return $this->runMiddleware($route['middleware'], $request, function () use ($route, $request) {
                return $this->callHandler($route['handler'], $request);
            });
        }

        throw new \RuntimeException("Route not found: {$method} {$uri}", 404);
    }

    protected function runMiddleware(array $middlewares, Request $request, callable $final): Response
    {
        if (empty($middlewares)) {
            return $final();
        }

        $middleware = array_shift($middlewares);
        $mw = new $middleware();
        return $mw->handle($request, function () use ($middlewares, $request, $final) {
            return $this->runMiddleware($middlewares, $request, $final);
        });
    }

    protected function callHandler(array|callable $handler, Request $request): Response
    {
        if (is_callable($handler)) {
            $result = $handler($request);
        } else {
            [$class, $method] = $handler;
            $controller = $this->container->make($class);
            $result = $controller->$method($request);
        }

        if ($result instanceof Response) {
            return $result;
        }

        return new Response((string)$result);
    }
}
