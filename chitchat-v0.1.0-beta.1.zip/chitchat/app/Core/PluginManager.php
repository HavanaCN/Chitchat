<?php
namespace App\Core;

class PluginManager
{
    protected string $pluginsPath;
    protected Container $container;
    protected EventDispatcher $events;
    protected array $active = [];

    public function __construct(string $pluginsPath, Container $container, EventDispatcher $events)
    {
        $this->pluginsPath = $pluginsPath;
        $this->container   = $container;
        $this->events      = $events;
    }

    public function loadActive(): void
    {
        try {
            $db = $this->container->make('db');
            $plugins = $db->select('SELECT * FROM plugins WHERE is_active = 1');
            foreach ($plugins as $plugin) {
                $this->bootPlugin($plugin['slug']);
            }
        } catch (\Exception $e) {
            // DB not ready (during install)
        }
    }

    protected function bootPlugin(string $slug): void
    {
        $bootstrap = $this->pluginsPath . '/' . $slug . '/bootstrap.php';
        if (!file_exists($bootstrap)) return;

        require_once $bootstrap;
        $class = $this->resolveBootstrapClass($slug);
        if (class_exists($class)) {
            $instance = new $class($this->container, $this->events);
            $instance->boot();
            $this->active[$slug] = $instance;
        }
    }

    protected function resolveBootstrapClass(string $slug): string
    {
        $parts = array_map('ucfirst', explode('-', $slug));
        return 'Plugins\\' . implode('', $parts) . '\\PluginBootstrap';
    }

    public function install(string $zipPath, string $slug): bool
    {
        $dest = $this->pluginsPath . '/' . $slug;
        if (!is_dir($dest)) mkdir($dest, 0755, true);

        $zip = new \ZipArchive();
        if ($zip->open($zipPath) !== true) return false;
        $zip->extractTo($dest);
        $zip->close();

        // Run migrations
        $this->runMigrations($slug);

        // Register in DB
        $meta = $this->getMeta($slug);
        $db = $this->container->make('db');
        $db->table('plugins')->insert([
            'slug'        => $slug,
            'name'        => $meta['name'] ?? $slug,
            'version'     => $meta['version'] ?? '1.0.0',
            'is_active'   => 0,
            'installed_at' => date('Y-m-d H:i:s'),
        ]);
        return true;
    }

    protected function runMigrations(string $slug): void
    {
        $migrationsPath = $this->pluginsPath . '/' . $slug . '/migrations';
        if (!is_dir($migrationsPath)) return;

        $db = $this->container->make('db');
        foreach (glob($migrationsPath . '/*.sql') as $file) {
            $sql = file_get_contents($file);
            try {
                $db->getPdo()->exec($sql);
                $db->table('migrations')->insert([
                    'plugin'      => $slug,
                    'version'     => basename($file, '.sql'),
                    'executed_at' => date('Y-m-d H:i:s'),
                ]);
            } catch (\Exception $e) {
                // Already applied
            }
        }
    }

    protected function getMeta(string $slug): array
    {
        $metaFile = $this->pluginsPath . '/' . $slug . '/plugin.json';
        if (!file_exists($metaFile)) return [];
        return json_decode(file_get_contents($metaFile), true) ?? [];
    }

    public function activate(string $slug): void
    {
        $db = $this->container->make('db');
        $db->table('plugins')->where('slug', $slug)->update(['is_active' => 1]);
        $this->bootPlugin($slug);
    }

    public function deactivate(string $slug): void
    {
        $db = $this->container->make('db');
        $db->table('plugins')->where('slug', $slug)->update(['is_active' => 0]);
        unset($this->active[$slug]);
    }
}
