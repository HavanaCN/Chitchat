<?php
namespace App\Core;

use App\Helpers\GroupPermission;

class Auth
{
    protected Database $db;
    protected Session $session;
    protected ?array $user = null;

    public function __construct(Database $db, Session $session)
    {
        $this->db      = $db;
        $this->session = $session;
    }

    public function attempt(string $login, string $password, bool $remember = false): bool
    {
        $login = trim($login);
        if ($login === '') {
            return false;
        }

        $query = 'SELECT * FROM users WHERE %s = ? AND (suspended_until IS NULL OR suspended_until < NOW()) LIMIT 1';
        $isEmail = (bool)filter_var($login, FILTER_VALIDATE_EMAIL);
        $user = $this->db->selectOne(sprintf($query, $isEmail ? 'email' : 'username'), [$login]);

        if (!$user && $isEmail) {
            $user = $this->db->selectOne(sprintf($query, 'username'), [$login]);
        }

        if (!$user || !password_verify($password, $user['password'])) {
            return false;
        }

        $this->login($user, $remember);
        return true;
    }

    public function login(array $user, bool $remember = false): void
    {
        $this->user = $user;
        $this->session->regenerate();
        $this->session->set('user_id', $user['id']);

        if ($remember) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
            $this->db->table('remember_tokens')->insert([
                'user_id'    => $user['id'],
                'token'      => hash('sha256', $token),
                'expires_at' => $expires,
            ]);
            setcookie('remember_token', $token, [
                'expires'  => strtotime('+30 days'),
                'path'     => '/',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
    }

    public function logout(): void
    {
        $this->user = null;
        $this->session->forget('user_id');
        $this->session->destroy();
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }
    }

    public function user(): ?array
    {
        if ($this->user) {
            return $this->user;
        }

        $userId = $this->session->get('user_id');
        if ($userId) {
            $this->user = $this->loadUser((int)$userId);
            return $this->user;
        }

        if (isset($_COOKIE['remember_token'])) {
            $tokenHash = hash('sha256', $_COOKIE['remember_token']);
            $token = $this->db->selectOne(
                'SELECT * FROM remember_tokens WHERE token = ? AND expires_at > NOW()',
                [$tokenHash]
            );
            if ($token) {
                $this->user = $this->loadUser((int)$token['user_id']);
                if ($this->user) {
                    $this->session->set('user_id', $this->user['id']);
                }
            }
        }

        return $this->user;
    }

    public function check(): bool
    {
        return $this->user() !== null;
    }

    public function id(): ?int
    {
        return $this->user()['id'] ?? null;
    }

    public function isAdmin(): bool
    {
        $user = $this->user();
        if (!$user) {
            return false;
        }

        return GroupPermission::has($user['group_permissions'] ?? null, 'admin') || (int)$user['group_id'] === 1;
    }

    public function can(string $permission): bool
    {
        $user = $this->user();
        if (!$user) {
            return false;
        }

        if ($this->isAdmin()) {
            return true;
        }

        return GroupPermission::has($user['group_permissions'] ?? null, $permission);
    }

    protected function loadUser(int $userId): ?array
    {
        return $this->db->selectOne(
            'SELECT u.*, g.name as group_name, g.display_name as group_display_name, g.permissions as group_permissions
             FROM users u
             LEFT JOIN groups g ON u.group_id = g.id
             WHERE u.id = ?',
            [$userId]
        );
    }
}

