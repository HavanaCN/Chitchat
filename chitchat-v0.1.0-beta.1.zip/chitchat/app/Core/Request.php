<?php
namespace App\Core;

class Request
{
    protected array $params = [];
    protected array $query;
    protected array $body;
    protected array $files;
    protected array $headers;
    protected string $method;
    protected string $uri;

    public function __construct()
    {
        $this->method  = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $this->uri     = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $this->query   = $_GET ?? [];
        $this->body    = $_POST ?? [];
        $this->files   = $_FILES ?? [];
        $this->headers = $this->parseHeaders();

        // JSON body
        $contentType = $this->header('Content-Type', '');
        if (str_contains($contentType, 'application/json')) {
            $json = json_decode(file_get_contents('php://input'), true);
            if (is_array($json)) {
                $this->body = array_merge($this->body, $json);
            }
        }

        // Handle PUT/DELETE via POST _method override
        if ($this->method === 'POST' && isset($this->body['_method'])) {
            $this->method = strtoupper($this->body['_method']);
        }
    }

    public static function capture(): static
    {
        return new static();
    }

    protected function parseHeaders(): array
    {
        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (str_starts_with($key, 'HTTP_')) {
                $name = str_replace('_', '-', substr($key, 5));
                $headers[strtolower($name)] = $value;
            }
        }
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $headers['content-type'] = $_SERVER['CONTENT_TYPE'];
        }
        return $headers;
    }

    public function getMethod(): string { return $this->method; }

    public function getPath(): string
    {
        $queryRoute = $this->query['route'] ?? null;
        if (is_string($queryRoute) && trim($queryRoute) !== '') {
            return $this->normalizePath($queryRoute);
        }

        $path = (string)$this->uri;
        $scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        $scriptDir = rtrim(dirname($scriptName), '/');

        if ($scriptName !== '' && str_starts_with($path, $scriptName)) {
            $path = substr($path, strlen($scriptName));
        } elseif ($scriptDir !== '' && $scriptDir !== '.' && str_starts_with($path, $scriptDir)) {
            $path = substr($path, strlen($scriptDir));
        }

        return $this->normalizePath($path);
    }

    protected function normalizePath(?string $path): string
    {
        $path = trim((string)$path);
        if ($path === '') {
            return '/';
        }

        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#^/?index\.php/?#', '', $path) ?? $path;
        $path = '/' . ltrim($path, '/');

        return $path === '/' ? '/' : rtrim($path, '/');
    }

    public function setParams(array $params): void { $this->params = $params; }

    public function param(string $key, mixed $default = null): mixed { return $this->params[$key] ?? $default; }
    public function query(string $key, mixed $default = null): mixed { return $this->query[$key] ?? $default; }
    public function input(string $key, mixed $default = null): mixed { return $this->body[$key] ?? $this->query[$key] ?? $default; }
    public function all(): array { return array_merge($this->query, $this->body); }
    public function file(string $key): ?array { return $this->files[$key] ?? null; }
    public function header(string $key, mixed $default = null): mixed { return $this->headers[strtolower($key)] ?? $default; }
    public function isAjax(): bool { return $this->header('X-Requested-With') === 'XMLHttpRequest'; }
    public function isJson(): bool { return str_contains($this->header('Accept', ''), 'application/json') || str_contains($this->header('Content-Type', ''), 'application/json'); }

    public function validate(array $rules): array
    {
        $errors = [];
        foreach ($rules as $field => $rule) {
            $value = $this->input($field);
            foreach (explode('|', $rule) as $r) {
                if ($r === 'required' && empty($value)) {
                    $errors[$field][] = "{$field} is required.";
                }
                if (str_starts_with($r, 'min:')) {
                    $min = (int)substr($r, 4);
                    if (strlen((string)$value) < $min) {
                        $errors[$field][] = "{$field} must be at least {$min} characters.";
                    }
                }
                if (str_starts_with($r, 'max:')) {
                    $max = (int)substr($r, 4);
                    if (strlen((string)$value) > $max) {
                        $errors[$field][] = "{$field} must not exceed {$max} characters.";
                    }
                }
                if ($r === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$field][] = "{$field} must be a valid email.";
                }
            }
        }
        return $errors;
    }
}
