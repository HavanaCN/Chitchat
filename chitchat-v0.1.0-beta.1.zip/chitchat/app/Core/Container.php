<?php
namespace App\Core;

class Container
{
    protected array $bindings = [];
    protected array $instances = [];

    public function bind(string $abstract, callable $factory): void
    {
        $this->bindings[$abstract] = ['factory' => $factory, 'singleton' => false];
    }

    public function singleton(string $abstract, callable $factory): void
    {
        $this->bindings[$abstract] = ['factory' => $factory, 'singleton' => true];
    }

    public function instance(string $abstract, mixed $instance): void
    {
        $this->instances[$abstract] = $instance;
    }

    public function make(string $abstract): mixed
    {
        if (isset($this->instances[$abstract])) {
            return $this->instances[$abstract];
        }

        if (isset($this->bindings[$abstract])) {
            $binding = $this->bindings[$abstract];
            $instance = ($binding['factory'])($this);
            if ($binding['singleton']) {
                $this->instances[$abstract] = $instance;
            }
            return $instance;
        }

        // Auto-resolve
        if (class_exists($abstract)) {
            return new $abstract();
        }

        throw new \RuntimeException("Cannot resolve [{$abstract}] from container.");
    }
}
