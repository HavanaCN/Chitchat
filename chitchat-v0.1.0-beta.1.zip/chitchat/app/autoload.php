<?php
/**
 * Chitchat Forum Autoloader
 * PSR-4 compatible class autoloader
 */

spl_autoload_register(function (string $class): void {
    // Map: Namespace prefix → base directory
    $prefixes = [
        'App\\Core\\'             => __DIR__ . '/Core/',
        'App\\Forum\\Controllers\\' => __DIR__ . '/Forum/Controllers/',
        'App\\Forum\\Models\\'    => __DIR__ . '/Forum/Models/',
        'App\\Admin\\Controllers\\' => __DIR__ . '/Admin/Controllers/',
        'App\\Api\\Controllers\\'  => __DIR__ . '/Api/Controllers/',
        'App\\Helpers\\'          => __DIR__ . '/Helpers/',
        'Plugins\\'               => dirname(__DIR__) . '/plugins/',
    ];

    foreach ($prefixes as $prefix => $baseDir) {
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) continue;

        $relative = str_replace('\\', '/', substr($class, $len));
        $file = $baseDir . $relative . '.php';

        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});
