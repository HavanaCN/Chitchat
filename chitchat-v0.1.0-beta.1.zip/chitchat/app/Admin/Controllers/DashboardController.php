<?php
namespace App\Admin\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;

class DashboardController extends BaseController
{
    public function index(Request $request): Response
    {
        $this->requireAdmin();

        $stats = [
            'users'       => (int)($this->db->selectOne('SELECT COUNT(*) as cnt FROM users')['cnt'] ?? 0),
            'discussions' => (int)($this->db->selectOne('SELECT COUNT(*) as cnt FROM discussions WHERE is_hidden = 0')['cnt'] ?? 0),
            'posts'       => (int)($this->db->selectOne('SELECT COUNT(*) as cnt FROM posts WHERE is_hidden = 0')['cnt'] ?? 0),
        ];

        $recentUsers = $this->db->select(
            'SELECT id, username, email, created_at FROM users ORDER BY created_at DESC LIMIT 10'
        );

        $recentDiscussions = $this->db->select(
            'SELECT d.id, d.title, u.username, d.created_at FROM discussions d LEFT JOIN users u ON d.user_id = u.id WHERE d.is_hidden = 0 ORDER BY d.created_at DESC LIMIT 10'
        );

        return $this->render('pages/admin/dashboard', [
            'stats'              => $stats,
            'recentUsers'        => $recentUsers,
            'recentDiscussions'  => $recentDiscussions,
        ]);
    }
}
