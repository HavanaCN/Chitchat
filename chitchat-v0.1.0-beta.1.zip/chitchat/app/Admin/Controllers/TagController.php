<?php
namespace App\Admin\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\Tag;

class TagController extends BaseController
{
    public function index(Request $request): Response
    {
        $this->requireAdmin();
        $tags = Tag::getTree();
        return $this->render('pages/admin/tags', ['tags' => $tags]);
    }

    public function store(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);

        $name  = htmlspecialchars($request->input('name', ''), ENT_QUOTES, 'UTF-8');
        $slug  = $request->input('slug') ?: $this->makeSlug($name);
        $desc  = htmlspecialchars($request->input('description', ''), ENT_QUOTES, 'UTF-8');
        $color = $request->input('color', '#0077cc');
        $parent = $request->input('parent_id') ? (int)$request->input('parent_id') : null;

        if (strlen($name) < 1) return $this->json(['error' => 'Name required'], 422);

        $id = $this->db->table('tags')->insert([
            'name'        => $name,
            'slug'        => $slug,
            'description' => $desc,
            'color'       => $color,
            'parent_id'   => $parent,
            'position'    => 0,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return $this->json(['success' => true, 'id' => $id]);
    }

    public function update(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);
        $id = (int)$request->param('id');

        $this->db->table('tags')->where('id', $id)->update([
            'name'        => htmlspecialchars($request->input('name', ''), ENT_QUOTES, 'UTF-8'),
            'slug'        => $request->input('slug', ''),
            'description' => htmlspecialchars($request->input('description', ''), ENT_QUOTES, 'UTF-8'),
            'color'       => $request->input('color', '#0077cc'),
            'parent_id'   => $request->input('parent_id') ? (int)$request->input('parent_id') : null,
        ]);

        return $this->json(['success' => true]);
    }

    public function destroy(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);
        $id = (int)$request->param('id');
        $tag = $this->db->selectOne('SELECT * FROM tags WHERE id = ? LIMIT 1', [$id]);
        if (!$tag) {
            return $this->json(['error' => '分类不存在'], 404);
        }
        if (GroupPermission::isProtectedTag($tag)) {
            return $this->json(['error' => '默认公告和未分类不能删除'], 422);
        }

        $this->db->delete('DELETE FROM discussion_tag WHERE tag_id = ?', [$id]);
        Tag::delete($id);
        return $this->json(['success' => true]);
    }

    protected function makeSlug(string $name): string
    {
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9\-]/', '-', $name));
        $slug = preg_replace('/-+/', '-', trim($slug, '-'));
        return $slug ?: 'tag-' . time();
    }
}
