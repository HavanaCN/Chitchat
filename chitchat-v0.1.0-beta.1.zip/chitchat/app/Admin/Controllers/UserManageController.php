<?php
namespace App\Admin\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\User;
use App\Helpers\GroupPermission;

class UserManageController extends BaseController
{
    public function index(Request $request): Response
    {
        $this->requireAdmin();

        $page = (int)$request->query('page', 1);
        $q = trim((string)$request->query('q', ''));

        if ($q !== '') {
            $like = '%' . $q . '%';
            $total = (int)($this->db->selectOne('SELECT COUNT(*) as cnt FROM users WHERE username LIKE ? OR email LIKE ?', [$like, $like])['cnt'] ?? 0);
            $users = $this->db->select(
                'SELECT u.*, g.name as group_name, g.display_name as group_display_name
                 FROM users u
                 LEFT JOIN groups g ON u.group_id = g.id
                 WHERE u.username LIKE ? OR u.email LIKE ?
                 ORDER BY u.id DESC
                 LIMIT 20 OFFSET ?',
                [$like, $like, ($page - 1) * 20]
            );
        } else {
            $total = (int)($this->db->selectOne('SELECT COUNT(*) as cnt FROM users')['cnt'] ?? 0);
            $users = $this->db->select(
                'SELECT u.*, g.name as group_name, g.display_name as group_display_name
                 FROM users u
                 LEFT JOIN groups g ON u.group_id = g.id
                 ORDER BY u.id DESC
                 LIMIT 20 OFFSET ?',
                [($page - 1) * 20]
            );
        }

        foreach ($users as &$user) {
            $user['group_label'] = GroupPermission::displayName($user, (string)($user['group_name'] ?? '用户组'));
        }
        unset($user);

        $groups = $this->db->select('SELECT * FROM groups ORDER BY id ASC');
        foreach ($groups as &$group) {
            $group['group_label'] = GroupPermission::displayName($group, (string)($group['name'] ?? '用户组'));
        }
        unset($group);

        return $this->render('pages/admin/users', [
            'users' => $users,
            'groups' => $groups,
            'total' => $total,
            'page' => $page,
            'lastPage' => (int)ceil($total / 20),
            'q' => $q,
        ]);
    }

    public function update(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        $data = [];
        if ($request->input('group_id')) {
            $data['group_id'] = (int)$request->input('group_id');
        }
        if ($request->input('suspended_until') !== null) {
            $data['suspended_until'] = $request->input('suspended_until') ?: null;
        }

        if ($data) {
            User::update($id, $data);
        }

        return $this->json(['success' => true]);
    }

    public function destroy(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        if ($id === $this->auth->id()) {
            return $this->json(['error' => 'Cannot delete yourself'], 422);
        }

        User::delete($id);
        return $this->json(['success' => true]);
    }
}
