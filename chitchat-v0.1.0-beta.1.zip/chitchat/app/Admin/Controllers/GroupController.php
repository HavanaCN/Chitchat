<?php
namespace App\Admin\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\Tag;
use App\Helpers\GroupPermission;
use App\Helpers\Url;

class GroupController extends BaseController
{
    public function index(Request $request): Response
    {
        $this->requireAdmin();

        $groups = $this->db->select('SELECT * FROM `groups` ORDER BY id ASC');
        foreach ($groups as &$group) {
            $permissions = GroupPermission::parse($group['permissions'] ?? null);
            $group['group_display_name'] = GroupPermission::displayName($group, (string)($group['name'] ?? '用户组'));
            $group['permissions_payload'] = $permissions;
            $group['post_tag_ids'] = array_values(array_filter(array_map('intval', $permissions['post_tag_ids'] ?? [])));
        }
        unset($group);

        $tags = Tag::all('position', 'ASC');

        return $this->render('pages/admin/groups', [
            'groups' => $groups,
            'tags' => $tags,
            'flashSuccess' => $this->session->getFlash('success'),
            'flashError' => $this->session->getFlash('error'),
        ]);
    }

    public function update(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        $group = $this->db->selectOne('SELECT * FROM `groups` WHERE id = ? LIMIT 1', [$id]);
        if (!$group) {
            $this->session->flash('error', '未找到要更新的用户组');
            return $this->redirect(Url::route('admin/groups'));
        }

        $name = trim((string)$request->input('name', ''));
        $displayName = trim((string)$request->input('display_name', ''));
        if ($name === '' || $displayName === '') {
            $this->session->flash('error', '用户组标识名和外显名称都不能为空');
            return $this->redirect(Url::route('admin/groups'));
        }

        $duplicate = $this->db->selectOne('SELECT id FROM `groups` WHERE name = ? AND id <> ? LIMIT 1', [$name, $id]);
        if ($duplicate) {
            $this->session->flash('error', '该用户组标识名已存在，请换一个');
            return $this->redirect(Url::route('admin/groups'));
        }

        $permissions = $this->buildPermissions($request);

        $this->db->table('groups')->where('id', $id)->update([
            'name' => $name,
            'display_name' => $displayName,
            'permissions' => json_encode($permissions, JSON_UNESCAPED_UNICODE),
            'color' => trim((string)$request->input('color', '#666666')) ?: '#666666',
            'icon' => trim((string)$request->input('icon', '')) ?: null,
        ]);

        $this->session->flash('success', '用户组设置已保存');
        return $this->redirect(Url::route('admin/groups'));
    }

    protected function buildPermissions(Request $request): array
    {
        $isAdmin = (bool)$request->input('perm_admin');
        $isModerate = (bool)$request->input('perm_moderate');
        $canPost = $isAdmin || $isModerate || (bool)$request->input('perm_post');
        $canReply = $isAdmin || $isModerate || (bool)$request->input('perm_reply');

        $permissions = [
            'admin' => $isAdmin,
            'moderate' => $isModerate,
            'post' => $canPost,
            'reply' => $canReply,
        ];

        foreach (['admin', 'moderate', 'post', 'reply'] as $key) {
            if (empty($permissions[$key])) {
                unset($permissions[$key]);
            }
        }

        return $permissions;

    }
}
