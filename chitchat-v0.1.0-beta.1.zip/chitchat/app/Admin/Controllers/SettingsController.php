<?php
namespace App\Admin\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Helpers\ForumIcon;
use App\Helpers\Url;

class SettingsController extends BaseController
{
    public function index(Request $request): Response
    {
        $this->requireAdmin();
        $settings = $this->loadSettings();

        return $this->render('pages/admin/settings', [
            'settings' => $settings,
            'timezoneGroups' => $this->getTimezoneGroups(),
            'iconPresets' => ForumIcon::presets(),
            'resolvedForumIcon' => ForumIcon::resolve($settings),
        ]);
    }

    public function update(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);

        $currentSettings = $this->loadSettings();
        $requestedTheme = trim((string)$request->input('theme', ''));
        $forumNameInput = $request->input('forum_name');
        $isThemeOnlyUpdate = $requestedTheme !== '' && ($forumNameInput === null || trim((string)$forumNameInput) === '');

        if ($isThemeOnlyUpdate) {
            return $this->updateThemeSelection($request, $requestedTheme);
        }

        $forumName = trim((string)$forumNameInput);
        if ($forumName === '') {
            return $this->json(['error' => '论坛名称不能为空'], 422);
        }
        if (mb_strlen($forumName, 'UTF-8') > 12) {
            return $this->json(['error' => '论坛名称不可超过12个汉字'], 422);
        }

        $timezone = trim((string)$request->input('timezone', 'Asia/Shanghai'));
        $validTimezones = \DateTimeZone::listIdentifiers();
        if (!in_array($timezone, $validTimezones, true)) {
            return $this->json(['error' => '请选择有效的时区'], 422);
        }

        $itemsPerPage = (int)$request->input('items_per_page', 20);
        if ($itemsPerPage < 5 || $itemsPerPage > 100) {
            return $this->json(['error' => '每页显示数量需在 5 到 100 之间'], 422);
        }

        $iconType = $request->input('forum_icon_type', 'preset') === 'upload' ? 'upload' : 'preset';
        $iconPreset = ForumIcon::normalizePreset((string)$request->input('forum_icon_preset', ForumIcon::defaultPreset()));
        $iconUpload = $this->handleForumIconUpload($request, $currentSettings);
        if (isset($iconUpload['error'])) {
            return $this->json(['error' => $iconUpload['error']], 422);
        }
        if ($iconType === 'upload' && empty($iconUpload['filename'])) {
            return $this->json(['error' => '请选择一个 64×64 的 PNG 论坛图标'], 422);
        }

        $settings = [
            'forum_name' => $forumName,
            'forum_description' => trim((string)$request->input('forum_description', '')),
            'allow_registration' => $request->input('allow_registration') ? '1' : '',
            'custom_css' => (string)$request->input('custom_css', ''),
            'timezone' => $timezone,
            'items_per_page' => (string)$itemsPerPage,
            'icp_filing' => trim((string)$request->input('icp_filing', '')),
            'forum_icon_type' => $iconType,
            'forum_icon_preset' => $iconPreset,
            'forum_icon_upload' => $iconUpload['filename'] ?? '',
        ];

        $forumUrl = $request->input('forum_url');
        if ($forumUrl !== null) {
            $settings['forum_url'] = trim((string)$forumUrl);
        }

        $theme = $request->input('theme');
        if ($theme !== null && trim((string)$theme) !== '') {
            $settings['theme'] = trim((string)$theme);
        }

        foreach ($settings as $key => $value) {
            $this->db->query(
                'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?',
                [$key, $value, $value]
            );
        }

        $configUpdates = ['timezone' => $timezone];
        if (!empty($settings['theme'])) {
            $configUpdates['theme'] = $settings['theme'];
        }
        $this->syncAppConfig($configUpdates);

        $resolvedIcon = ForumIcon::resolve($settings);

        return $this->json([
            'success' => true,
            'message' => '设置已保存',
            'icon_html' => ForumIcon::render($settings, 'icon-preview-box'),
            'icon_description' => $resolvedIcon['type'] === 'upload' ? '使用自定义 64×64 PNG 图标' : '使用 SVG 预设图标',
            'icon_type' => $resolvedIcon['type'],
            'icon_preset' => $settings['forum_icon_preset'],
            'icon_preset_label' => $resolvedIcon['type'] === 'preset'
                ? ($resolvedIcon['label'] ?? $settings['forum_icon_preset'])
                : (ForumIcon::presets()[$settings['forum_icon_preset']]['label'] ?? $settings['forum_icon_preset']),
            'icon_upload_filename' => $settings['forum_icon_upload'],
        ]);
    }

    public function plugins(Request $request): Response
    {
        $this->requireAdmin();
        $plugins = $this->db->select('SELECT * FROM plugins ORDER BY name ASC');
        return $this->render('pages/admin/plugins', ['plugins' => $plugins]);
    }

    public function activatePlugin(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);
        $slug = $request->param('slug');
        $this->app->make('plugins')->activate($slug);
        return $this->json(['success' => true]);
    }

    public function deactivatePlugin(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);
        $slug = $request->param('slug');
        $this->app->make('plugins')->deactivate($slug);
        return $this->json(['success' => true]);
    }

    public function uploadPlugin(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);
        $file = $request->file('plugin');
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            return $this->json(['error' => '上传失败'], 400);
        }

        $slug = pathinfo($file['name'], PATHINFO_FILENAME);
        $slug = preg_replace('/[^a-z0-9\-]/', '-', strtolower($slug));
        $destZip = STORAGE_PATH . '/uploads/' . $file['name'];
        if (!is_dir(dirname($destZip))) {
            mkdir(dirname($destZip), 0755, true);
        }
        move_uploaded_file($file['tmp_name'], $destZip);
        $this->app->make('plugins')->install($destZip, $slug);
        return $this->json(['success' => true]);
    }

    public function themes(Request $request): Response
    {
        $this->requireAdmin();
        $themesPath = CHITCHAT_ROOT . '/themes';
        $themes = [];
        foreach (glob($themesPath . '/*/config.json') as $configFile) {
            $meta = json_decode(file_get_contents($configFile), true) ?? [];
            $slug = basename(dirname($configFile));
            $themes[] = array_merge($meta, ['slug' => $slug]);
        }
        $currentTheme = $this->app->make('config')->get('app.theme', 'default');

        return $this->render('pages/admin/themes', [
            'themes' => $themes,
            'currentTheme' => $currentTheme,
            'flashSuccess' => $this->session->getFlash('success'),
            'flashError' => $this->session->getFlash('error'),
        ]);
    }

    protected function updateThemeSelection(Request $request, string $theme): Response
    {
        $availableThemes = [];
        foreach (glob(CHITCHAT_ROOT . '/themes/*/config.json') as $configFile) {
            $meta = json_decode(file_get_contents($configFile), true) ?? [];
            $slug = basename(dirname($configFile));
            $availableThemes[$slug] = array_merge($meta, ['slug' => $slug]);
        }

        if (!isset($availableThemes[$theme])) {
            if ($request->isAjax() || $request->isJson()) {
                return $this->json(['error' => '所选主题不存在或不可用'], 422);
            }

            $this->session->flash('error', '所选主题不存在或不可用');
            return $this->redirect(Url::route('admin/themes'));
        }

        $this->db->query(
            'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?',
            ['theme', $theme, $theme]
        );
        $this->syncAppConfig(['theme' => $theme]);

        $themeName = trim((string)($availableThemes[$theme]['name'] ?? $theme));
        $message = '主题已切换为“' . $themeName . '”';

        if ($request->isAjax() || $request->isJson()) {
            return $this->json([
                'success' => true,
                'message' => $message,
                'theme' => $theme,
            ]);
        }

        $this->session->flash('success', $message);
        return $this->redirect(Url::route('admin/themes'));
    }

    protected function loadSettings(): array
    {
        $rows = $this->db->select('SELECT `key`, `value` FROM settings');
        $settings = [];
        foreach ($rows as $row) {
            $settings[$row['key']] = $row['value'];
        }

        return $settings;
    }

    protected function handleForumIconUpload(Request $request, array $currentSettings): array
    {
        $file = $request->file('forum_icon_file');
        $existing = trim((string)($currentSettings['forum_icon_upload'] ?? ''));

        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return ['filename' => $existing];
        }
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            return ['error' => '上传论坛图标失败，请重新选择文件'];
        }
        if (($file['size'] ?? 0) > 1024 * 1024) {
            return ['error' => '论坛图标大小不能超过 1MB'];
        }

        $imageInfo = @getimagesize($file['tmp_name']);
        if (!$imageInfo || ($imageInfo[2] ?? null) !== IMAGETYPE_PNG) {
            return ['error' => '论坛图标只允许上传 PNG 图片'];
        }
        if ((int)($imageInfo[0] ?? 0) !== 64 || (int)($imageInfo[1] ?? 0) !== 64) {
            return ['error' => '论坛图标必须是 64×64 像素的 PNG 图片'];
        }

        $destDir = PUBLIC_PATH . '/uploads/forum-icons';
        if (!is_dir($destDir) && !mkdir($destDir, 0755, true)) {
            return ['error' => '创建论坛图标目录失败'];
        }

        $filename = 'forum_icon_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.png';
        $destPath = $destDir . '/' . $filename;
        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            return ['error' => '保存论坛图标失败，请稍后重试'];
        }

        if ($existing !== '' && $existing !== $filename) {
            $oldPath = $destDir . '/' . $existing;
            if (is_file($oldPath)) {
                @unlink($oldPath);
            }
        }

        return ['filename' => $filename];
    }

    protected function getTimezoneGroups(): array
    {
        $common = [
            'Asia/Shanghai',
            'Asia/Hong_Kong',
            'Asia/Taipei',
            'Asia/Tokyo',
            'Asia/Singapore',
            'UTC',
            'Europe/London',
            'America/New_York',
            'America/Los_Angeles',
        ];

        $grouped = ['常用' => $common];
        $commonLookup = array_flip($common);

        foreach (\DateTimeZone::listIdentifiers() as $timezone) {
            if (isset($commonLookup[$timezone])) {
                continue;
            }
            $parts = explode('/', $timezone, 2);
            $group = count($parts) === 2 ? $parts[0] : '其他';
            $grouped[$group][] = $timezone;
        }

        $preferredOrder = ['常用', 'Asia', 'Europe', 'America', 'Australia', 'Africa', 'Atlantic', 'Indian', 'Pacific', 'Antarctica', 'Arctic', '其他'];
        $sorted = [];
        foreach ($preferredOrder as $group) {
            if (isset($grouped[$group])) {
                $sorted[$group] = $grouped[$group];
                unset($grouped[$group]);
            }
        }
        foreach ($grouped as $group => $timezones) {
            $sorted[$group] = $timezones;
        }

        return $sorted;
    }

    protected function syncAppConfig(array $updates): void
    {
        $configPath = CONFIG_PATH . '/config.php';
        if (!file_exists($configPath)) {
            return;
        }

        $config = require $configPath;
        foreach ($updates as $key => $value) {
            if ($value === '' || $value === null) {
                continue;
            }
            $config['app'][$key] = $value;
        }

        file_put_contents($configPath, '<?php return ' . var_export($config, true) . ';');
    }
}
