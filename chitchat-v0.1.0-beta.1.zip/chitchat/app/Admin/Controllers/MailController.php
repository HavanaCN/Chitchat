<?php
namespace App\Admin\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Helpers\Mailer;
use App\Helpers\Settings;
use App\Helpers\Url;

class MailController extends BaseController
{
    public function index(Request $request): Response
    {
        $this->requireAdmin();

        $settings = Settings::all();
        foreach (Settings::defaultMailTemplates() as $key => $value) {
            if (!isset($settings[$key]) || trim((string)$settings[$key]) === '') {
                $settings[$key] = $value;
            }
        }

        $settings['smtp_port'] = $settings['smtp_port'] ?? '587';
        $settings['smtp_encryption'] = $settings['smtp_encryption'] ?? 'tls';

        $smtpToggleEnabled = Settings::isEnabled($settings['smtp_enabled'] ?? '');
        $smtpConfigured = Settings::isSmtpConfigured($settings);
        $smtpVerified = Settings::isSmtpVerified($settings);

        return $this->render('pages/admin/mail', [
            'settings' => $settings,
            'smtpStatus' => $this->buildSmtpStatusMeta($smtpToggleEnabled, $smtpConfigured, $smtpVerified),
            'smtpVerified' => $smtpVerified,
            'smtpLastTestedAt' => (string)($settings['smtp_last_tested_at'] ?? ''),
            'smtpLastTestRecipient' => (string)($settings['smtp_last_test_recipient'] ?? ''),
            'flashSuccess' => $this->session->getFlash('success'),
            'flashError' => $this->session->getFlash('error'),
        ]);
    }

    public function test(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);

        $current = Settings::all();
        $settings = $this->collectMailSettings($request, $current);
        $testEmail = trim((string)$request->input('smtp_test_email', ''));

        $errors = $this->validateSmtpSettings($settings);
        if (!filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
            $errors[] = '请填写有效的测试收件邮箱';
        }

        if ($errors) {
            return $this->json(['error' => implode('；', $errors)], 422);
        }

        try {
            $forumName = trim((string)($settings['forum_name'] ?? 'Chitchat')) ?: 'Chitchat';
            $testedAt = date('Y-m-d H:i:s');
            $subject = '【' . $forumName . '】SMTP 测试邮件';
            $body = "这是一封来自 {$forumName} 的 SMTP 测试邮件。\n\n如果你收到这封邮件，说明当前后台填写的 SMTP 服务器、认证信息与发件设置已经通过连接和发送验证。\n\n测试时间：{$testedAt}\n发件系统：{$forumName}";

            $mailer = new Mailer($settings);
            $mailer->send($testEmail, $subject, $body, '站点管理员');

            $this->session->set('admin.smtp_test', [
                'fingerprint' => Settings::smtpConfigFingerprint($settings),
                'tested_at' => $testedAt,
                'recipient' => $testEmail,
            ]);

            return $this->json([
                'success' => true,
                'message' => '测试邮件已成功发送到 ' . $testEmail . '，当前 SMTP 配置可以正常连接并发信。',
                'tested_at' => $testedAt,
            ]);
        } catch (\Throwable $e) {
            $this->session->forget('admin.smtp_test');
            return $this->json(['error' => $e->getMessage()], 422);
        }
    }

    public function update(Request $request): Response
    {
        $this->requireAdmin();
        $this->validateCsrf($request);

        $current = Settings::all();
        $settings = $this->collectMailSettings($request, $current);
        $smtpToggleEnabled = Settings::isEnabled($settings['smtp_enabled'] ?? '');

        if ($smtpToggleEnabled) {
            $errors = $this->validateSmtpSettings($settings);
            if ($errors) {
                $this->session->flash('error', implode('；', $errors));
                return $this->redirect(Url::route('admin/mail'));
            }

            $fingerprint = Settings::smtpConfigFingerprint($settings);
            $sessionTest = $this->session->get('admin.smtp_test', []);
            $savedFingerprint = trim((string)($current['smtp_last_test_fingerprint'] ?? ''));
            $verifiedBySavedConfig = $savedFingerprint !== '' && hash_equals($savedFingerprint, $fingerprint);
            $verifiedByCurrentSession = is_array($sessionTest)
                && !empty($sessionTest['fingerprint'])
                && hash_equals((string)$sessionTest['fingerprint'], $fingerprint);

            if (!$verifiedBySavedConfig && !$verifiedByCurrentSession) {
                $this->session->flash('error', '请先使用“发送测试邮件”验证当前 SMTP 配置，测试通过后才能保存启用状态。');
                return $this->redirect(Url::route('admin/mail'));
            }

            if ($verifiedByCurrentSession) {
                $settings['smtp_last_tested_at'] = (string)($sessionTest['tested_at'] ?? date('Y-m-d H:i:s'));
                $settings['smtp_last_test_recipient'] = (string)($sessionTest['recipient'] ?? '');
                $settings['smtp_last_test_fingerprint'] = $fingerprint;
            } else {
                $settings['smtp_last_tested_at'] = (string)($current['smtp_last_tested_at'] ?? '');
                $settings['smtp_last_test_recipient'] = (string)($current['smtp_last_test_recipient'] ?? '');
                $settings['smtp_last_test_fingerprint'] = $savedFingerprint;
            }
        } else {
            if (isset($current['smtp_last_tested_at'])) {
                $settings['smtp_last_tested_at'] = (string)$current['smtp_last_tested_at'];
            }
            if (isset($current['smtp_last_test_recipient'])) {
                $settings['smtp_last_test_recipient'] = (string)$current['smtp_last_test_recipient'];
            }
            if (isset($current['smtp_last_test_fingerprint'])) {
                $settings['smtp_last_test_fingerprint'] = (string)$current['smtp_last_test_fingerprint'];
            }
        }

        Settings::setMany($settings);
        $this->session->flash('success', $smtpToggleEnabled
            ? '邮件服务设置已保存，当前 SMTP 配置已经通过测试验证。'
            : '邮件服务设置已保存，邮件能力已保持关闭。');

        return $this->redirect(Url::route('admin/mail'));
    }

    protected function collectMailSettings(Request $request, array $current): array
    {
        $password = trim((string)$request->input('smtp_pass', ''));
        $encryption = trim((string)$request->input('smtp_encryption', 'tls'));
        if (!in_array($encryption, ['none', 'tls', 'ssl'], true)) {
            $encryption = 'tls';
        }

        return [
            'forum_name' => trim((string)($current['forum_name'] ?? 'Chitchat')),
            'smtp_enabled' => $request->input('smtp_enabled') ? '1' : '0',
            'smtp_host' => trim((string)$request->input('smtp_host', '')),
            'smtp_port' => (string)max(1, (int)$request->input('smtp_port', 587)),
            'smtp_user' => trim((string)$request->input('smtp_user', '')),
            'smtp_pass' => $password !== '' ? $password : (string)($current['smtp_pass'] ?? ''),
            'smtp_from' => trim((string)$request->input('smtp_from', '')),
            'smtp_from_name' => trim((string)$request->input('smtp_from_name', '')),
            'smtp_encryption' => $encryption,
            'mail_register_verify_subject' => trim((string)$request->input('mail_register_verify_subject', Settings::mailTemplate('mail_register_verify_subject', $current))),
            'mail_register_verify_body' => trim((string)$request->input('mail_register_verify_body', Settings::mailTemplate('mail_register_verify_body', $current))),
            'mail_reset_password_subject' => trim((string)$request->input('mail_reset_password_subject', Settings::mailTemplate('mail_reset_password_subject', $current))),
            'mail_reset_password_body' => trim((string)$request->input('mail_reset_password_body', Settings::mailTemplate('mail_reset_password_body', $current))),
        ];
    }

    protected function validateSmtpSettings(array $settings): array
    {
        $errors = [];

        if (trim((string)($settings['smtp_host'] ?? '')) === '') {
            $errors[] = '请填写 SMTP 服务器地址';
        }

        $port = (int)($settings['smtp_port'] ?? 0);
        if ($port <= 0 || $port > 65535) {
            $errors[] = '请填写有效的 SMTP 端口';
        }

        if (trim((string)($settings['smtp_user'] ?? '')) === '') {
            $errors[] = '请填写 SMTP 用户名';
        }

        $fromEmail = trim((string)($settings['smtp_from'] ?? ''));
        if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
            $errors[] = '请填写有效的发件人邮箱';
        }

        return $errors;
    }

    protected function buildSmtpStatusMeta(bool $toggleEnabled, bool $configured, bool $verified): array
    {
        if (!$toggleEnabled) {
            return [
                'label' => '已关闭',
                'class' => 'is-disabled',
                'description' => '邮件服务当前处于关闭状态，注册验证码和忘记密码功能不会对外开放。',
            ];
        }

        if (!$configured) {
            return [
                'label' => '配置未完成',
                'class' => 'is-pending',
                'description' => '请先补全 SMTP 服务器、端口、用户名和发件人邮箱，再进行测试。',
            ];
        }

        if (!$verified) {
            return [
                'label' => '待测试',
                'class' => 'is-pending',
                'description' => '当前配置尚未通过测试邮件验证，注册验证码和忘记密码功能暂不会启用。',
            ];
        }

        return [
            'label' => '已启用',
            'class' => 'is-enabled',
            'description' => '当前 SMTP 配置已经通过测试，可以正常用于注册验证码与密码找回。',
        ];
    }
}

