<?php
/**
 * Chitchat Routes
 */

use App\Core\Application;
use App\Forum\Controllers\HomeController;
use App\Forum\Controllers\DiscussionController;
use App\Forum\Controllers\PostController;
use App\Forum\Controllers\AuthController;
use App\Forum\Controllers\UserController;
use App\Admin\Controllers\DashboardController;
use App\Admin\Controllers\UserManageController;
use App\Admin\Controllers\TagController;
use App\Admin\Controllers\SettingsController;
use App\Admin\Controllers\GroupController;
use App\Admin\Controllers\MailController;

$app   = Application::getInstance();
$router = $app->make('router');

// Forum front-end routes
$router->get('/', [HomeController::class, 'index']);
$router->get('/search', [HomeController::class, 'search']);

// Auth
$router->get('/login', [AuthController::class, 'showLogin']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/register', [AuthController::class, 'showRegister']);
$router->post('/register', [AuthController::class, 'register']);
$router->post('/register/code', [AuthController::class, 'sendRegisterCode']);
$router->post('/password/forgot/code', [AuthController::class, 'sendResetPasswordCode']);
$router->post('/password/reset', [AuthController::class, 'resetPassword']);
$router->post('/logout', [AuthController::class, 'logout']);
$router->get('/notifications', [AuthController::class, 'notifications']);
$router->get('/notifications/count', [AuthController::class, 'notificationCount']);

// Discussions
$router->get('/d/{id}', [DiscussionController::class, 'show']);
$router->get('/new-discussion', [DiscussionController::class, 'create']);
$router->post('/discussions', [DiscussionController::class, 'store']);
$router->get('/d/{id}/edit', [DiscussionController::class, 'edit']);
$router->post('/d/{id}/update', [DiscussionController::class, 'update']);
$router->post('/d/{id}/delete', [DiscussionController::class, 'destroy']);
$router->post('/d/{id}/sticky', [DiscussionController::class, 'toggleSticky']);
$router->post('/d/{id}/featured', [DiscussionController::class, 'toggleFeatured']);
$router->post('/d/{id}/lock', [DiscussionController::class, 'toggleLock']);

// Posts
$router->post('/d/{id}/posts', [PostController::class, 'store']);
$router->post('/posts/{postId}/update', [PostController::class, 'update']);
$router->post('/posts/{postId}/delete', [PostController::class, 'destroy']);
$router->post('/posts/{postId}/like', [PostController::class, 'like']);
$router->post('/uploads/editor-image', [PostController::class, 'uploadEditorImage']);

// Users
$router->get('/u/{username}', [UserController::class, 'profile']);
$router->get('/settings', [UserController::class, 'editProfile']);
$router->post('/settings/update', [UserController::class, 'updateProfile']);

// Admin
$router->get('/admin', [DashboardController::class, 'index']);
$router->get('/admin/users', [UserManageController::class, 'index']);
$router->post('/admin/users/{id}', [UserManageController::class, 'update']);
$router->post('/admin/users/{id}/delete', [UserManageController::class, 'destroy']);
$router->get('/admin/groups', [GroupController::class, 'index']);
$router->post('/admin/groups/{id}', [GroupController::class, 'update']);
$router->get('/admin/tags', [TagController::class, 'index']);
$router->post('/admin/tags', [TagController::class, 'store']);
$router->post('/admin/tags/{id}/update', [TagController::class, 'update']);
$router->post('/admin/tags/{id}/delete', [TagController::class, 'destroy']);
$router->get('/admin/settings', [SettingsController::class, 'index']);
$router->post('/admin/settings', [SettingsController::class, 'update']);
$router->get('/admin/mail', [MailController::class, 'index']);
$router->post('/admin/mail', [MailController::class, 'update']);
$router->post('/admin/mail/test', [MailController::class, 'test']);

$router->get('/admin/plugins', [SettingsController::class, 'plugins']);
$router->post('/admin/plugins/{slug}/activate', [SettingsController::class, 'activatePlugin']);
$router->post('/admin/plugins/{slug}/deactivate', [SettingsController::class, 'deactivatePlugin']);
$router->post('/admin/plugins/upload', [SettingsController::class, 'uploadPlugin']);
$router->get('/admin/themes', [SettingsController::class, 'themes']);

