<?php
namespace App\Helpers;

class Mailer
{
    protected array $settings;
    protected $socket = null;
    protected int $timeout = 15;

    public function __construct(array $settings)
    {
        $this->settings = $settings;
    }

    public function send(string $toEmail, string $subject, string $body, ?string $toName = null): void
    {
        $host = trim((string)($this->settings['smtp_host'] ?? ''));
        $port = (int)($this->settings['smtp_port'] ?? 587);
        $user = trim((string)($this->settings['smtp_user'] ?? ''));
        $pass = (string)($this->settings['smtp_pass'] ?? '');
        $from = trim((string)($this->settings['smtp_from'] ?? ''));
        $fromName = trim((string)($this->settings['smtp_from_name'] ?? ($this->settings['forum_name'] ?? 'Chitchat')));
        $encryption = strtolower(trim((string)($this->settings['smtp_encryption'] ?? 'tls')));

        if ($host === '' || $port <= 0 || $user === '' || $from === '') {
            throw new \RuntimeException('SMTP 配置不完整，无法发送邮件。');
        }

        $remoteHost = $encryption === 'ssl' ? 'ssl://' . $host : $host;
        $this->socket = @stream_socket_client($remoteHost . ':' . $port, $errno, $errstr, $this->timeout, STREAM_CLIENT_CONNECT);
        if (!$this->socket) {
            throw new \RuntimeException('SMTP 连接失败：' . $errstr . ' (' . $errno . ')');
        }

        stream_set_timeout($this->socket, $this->timeout);

        try {
            $this->expect([220]);
            $this->command('EHLO localhost', [250]);

            if ($encryption === 'tls') {
                $this->command('STARTTLS', [220]);
                if (!stream_socket_enable_crypto($this->socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    throw new \RuntimeException('SMTP TLS 握手失败。');
                }
                $this->command('EHLO localhost', [250]);
            }

            if ($user !== '') {
                $this->command('AUTH LOGIN', [334]);
                $this->command(base64_encode($user), [334]);
                $this->command(base64_encode($pass), [235]);
            }

            $this->command('MAIL FROM:<' . $from . '>', [250]);
            $this->command('RCPT TO:<' . $toEmail . '>', [250, 251]);
            $this->command('DATA', [354]);

            $headers = [
                'Date: ' . date('r'),
                'From: ' . $this->formatAddress($from, $fromName),
                'To: ' . $this->formatAddress($toEmail, $toName ?: $toEmail),
                'Subject: ' . $this->encodeHeader($subject),
                'MIME-Version: 1.0',
                'Content-Type: text/plain; charset=UTF-8',
                'Content-Transfer-Encoding: base64',
            ];

            $message = implode("\r\n", $headers)
                . "\r\n\r\n"
                . chunk_split(base64_encode(str_replace(["\r\n", "\r"], "\n", $body)));

            $this->write($this->escapeMessage($message) . "\r\n.\r\n");
            $this->expect([250]);
            $this->command('QUIT', [221]);
        } finally {
            if (is_resource($this->socket)) {
                fclose($this->socket);
            }
            $this->socket = null;
        }
    }

    protected function command(string $command, array $expectCodes): string
    {
        $this->write($command . "\r\n");
        return $this->expect($expectCodes);
    }

    protected function expect(array $expectCodes): string
    {
        $response = '';
        while (($line = fgets($this->socket, 515)) !== false) {
            $response .= $line;
            if (preg_match('/^\d{3} /', $line)) {
                break;
            }
        }

        if ($response === '') {
            throw new \RuntimeException('SMTP 无响应。');
        }

        $code = (int)substr($response, 0, 3);
        if (!in_array($code, $expectCodes, true)) {
            throw new \RuntimeException('SMTP 响应异常：' . trim($response));
        }

        return $response;
    }

    protected function write(string $content): void
    {
        if (!is_resource($this->socket) || fwrite($this->socket, $content) === false) {
            throw new \RuntimeException('SMTP 写入失败。');
        }
    }

    protected function encodeHeader(string $value): string
    {
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }

    protected function formatAddress(string $email, string $name): string
    {
        $name = trim($name);
        if ($name === '') {
            return '<' . $email . '>';
        }

        return $this->encodeHeader($name) . ' <' . $email . '>';
    }

    protected function escapeMessage(string $message): string
    {
        $lines = preg_split('/\r\n|\r|\n/', $message) ?: [];
        foreach ($lines as &$line) {
            if (str_starts_with($line, '.')) {
                $line = '.' . $line;
            }
        }

        return implode("\r\n", $lines);
    }
}
