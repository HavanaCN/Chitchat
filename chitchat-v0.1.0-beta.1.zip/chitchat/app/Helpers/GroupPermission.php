<?php
namespace App\Helpers;

class GroupPermission
{
    public static function parse(array|string|null $raw): array
    {
        if (is_array($raw)) {
            return $raw;
        }

        if (!is_string($raw) || trim($raw) === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    public static function has(array|string|null $raw, string $permission): bool
    {
        $permissions = self::parse($raw);
        return !empty($permissions[$permission]);
    }

    public static function displayName(array $payload, string $default = '成员'): string
    {
        $name = trim((string)($payload['group_display_name'] ?? $payload['display_name'] ?? $payload['group_name'] ?? $payload['name'] ?? ''));
        return $name !== '' ? $name : $default;
    }

    public static function canManageAnnouncements(array $groupOrUser): bool
    {
        $permissions = self::parse($groupOrUser['group_permissions'] ?? $groupOrUser['permissions'] ?? null);
        $groupId = (int)($groupOrUser['group_id'] ?? 0);

        return !empty($permissions['admin'])
            || !empty($permissions['moderate'])
            || in_array($groupId, [1, 2], true);
    }

    public static function canStartDiscussion(array $groupOrUser): bool
    {
        return self::has($groupOrUser['group_permissions'] ?? $groupOrUser['permissions'] ?? null, 'post')
            || self::canManageAnnouncements($groupOrUser);
    }

    public static function canPostToSelectedTags(array $groupOrUser, array $selectedTagIds, array $allTags): bool
    {
        $selectedTagIds = array_values(array_unique(array_filter(array_map('intval', $selectedTagIds), static fn ($id) => $id > 0)));
        if ($selectedTagIds === []) {
            return self::canStartDiscussion($groupOrUser);
        }


        $flatTags = self::flattenTree($allTags);
        $tagsById = [];
        foreach ($flatTags as $tag) {
            $tagsById[(int)$tag['id']] = $tag;
        }

        foreach ($selectedTagIds as $tagId) {
            $tag = $tagsById[$tagId] ?? null;
            if ($tag && self::isAnnouncementTag($tag) && !self::canManageAnnouncements($groupOrUser)) {
                return false;
            }
        }

        return true;
    }

    public static function filterTreeForPosting(array $tree, array $groupOrUser): array
    {
        $filtered = [];
        foreach ($tree as $tag) {
            if (self::isUncategorizedTag($tag)) {
                continue;
            }

            if (self::isAnnouncementTag($tag) && !self::canManageAnnouncements($groupOrUser)) {
                continue;
            }

            if (!empty($tag['children'])) {
                $tag['children'] = self::filterTreeForPosting($tag['children'], $groupOrUser);
            }

            $filtered[] = $tag;
        }

        return $filtered;
    }

    public static function flattenTree(array $tree): array
    {
        $flat = [];
        foreach ($tree as $tag) {
            $children = $tag['children'] ?? [];
            $tag['children'] = [];
            $flat[] = $tag;
            if ($children) {
                $flat = array_merge($flat, self::flattenTree($children));
            }
        }

        return $flat;
    }

    public static function isAnnouncementTag(array $tag): bool
    {
        $slug = strtolower(trim((string)($tag['slug'] ?? '')));
        $name = trim((string)($tag['name'] ?? ''));

        return $slug === 'announcements' || $slug === 'announcement' || str_contains($name, '公告');
    }

    public static function isUncategorizedTag(array $tag): bool
    {
        $slug = strtolower(trim((string)($tag['slug'] ?? '')));
        return $slug === 'uncategorized';
    }

    public static function isProtectedTag(array $tag): bool
    {
        return self::isAnnouncementTag($tag) || self::isUncategorizedTag($tag);
    }
}
