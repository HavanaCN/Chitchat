<?php
namespace App\Helpers;

class Helper
{
    /**
     * Format relative time (in Chinese)
     */
    public static function timeAgo(?string $datetime): string
    {
        if (!$datetime) return '';
        $diff = time() - strtotime($datetime);
        if ($diff < 60)       return '刚刚';
        if ($diff < 3600)     return floor($diff / 60) . ' 分钟前';
        if ($diff < 86400)    return floor($diff / 3600) . ' 小时前';
        if ($diff < 2592000)  return floor($diff / 86400) . ' 天前';
        if ($diff < 31536000) return floor($diff / 2592000) . ' 个月前';
        return floor($diff / 31536000) . ' 年前';
    }

    /**
     * Built-in forum icon presets.
     */
    public static function getForumIconPresets(): array
    {
        return [
            'chat-bubble' => [
                'label' => '轻聊气泡',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="8" y="10" width="48" height="34" rx="16" fill="currentColor" opacity="0.14"/><path d="M18 23C18 18.5817 21.5817 15 26 15H38C42.4183 15 46 18.5817 46 23V31C46 35.4183 42.4183 39 38 39H30.5L22 46V39H26C21.5817 39 18 35.4183 18 31V23Z" fill="currentColor"/></svg>',
            ],
            'double-chat' => [
                'label' => '双层对话',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 16H40C45.5228 16 50 20.4772 50 26V28C50 33.5228 45.5228 38 40 38H37L28 45V38H18C12.4772 38 8 33.5228 8 28V26C8 20.4772 12.4772 16 18 16Z" fill="currentColor" opacity="0.18"/><path d="M24 22H46C51.5228 22 56 26.4772 56 32V34C56 39.5228 51.5228 44 46 44H36L28 51V44H24C18.4772 44 14 39.5228 14 34V32C14 26.4772 18.4772 22 24 22Z" fill="currentColor"/></svg>',
            ],
            'spark-bubble' => [
                'label' => '灵感火花',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M32 10L34.9389 18.0611L43 21L34.9389 23.9389L32 32L29.0611 23.9389L21 21L29.0611 18.0611L32 10Z" fill="currentColor"/><path d="M17 27C17 21.4772 21.4772 17 27 17H41C46.5228 17 51 21.4772 51 27V30C51 35.5228 46.5228 40 41 40H33L24 48V40H27C21.4772 40 17 35.5228 17 30V27Z" fill="currentColor" opacity="0.2"/><path d="M17 27C17 21.4772 21.4772 17 27 17H41C46.5228 17 51 21.4772 51 27V30C51 35.5228 46.5228 40 41 40H33L24 48V40H27C21.4772 40 17 35.5228 17 30V27Z" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/></svg>',
            ],
            'orbit' => [
                'label' => '交流星环',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="32" cy="32" r="9" fill="currentColor"/><ellipse cx="32" cy="32" rx="22" ry="11" stroke="currentColor" stroke-width="3"/><ellipse cx="32" cy="32" rx="22" ry="11" transform="rotate(60 32 32)" stroke="currentColor" stroke-width="3" opacity="0.75"/><circle cx="52" cy="33" r="3" fill="currentColor"/><circle cx="22" cy="14" r="2.5" fill="currentColor" opacity="0.8"/></svg>',
            ],
            'shield-chat' => [
                'label' => '守护社区',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M32 10L48 16V28C48 38.5 41.4 47.9 32 52C22.6 47.9 16 38.5 16 28V16L32 10Z" fill="currentColor" opacity="0.16"/><path d="M24 25C24 22.7909 25.7909 21 28 21H36C38.2091 21 40 22.7909 40 25V28C40 30.2091 38.2091 32 36 32H33L27 37V32C25.3431 32 24 30.6569 24 29V25Z" fill="currentColor"/><path d="M32 10L48 16V28C48 38.5 41.4 47.9 32 52C22.6 47.9 16 38.5 16 28V16L32 10Z" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/></svg>',
            ],
            'paper-plane' => [
                'label' => '纸飞机',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M54 12L28 38" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M54 12L36 52L28 38L14 30L54 12Z" fill="currentColor" opacity="0.18" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><path d="M28 38L24 48" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>',
            ],
            'beacon' => [
                'label' => '信标节点',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="32" cy="32" r="7" fill="currentColor"/><circle cx="32" cy="32" r="16" stroke="currentColor" stroke-width="3" opacity="0.55"/><circle cx="32" cy="32" r="25" stroke="currentColor" stroke-width="3" opacity="0.28"/><path d="M32 9V15" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M32 49V55" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M9 32H15" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M49 32H55" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>',
            ],
        ];
    }

    public static function getForumIconPreset(string $key): array
    {
        $presets = self::getForumIconPresets();
        return $presets[$key] ?? $presets['chat-bubble'];
    }

    public static function renderForumIcon(array $forum, string $class = 'forum-logo-mark'): string
    {
        $classAttr = htmlspecialchars($class, ENT_QUOTES, 'UTF-8');
        $type = $forum['forum_icon_type'] ?? 'preset';

        if ($type === 'upload' && !empty($forum['forum_icon_upload'])) {
            $filename = basename((string)$forum['forum_icon_upload']);
            $src = Url::path('uploads/forum-icons/' . rawurlencode($filename));
            return '<span class="' . $classAttr . ' forum-icon is-image"><img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="论坛图标" width="32" height="32"></span>';
        }


        $preset = self::getForumIconPreset((string)($forum['forum_icon_preset'] ?? 'chat-bubble'));
        return '<span class="' . $classAttr . ' forum-icon is-svg" aria-hidden="true">' . $preset['svg'] . '</span>';
    }

    /**
     * Simple Markdown to HTML
     */

    public static function markdown(string $text): string
    {
        $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
        // Fenced code blocks
        $text = preg_replace_callback('/```(\w*)\n([\s\S]*?)```/m', function ($m) {
            return '<pre><code class="language-' . $m[1] . '">' . $m[2] . '</code></pre>';
        }, $text);
        // Inline code
        $text = preg_replace('/`([^`]+)`/', '<code>$1</code>', $text);
        // Headers
        $text = preg_replace('/^### (.+)$/m', '<h3>$1</h3>', $text);
        $text = preg_replace('/^## (.+)$/m', '<h2>$1</h2>', $text);
        $text = preg_replace('/^# (.+)$/m', '<h1>$1</h1>', $text);
        // Bold / Italic
        $text = preg_replace('/\*\*\*(.+?)\*\*\*/', '<strong><em>$1</em></strong>', $text);
        $text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text);
        $text = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $text);
        // Blockquote
        $text = preg_replace('/^&gt; (.+)$/m', '<blockquote>$1</blockquote>', $text);
        // Links & Images
        $text = preg_replace('/!\[([^\]]*)\]\(([^)]+)\)/', '<img src="$2" alt="$1" class="post-image">', $text);
        $text = preg_replace('/\[([^\]]+)\]\(([^)]+)\)/', '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>', $text);
        // HR
        $text = preg_replace('/^---$/m', '<hr>', $text);
        // @mentions
        $text = preg_replace_callback('/@(\w+)/', static function ($matches) {
            $username = $matches[1];
            $url = Url::route('u/' . rawurlencode($username));

            return '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" class="mention">@' . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . '</a>';
        }, $text);

        // Line breaks
        $text = nl2br($text);
        return $text;
    }

    /**
     * Slugify a string
     */
    public static function slug(string $text): string
    {
        // Transliterate common Chinese characters (simplified approach)
        $text = strtolower(trim($text));
        $text = preg_replace('/[^\w\s\-]/', '', $text);
        $text = preg_replace('/[\s\-]+/', '-', $text);
        return trim($text, '-') ?: 'item-' . time();
    }

    /**
     * Truncate text preserving words
     */
    public static function truncate(string $text, int $length = 100): string
    {
        $text = strip_tags($text);
        if (mb_strlen($text) <= $length) return $text;
        return mb_substr($text, 0, $length) . '...';
    }

    /**
     * Format number (with K/M suffix)
     */
    public static function formatNumber(int $n): string
    {
        if ($n >= 1000000) return round($n / 1000000, 1) . 'M';
        if ($n >= 1000)    return round($n / 1000, 1) . 'K';
        return (string)$n;
    }
}
