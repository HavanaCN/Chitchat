<?php
namespace App\Helpers;

use App\Core\Application;

class Settings
{
    public static function all(): array
    {
        try {
            $db = Application::getInstance()->make('db');
            $rows = $db->select('SELECT `key`, `value` FROM settings');
            $settings = [];
            foreach ($rows as $row) {
                $settings[$row['key']] = $row['value'];
            }
            return $settings;
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function setMany(array $settings): void
    {
        $db = Application::getInstance()->make('db');
        foreach ($settings as $key => $value) {
            $db->query(
                'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?',
                [$key, $value, $value]
            );
        }
    }

    public static function isEnabled(mixed $value): bool
    {
        return !empty($value) && $value !== '0' && $value !== 0 && $value !== false;
    }

    public static function isSmtpConfigured(?array $settings = null): bool
    {
        $settings = $settings ?? self::all();

        return trim((string)($settings['smtp_host'] ?? '')) !== ''
            && trim((string)($settings['smtp_port'] ?? '')) !== ''
            && trim((string)($settings['smtp_user'] ?? '')) !== ''
            && trim((string)($settings['smtp_from'] ?? '')) !== '';
    }

    public static function smtpConfigFingerprint(?array $settings = null): string
    {
        $settings = $settings ?? self::all();

        $payload = [
            'smtp_host' => strtolower(trim((string)($settings['smtp_host'] ?? ''))),
            'smtp_port' => (string)((int)($settings['smtp_port'] ?? 0)),
            'smtp_user' => trim((string)($settings['smtp_user'] ?? '')),
            'smtp_pass' => (string)($settings['smtp_pass'] ?? ''),
            'smtp_from' => strtolower(trim((string)($settings['smtp_from'] ?? ''))),
            'smtp_encryption' => strtolower(trim((string)($settings['smtp_encryption'] ?? 'tls'))),
        ];

        return hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public static function isSmtpVerified(?array $settings = null): bool
    {
        $settings = $settings ?? self::all();
        if (!self::isSmtpConfigured($settings)) {
            return false;
        }

        $fingerprint = trim((string)($settings['smtp_last_test_fingerprint'] ?? ''));
        return $fingerprint !== '' && hash_equals($fingerprint, self::smtpConfigFingerprint($settings));
    }

    public static function isSmtpEnabled(?array $settings = null): bool
    {
        $settings = $settings ?? self::all();

        return self::isEnabled($settings['smtp_enabled'] ?? '')
            && self::isSmtpConfigured($settings)
            && self::isSmtpVerified($settings);
    }


    public static function defaultMailTemplates(): array
    {
        return [
            'mail_register_verify_subject' => '【{{forum_name}}】注册验证码',
            'mail_register_verify_body' => "你好 {{username}}：\n\n欢迎注册 {{forum_name}}。\n你的邮箱验证码是：{{code}}\n\n该验证码将在 {{expires_minutes}} 分钟后失效，请尽快完成验证。\n\n如果这不是你的操作，请忽略本邮件。\n\n{{forum_name}}\n{{site_url}}",
            'mail_reset_password_subject' => '【{{forum_name}}】密码重置验证码',
            'mail_reset_password_body' => "你好 {{username}}：\n\n你正在为 {{forum_name}} 重置登录密码。\n本次密码重置验证码是：{{code}}\n\n该验证码将在 {{expires_minutes}} 分钟后失效。若并非你本人操作，请尽快联系站点管理员。\n\n{{forum_name}}\n{{site_url}}",
        ];
    }

    public static function mailTemplate(string $key, ?array $settings = null): string
    {
        $settings = $settings ?? self::all();
        $defaults = self::defaultMailTemplates();

        return (string)($settings[$key] ?? $defaults[$key] ?? '');
    }

    public static function renderTemplate(string $template, array $variables = []): string
    {
        $replacements = [];
        foreach ($variables as $key => $value) {
            $replacements['{{' . $key . '}}'] = (string)$value;
        }

        return strtr($template, $replacements);
    }
}
