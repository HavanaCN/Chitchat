<?php
namespace App\Helpers;

use App\Core\Application;

class EmailCode
{
    public static function issue(string $email, string $purpose, int $expiresMinutes = 10): array
    {
        $email = trim(strtolower($email));
        if ($email === '') {
            throw new \RuntimeException('邮箱地址不能为空');
        }

        $db = Application::getInstance()->make('db');
        self::ensureRequestInterval($email, $purpose, 60);

        $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expiresAt = date('Y-m-d H:i:s', strtotime('+' . $expiresMinutes . ' minutes'));

        $db->query('UPDATE email_codes SET used_at = NOW() WHERE email = ? AND purpose = ? AND used_at IS NULL', [$email, $purpose]);
        $id = $db->table('email_codes')->insert([
            'email' => $email,
            'purpose' => $purpose,
            'code' => $code,
            'expires_at' => $expiresAt,
            'used_at' => null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return [
            'id' => $id,
            'email' => $email,
            'purpose' => $purpose,
            'code' => $code,
            'expires_minutes' => $expiresMinutes,
            'expires_at' => $expiresAt,
        ];
    }

    public static function consume(string $email, string $purpose, string $code): bool
    {
        $db = Application::getInstance()->make('db');
        $record = self::findValidRecord($email, $purpose, $code);
        if (!$record) {
            return false;
        }

        $db->query('UPDATE email_codes SET used_at = NOW() WHERE id = ? AND used_at IS NULL', [(int)$record['id']]);
        return true;
    }

    public static function ensureRequestInterval(string $email, string $purpose, int $seconds = 60): void
    {
        $db = Application::getInstance()->make('db');
        $latest = $db->selectOne(
            'SELECT created_at FROM email_codes WHERE email = ? AND purpose = ? ORDER BY id DESC LIMIT 1',
            [trim(strtolower($email)), $purpose]
        );

        if (!$latest || empty($latest['created_at'])) {
            return;
        }

        $remaining = $seconds - (time() - strtotime((string)$latest['created_at']));
        if ($remaining > 0) {
            throw new \RuntimeException('验证码发送过于频繁，请在 ' . $remaining . ' 秒后再试');
        }
    }

    protected static function findValidRecord(string $email, string $purpose, string $code): ?array
    {
        $db = Application::getInstance()->make('db');
        return $db->selectOne(
            'SELECT * FROM email_codes WHERE email = ? AND purpose = ? AND code = ? AND used_at IS NULL AND expires_at > NOW() ORDER BY id DESC LIMIT 1',
            [trim(strtolower($email)), $purpose, trim($code)]
        );
    }
}
