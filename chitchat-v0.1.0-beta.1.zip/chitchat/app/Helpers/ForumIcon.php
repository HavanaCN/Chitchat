<?php
namespace App\Helpers;

class ForumIcon
{
    public static function defaultPreset(): string
    {
        return 'chat-bubble';
    }

    public static function presets(): array
    {
        return [
            'chat-bubble' => [
                'label' => '经典气泡',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="8" y="10" width="48" height="34" rx="14" fill="#0EA5E9"/><path d="M20 44L18 56L30 46" fill="#0EA5E9"/><circle cx="22" cy="27" r="4" fill="#ffffff"/><circle cx="32" cy="27" r="4" fill="#ffffff"/><circle cx="42" cy="27" r="4" fill="#ffffff"/></svg>',
            ],
            'double-chat' => [
                'label' => '双层对话',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="10" y="14" width="30" height="24" rx="10" fill="#A855F7"/><path d="M22 38L18 47L28 39" fill="#A855F7"/><rect x="24" y="22" width="30" height="24" rx="10" fill="#EC4899"/><path d="M42 46L48 54L46 45" fill="#EC4899"/></svg>',
            ],
            'spark-chat' => [
                'label' => '灵感火花',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M32 6L34.7 13.3L42 16L34.7 18.7L32 26L29.3 18.7L22 16L29.3 13.3L32 6Z" fill="#F59E0B"/><rect x="12" y="22" width="40" height="26" rx="12" fill="#2563EB"/><path d="M24 48L20 58L32 49" fill="#2563EB"/><path d="M23 35H41" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/><path d="M23 28H34" stroke="#BFDBFE" stroke-width="4" stroke-linecap="round"/></svg>',
            ],
            'forum-stack' => [
                'label' => '论坛楼层',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="12" y="10" width="40" height="12" rx="6" fill="#0F766E"/><rect x="8" y="26" width="48" height="12" rx="6" fill="#14B8A6"/><rect x="14" y="42" width="36" height="12" rx="6" fill="#5EEAD4"/></svg>',
            ],
            'compass' => [
                'label' => '探索罗盘',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="32" cy="32" r="24" fill="#EEF2FF" stroke="#4F46E5" stroke-width="4"/><path d="M41 23L36 36L23 41L28 28L41 23Z" fill="#4F46E5"/><circle cx="32" cy="32" r="4" fill="#C7D2FE"/></svg>',
            ],
            'feather-pen' => [
                'label' => '羽笔写作',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M50 12C41 12 32 18 28 28L18 50L26 46L36 26C38 22 43 18 50 16V12Z" fill="#7C3AED"/><path d="M18 50L12 52L14 46L26 46L18 50Z" fill="#C4B5FD"/><path d="M33 31L42 40" stroke="#DDD6FE" stroke-width="4" stroke-linecap="round"/></svg>',
            ],
            'lighthouse' => [
                'label' => '灯塔',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28 16H36L40 52H24L28 16Z" fill="#DC2626"/><rect x="26" y="10" width="12" height="8" rx="3" fill="#FCA5A5"/><path d="M38 20L56 12V28L38 24V20Z" fill="#FCD34D"/><path d="M26 20L8 12V28L26 24V20Z" fill="#FDE68A"/><rect x="22" y="52" width="20" height="4" rx="2" fill="#991B1B"/></svg>',
            ],
            'mountain' => [
                'label' => '山形',
                'svg' => '<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="8" y="8" width="48" height="48" rx="14" fill="#DBEAFE"/><path d="M18 44L28 28L36 38L43 26L52 44H18Z" fill="#2563EB"/><path d="M24 28L28 22L32 28H24Z" fill="#93C5FD"/></svg>',
            ],
        ];
    }

    public static function normalizePreset(?string $preset): string
    {
        $presets = self::presets();
        return isset($presets[$preset ?? '']) ? (string)$preset : self::defaultPreset();
    }

    public static function resolve(array $settings): array
    {
        $type = ($settings['forum_icon_type'] ?? 'preset') === 'upload' ? 'upload' : 'preset';
        $upload = trim((string)($settings['forum_icon_upload'] ?? ''));

        if ($type === 'upload' && $upload !== '') {
            return [
                'type' => 'upload',
                'url' => Url::path('uploads/forum-icons/' . rawurlencode($upload)),
                'filename' => $upload,
            ];
        }


        $preset = self::normalizePreset($settings['forum_icon_preset'] ?? null);
        $presets = self::presets();

        return [
            'type' => 'preset',
            'preset' => $preset,
            'label' => $presets[$preset]['label'],
            'svg' => $presets[$preset]['svg'],
        ];
    }

    public static function render(array $settings, string $wrapperClass = 'forum-brand-icon'): string
    {
        $icon = self::resolve($settings);
        $class = htmlspecialchars($wrapperClass, ENT_QUOTES, 'UTF-8');

        if ($icon['type'] === 'upload') {
            return '<span class="' . $class . '"><img src="' . htmlspecialchars($icon['url'], ENT_QUOTES, 'UTF-8') . '" alt="" loading="lazy"></span>';
        }

        return '<span class="' . $class . '" aria-hidden="true">' . $icon['svg'] . '</span>';
    }
}
