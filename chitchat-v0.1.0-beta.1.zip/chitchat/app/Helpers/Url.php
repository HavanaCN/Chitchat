<?php
namespace App\Helpers;

use App\Core\Application;

class Url
{
    public static function baseUrl(): string
    {
        $configured = '';

        try {
            $configured = (string)Application::getInstance()->make('config')->get('app.base_url', '');
        } catch (\Throwable $e) {
            $configured = '';
        }

        if (trim($configured) !== '') {
            return self::normalizeBaseUrl($configured);
        }

        return self::detectBasePath();
    }

    public static function normalizeBaseUrl(?string $value): string
    {
        $value = trim((string)$value);
        if ($value === '' || $value === '/' || $value === '.') {
            return '';
        }

        if (preg_match('#^https?://#i', $value)) {
            return rtrim($value, '/');
        }

        $value = str_replace('\\', '/', $value);
        $path = parse_url($value, PHP_URL_PATH);
        $path = is_string($path) ? $path : $value;
        $path = '/' . trim($path, '/');

        return $path === '/' ? '' : rtrim($path, '/');
    }

    public static function detectBasePath(): string
    {
        $scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        $basePath = rtrim(dirname($scriptName), '/');

        if ($basePath === '' || $basePath === '.' || $basePath === '/') {
            return '';
        }

        return $basePath;
    }

    public static function path(string $path = ''): string
    {
        $baseUrl = self::baseUrl();
        $relative = ltrim($path, '/');

        if ($relative === '') {
            return $baseUrl !== '' ? $baseUrl : '/';
        }

        if ($baseUrl === '') {
            return '/' . $relative;
        }

        return rtrim($baseUrl, '/') . '/' . $relative;
    }

    public static function entryScript(): string
    {
        return self::path('index.php');
    }

    public static function route(string $path = '', array $query = []): string
    {
        $normalizedPath = self::normalizeRoutePath($path);
        $url = self::entryScript();

        if ($normalizedPath !== '') {
            $query = array_merge(['route' => ltrim($normalizedPath, '/')], $query);
        }

        return self::appendQuery($url, $query);
    }

    public static function normalizeRoutePath(?string $path): string
    {
        $path = trim((string)$path);
        if ($path === '' || $path === '/' || $path === 'index.php') {
            return '';
        }

        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#^/?index\.php/?#', '', $path) ?? $path;
        $path = trim($path, '/');

        return $path === '' ? '' : '/' . $path;
    }

    public static function appendQuery(string $url, array $query = []): string
    {
        $query = array_filter($query, static fn ($value) => $value !== null && $value !== '');
        if ($query === []) {
            return $url;
        }

        $separator = str_contains($url, '?') ? '&' : '?';
        return $url . $separator . http_build_query($query);
    }

    public static function prependIfRelativeRoot(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return self::path('');
        }

        if (
            preg_match('#^(?:[a-z][a-z0-9+.-]*:)?//#i', $url)
            || str_starts_with($url, '#')
            || str_starts_with($url, 'mailto:')
            || str_starts_with($url, 'javascript:')
        ) {
            return $url;
        }

        if (!str_starts_with($url, '/')) {
            return $url;
        }

        $baseUrl = self::baseUrl();
        if ($baseUrl === '') {
            return $url;
        }

        if (preg_match('#^https?://#i', $baseUrl)) {
            return rtrim($baseUrl, '/') . $url;
        }

        if ($url === $baseUrl || str_starts_with($url, $baseUrl . '/')) {
            return $url;
        }

        return $baseUrl . $url;
    }
}

