<?php
namespace App\Forum\Models;

use App\Core\BaseModel;

class Post extends BaseModel
{
    protected static string $table = 'posts';

    public static function getForDiscussion(int $discussionId, int $page = 1, int $perPage = 20): array
    {
        $db = static::db();
        $total = (int)($db->selectOne(
            'SELECT COUNT(*) as cnt FROM posts WHERE discussion_id = ? AND is_hidden = 0',
            [$discussionId]
        )['cnt'] ?? 0);


        $items = $db->select(
            'SELECT p.*, u.username, u.avatar, u.email as user_email, u.bio, u.created_at as user_joined,
                    u.group_id, g.name as group_name, g.display_name as group_display_name
             FROM posts p
             LEFT JOIN users u ON p.user_id = u.id
             LEFT JOIN groups g ON u.group_id = g.id
             WHERE p.discussion_id = ? AND p.is_hidden = 0
             ORDER BY p.number ASC
             LIMIT ? OFFSET ?',
            [$discussionId, $perPage, ($page - 1) * $perPage]
        );

        return [
            'data' => $items,
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => (int)ceil($total / $perPage),
        ];
    }

    public static function create(array $data): int
    {
        $db = static::db();
        $number = (int)($db->selectOne(
            'SELECT COALESCE(MAX(number), 0) + 1 as next_num FROM posts WHERE discussion_id = ?',
            [$data['discussion_id']]
        )['next_num'] ?? 1);

        $postId = $db->table('posts')->insert([
            'discussion_id' => $data['discussion_id'],
            'user_id' => $data['user_id'],
            'number' => $number,
            'content' => $data['content'],
            'reply_to' => $data['reply_to'] ?? null,
            'like_count' => 0,
            'is_hidden' => 0,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        $db->query(
            'UPDATE discussions SET comment_count = comment_count + 1, last_post_id = ?, last_user_id = ?, last_posted_at = NOW(), updated_at = NOW() WHERE id = ?',
            [$postId, $data['user_id'], $data['discussion_id']]
        );

        return $postId;
    }

    public static function getLikedByUser(int $postId, int $userId): bool
    {
        $row = static::db()->selectOne(
            'SELECT id FROM likes WHERE post_id = ? AND user_id = ?',
            [$postId, $userId]
        );
        return $row !== null;
    }

    public static function toggleLike(int $postId, int $userId): array
    {
        $db = static::db();
        $existing = $db->selectOne('SELECT id FROM likes WHERE post_id = ? AND user_id = ?', [$postId, $userId]);
        if ($existing) {
            $db->delete('DELETE FROM likes WHERE post_id = ? AND user_id = ?', [$postId, $userId]);
            $db->query('UPDATE posts SET like_count = like_count - 1 WHERE id = ?', [$postId]);
            return ['liked' => false];
        }

        $db->table('likes')->insert(['post_id' => $postId, 'user_id' => $userId, 'created_at' => date('Y-m-d H:i:s')]);
        $db->query('UPDATE posts SET like_count = like_count + 1 WHERE id = ?', [$postId]);
        return ['liked' => true];
    }
}
