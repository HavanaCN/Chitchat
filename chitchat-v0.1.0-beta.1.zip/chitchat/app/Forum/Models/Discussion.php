<?php
namespace App\Forum\Models;

use App\Core\BaseModel;
use App\Core\Database;
use App\Helpers\Helper;


class Discussion extends BaseModel
{
    protected static string $table = 'discussions';

    public static function getList(int $page = 1, int $perPage = 20, ?int $tagId = null, string $sort = 'last_reply'): array
    {
        $db = static::db();

        $orderBy = match ($sort) {
            'created' => 'd.created_at DESC',
            'hot' => 'd.comment_count DESC',
            default => 'd.last_posted_at DESC',
        };

        $sql = 'SELECT d.*, u.username, u.avatar, u.email as user_email,
                       lu.username as last_user_name, lu.avatar as last_user_avatar
                FROM discussions d
                LEFT JOIN users u ON d.user_id = u.id
                LEFT JOIN users lu ON d.last_user_id = lu.id';

        $bindings = [];
        if ($tagId) {
            $sql .= ' INNER JOIN discussion_tag dt ON d.id = dt.discussion_id AND dt.tag_id = ?';
            $bindings[] = $tagId;
        }

        $sql .= ' WHERE d.is_hidden = 0 ORDER BY d.is_sticky DESC, d.is_featured DESC, ' . $orderBy;

        $countSql = 'SELECT COUNT(*) as cnt FROM discussions d WHERE d.is_hidden = 0';
        if ($tagId) {
            $countSql .= ' AND EXISTS (SELECT 1 FROM discussion_tag dt WHERE dt.discussion_id = d.id AND dt.tag_id = ?)';
        }
        $total = (int)($db->selectOne($countSql, $tagId ? [$tagId] : [])['cnt'] ?? 0);

        $sql .= ' LIMIT ? OFFSET ?';
        $bindings[] = $perPage;
        $bindings[] = ($page - 1) * $perPage;

        $items = $db->select($sql, $bindings);
        foreach ($items as &$item) {
            $item['tags'] = Tag::getForDiscussion((int)$item['id']);
        }

        return [
            'data' => $items,
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => (int)ceil($total / $perPage),
        ];
    }

    public static function getDetail(int $id): ?array
    {
        return static::db()->selectOne(
            'SELECT d.*, u.username, u.avatar, u.email as user_email, u.group_id, u.bio,
                    u.created_at as user_joined, g.display_name as group_display_name, g.name as group_name
             FROM discussions d
             LEFT JOIN users u ON d.user_id = u.id
             LEFT JOIN groups g ON u.group_id = g.id
             WHERE d.id = ? AND d.is_hidden = 0',
            [$id]
        );
    }

    public static function syncVisibility(int $discussionId): bool
    {
        return static::db()->transaction(function (Database $db) use ($discussionId) {
            $visiblePosts = $db->select(
                'SELECT id, user_id, created_at
                 FROM posts
                 WHERE discussion_id = ? AND is_hidden = 0
                 ORDER BY number ASC, id ASC',
                [$discussionId]
            );

            if ($visiblePosts === []) {
                self::hideWithRelationsUsingDb($db, $discussionId, false);
                return false;
            }

            $firstPost = $visiblePosts[0];
            $lastPost = $visiblePosts[count($visiblePosts) - 1];
            $replyCount = max(count($visiblePosts) - 1, 0);

            $db->table('discussions')->where('id', $discussionId)->update([
                'first_post_id' => (int)$firstPost['id'],
                'last_post_id' => (int)$lastPost['id'],
                'last_user_id' => (int)$lastPost['user_id'],
                'comment_count' => $replyCount,
                'is_hidden' => 0,
                'last_posted_at' => (string)($lastPost['created_at'] ?? date('Y-m-d H:i:s')),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            return true;
        });
    }

    public static function hideWithRelations(int $discussionId): void
    {
        static::db()->transaction(function (Database $db) use ($discussionId) {
            self::hideWithRelationsUsingDb($db, $discussionId, true);
        });
    }

    protected static function hideWithRelationsUsingDb(Database $db, int $discussionId, bool $hidePosts): void
    {
        $postIds = array_map(
            static fn (array $row): int => (int)$row['id'],
            $db->select('SELECT id FROM posts WHERE discussion_id = ?', [$discussionId])
        );

        if ($hidePosts) {
            $db->query('UPDATE posts SET is_hidden = 1 WHERE discussion_id = ?', [$discussionId]);
        }

        $db->table('discussions')->where('id', $discussionId)->update([
            'first_post_id' => null,
            'last_post_id' => null,
            'last_user_id' => null,
            'comment_count' => 0,
            'is_hidden' => 1,
            'last_posted_at' => null,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        $db->delete('DELETE FROM discussion_tag WHERE discussion_id = ?', [$discussionId]);

        if ($postIds !== []) {
            $placeholders = implode(',', array_fill(0, count($postIds), '?'));
            $db->delete('DELETE FROM likes WHERE post_id IN (' . $placeholders . ')', $postIds);
        }

        self::deleteNotificationsForDiscussion($db, $discussionId, $postIds);
    }

    protected static function deleteNotificationsForDiscussion(Database $db, int $discussionId, array $postIds = []): void
    {
        $conditions = ['JSON_UNQUOTE(JSON_EXTRACT(data, "$.discussion_id")) = ?'];
        $bindings = [(string)$discussionId];

        if ($postIds !== []) {
            $conditions[] = 'JSON_UNQUOTE(JSON_EXTRACT(data, "$.post_id")) IN (' . implode(',', array_fill(0, count($postIds), '?')) . ')';
            $bindings = array_merge($bindings, array_map('strval', $postIds));
        }

        $db->delete('DELETE FROM notifications WHERE ' . implode(' OR ', $conditions), $bindings);
    }

    public static function create(array $data): int

    {
        $db = static::db();
        $now = date('Y-m-d H:i:s');
        $tagIds = self::normalizeTagIds($data['tag_ids'] ?? []);

        return $db->transaction(function ($db) use ($data, $now, $tagIds) {
            $discussionId = $db->table('discussions')->insert([
                'title' => $data['title'],
                'user_id' => $data['user_id'],
                'comment_count' => 0,
                'is_sticky' => 0,
                'is_locked' => 0,
                'is_featured' => 0,
                'is_hidden' => 0,
                'last_user_id' => $data['user_id'],
                'last_posted_at' => $now,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $postId = $db->table('posts')->insert([
                'discussion_id' => $discussionId,
                'user_id' => $data['user_id'],
                'number' => 1,
                'content' => $data['content'],
                'like_count' => 0,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $db->table('discussions')->where('id', $discussionId)->update([
                'first_post_id' => $postId,
                'last_post_id' => $postId,
            ]);

            foreach ($tagIds as $tagId) {
                $db->table('discussion_tag')->insert([
                    'discussion_id' => $discussionId,
                    'tag_id' => (int)$tagId,
                ]);
            }

            return $discussionId;
        });
    }

    public static function incrementCommentCount(int $id, int $userId): void
    {
        static::db()->query(
            'UPDATE discussions SET comment_count = comment_count + 1, last_user_id = ?, last_posted_at = NOW(), updated_at = NOW() WHERE id = ?',
            [$userId, $id]
        );
    }

    public static function search(string $q, int $page = 1, int $perPage = 20, ?string $author = null, ?int $tagId = null): array
    {
        $db = static::db();
        $page = max($page, 1);
        $keyword = trim(preg_replace('/\s+/u', ' ', $q) ?? $q);
        $author = $author !== null ? trim(preg_replace('/\s+/u', ' ', $author) ?? $author) : null;

        $conditions = ['d.is_hidden = 0'];
        $bindings = [];

        if ($keyword !== '') {
            $conditions[] = '(d.title LIKE ? OR EXISTS (SELECT 1 FROM posts p WHERE p.discussion_id = d.id AND p.is_hidden = 0 AND p.content LIKE ?))';
            $like = '%' . $keyword . '%';
            $bindings[] = $like;
            $bindings[] = $like;
        }

        if ($author !== null && $author !== '') {
            $conditions[] = 'u.username LIKE ?';
            $bindings[] = '%' . $author . '%';
        }

        if ($tagId !== null) {
            $conditions[] = 'EXISTS (SELECT 1 FROM discussion_tag dt WHERE dt.discussion_id = d.id AND dt.tag_id = ?)';
            $bindings[] = $tagId;
        }

        $whereSql = implode(' AND ', $conditions);
        $sql = 'SELECT d.*, u.username, u.avatar, u.email as user_email
                FROM discussions d
                LEFT JOIN users u ON d.user_id = u.id
                WHERE ' . $whereSql . '
                ORDER BY d.is_sticky DESC, d.is_featured DESC, d.last_posted_at DESC
                LIMIT ? OFFSET ?';
        $countSql = 'SELECT COUNT(*) as cnt
                     FROM discussions d
                     LEFT JOIN users u ON d.user_id = u.id
                     WHERE ' . $whereSql;

        $total = (int)($db->selectOne($countSql, $bindings)['cnt'] ?? 0);
        $items = $db->select($sql, array_merge($bindings, [$perPage, ($page - 1) * $perPage]));

        foreach ($items as &$item) {
            $item['tags'] = Tag::getForDiscussion((int)$item['id']);
            $excerpt = self::buildSearchExcerpt($db, (int)$item['id'], (string)($item['title'] ?? ''), $keyword);
            $item['search_excerpt'] = $excerpt['text'];
            $item['search_excerpt_source'] = $excerpt['source'];
        }
        unset($item);

        return [
            'data' => $items,
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => (int)ceil($total / $perPage),
        ];
    }

    protected static function buildSearchExcerpt(Database $db, int $discussionId, string $title, string $keyword): array
    {
        if ($keyword !== '') {
            $matchedPost = $db->selectOne(
                'SELECT content FROM posts WHERE discussion_id = ? AND is_hidden = 0 AND content LIKE ? ORDER BY number ASC, id ASC LIMIT 1',
                [$discussionId, '%' . $keyword . '%']
            );

            if ($matchedPost && !empty(trim((string)($matchedPost['content'] ?? '')))) {
                return [
                    'text' => self::excerptAroundKeyword((string)$matchedPost['content'], $keyword),
                    'source' => '内容命中',
                ];
            }

            return [
                'text' => self::excerptAroundKeyword($title, $keyword, 90),
                'source' => '标题命中',
            ];
        }

        $firstVisiblePost = $db->selectOne(
            'SELECT content FROM posts WHERE discussion_id = ? AND is_hidden = 0 ORDER BY number ASC, id ASC LIMIT 1',
            [$discussionId]
        );

        if ($firstVisiblePost && !empty(trim((string)($firstVisiblePost['content'] ?? '')))) {
            return [
                'text' => Helper::truncate(self::normalizeExcerptText((string)$firstVisiblePost['content']), 140),
                'source' => '讨论摘要',
            ];
        }

        return [
            'text' => Helper::truncate(self::normalizeExcerptText($title), 90),
            'source' => '标题摘要',
        ];
    }

    protected static function excerptAroundKeyword(string $text, string $keyword, int $length = 140): string
    {
        $plainText = self::normalizeExcerptText($text);
        if ($plainText === '') {
            return '';
        }

        $position = mb_stripos($plainText, $keyword);
        if ($position === false) {
            return Helper::truncate($plainText, $length);
        }

        $start = max($position - 28, 0);
        $sliceLength = max($length, mb_strlen($keyword) + 20);
        $slice = mb_substr($plainText, $start, $sliceLength);
        $prefix = $start > 0 ? '...' : '';
        $suffix = ($start + $sliceLength) < mb_strlen($plainText) ? '...' : '';

        return $prefix . trim($slice) . $suffix;
    }

    protected static function normalizeExcerptText(string $text): string
    {
        $plainText = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return trim(preg_replace('/\s+/u', ' ', $plainText) ?? $plainText);
    }

    public static function normalizeTagIds(array $tagIds): array
    {
        $tagIds = array_values(array_unique(array_filter(array_map('intval', $tagIds), static fn ($id) => $id > 0)));
        if ($tagIds !== []) {
            return $tagIds;
        }

        $uncategorizedId = Tag::uncategorizedId();
        return $uncategorizedId ? [$uncategorizedId] : [];
    }
}
