<?php
namespace App\Forum\Models;

use App\Core\BaseModel;

class Tag extends BaseModel
{
    protected static string $table = 'tags';

    public static function getTree(): array
    {
        $all = static::db()->select('SELECT * FROM tags ORDER BY position ASC, name ASC');
        $roots = [];
        $children = [];
        foreach ($all as $tag) {
            if ($tag['parent_id']) {
                $children[$tag['parent_id']][] = $tag;
            } else {
                $roots[] = $tag;
            }
        }
        foreach ($roots as &$root) {
            $root['children'] = $children[$root['id']] ?? [];
        }
        return $roots;
    }

    public static function getForDiscussion(int $discussionId): array
    {
        return static::db()->select(
            'SELECT t.* FROM tags t INNER JOIN discussion_tag dt ON t.id = dt.tag_id WHERE dt.discussion_id = ? ORDER BY t.position ASC, t.name ASC',
            [$discussionId]
        );
    }

    public static function findBySlug(string $slug): ?array
    {
        return static::db()->selectOne('SELECT * FROM tags WHERE slug = ?', [$slug]);
    }

    public static function findUncategorized(): ?array
    {
        return static::findBySlug('uncategorized');
    }

    public static function uncategorizedId(): ?int
    {
        $tag = static::findUncategorized();
        return $tag ? (int)$tag['id'] : null;
    }

    public static function getDiscussionCounts(): array
    {
        $rows = static::db()->select(
            'SELECT dt.tag_id, COUNT(*) as cnt
             FROM discussion_tag dt
             INNER JOIN discussions d ON d.id = dt.discussion_id
             WHERE d.is_hidden = 0
             GROUP BY dt.tag_id'
        );
        $counts = [];
        foreach ($rows as $row) {
            $counts[$row['tag_id']] = (int)$row['cnt'];
        }
        return $counts;
    }

}

