<?php
namespace App\Forum\Models;

use App\Core\BaseModel;
use App\Helpers\Url;

class User extends BaseModel
{
    protected static string $table = 'users';

    public static function findByEmail(string $email): ?array
    {
        return static::db()->selectOne('SELECT * FROM users WHERE email = ?', [$email]);
    }

    public static function findByUsername(string $username): ?array
    {
        return static::db()->selectOne('SELECT * FROM users WHERE username = ?', [$username]);
    }

    public static function register(array $data): int
    {
        return static::create([
            'username'   => $data['username'],
            'email'      => $data['email'],
            'password'   => password_hash($data['password'], PASSWORD_DEFAULT),
            'group_id'   => 3,
            'avatar'     => null,
            'bio'        => '',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function getWithGroup(int $id): ?array
    {
        return static::db()->selectOne(
            'SELECT u.*, g.name as group_name, g.display_name as group_display_name, g.permissions as group_permissions
             FROM users u
             LEFT JOIN groups g ON u.group_id = g.id
             WHERE u.id = ?',
            [$id]
        );
    }

    public static function getStats(int $id): array
    {
        $db = static::db();
        $postCount = $db->selectOne('SELECT COUNT(*) as cnt FROM posts WHERE user_id = ?', [$id]);
        $discussionCount = $db->selectOne('SELECT COUNT(*) as cnt FROM discussions WHERE user_id = ?', [$id]);
        return [
            'post_count'       => (int)($postCount['cnt'] ?? 0),
            'discussion_count' => (int)($discussionCount['cnt'] ?? 0),
        ];
    }

    public static function getAvatarUrl(array $user, int $size = 40): string
    {
        if (!empty($user['avatar'])) {
            return Url::path('uploads/avatars/' . rawurlencode((string)$user['avatar']));
        }
        $hash = md5(strtolower(trim($user['email'] ?? '')));
        return "https://www.gravatar.com/avatar/{$hash}?s={$size}&d=identicon";
    }
}

