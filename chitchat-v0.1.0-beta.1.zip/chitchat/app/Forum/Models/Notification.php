<?php
namespace App\Forum\Models;

use App\Core\BaseModel;

class Notification extends BaseModel
{
    protected static string $table = 'notifications';

    public static function send(int $toUserId, string $type, array $data, ?int $fromUserId = null): void
    {
        if ($toUserId === $fromUserId) return; // Don't notify yourself

        static::db()->table('notifications')->insert([
            'user_id'      => $toUserId,
            'from_user_id' => $fromUserId,
            'type'         => $type,
            'data'         => json_encode($data),
            'is_read'      => 0,
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
    }

    public static function getForUser(int $userId, int $limit = 20): array
    {
        return static::db()->select(
            'SELECT n.*, u.username as from_username, u.avatar as from_avatar, u.email as from_email
             FROM notifications n
             LEFT JOIN users u ON n.from_user_id = u.id
             WHERE n.user_id = ?
             ORDER BY n.created_at DESC
             LIMIT ?',
            [$userId, $limit]
        );
    }

    public static function getUnreadCount(int $userId): int
    {
        $row = static::db()->selectOne(
            'SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0',
            [$userId]
        );
        return (int)($row['cnt'] ?? 0);
    }

    public static function markAllRead(int $userId): void
    {
        static::db()->query('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [$userId]);
    }
}
