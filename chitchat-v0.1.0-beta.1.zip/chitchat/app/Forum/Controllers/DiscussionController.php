<?php
namespace App\Forum\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\Discussion;
use App\Forum\Models\Notification;
use App\Forum\Models\Post;
use App\Forum\Models\Tag;
use App\Helpers\GroupPermission;
use App\Helpers\Url;

class DiscussionController extends BaseController
{
    public function show(Request $request): Response
    {
        $id = (int)$request->param('id');
        $page = (int)$request->query('page', 1);

        $discussion = Discussion::getDetail($id);
        if (!$discussion) {
            throw new \RuntimeException('Discussion not found.', 404);
        }

        $posts = Post::getForDiscussion($id, $page);
        $tags = Tag::getForDiscussion($id);
        $user = $this->auth->user();

        if ($user) {
            foreach ($posts['data'] as &$post) {
                $post['is_liked'] = Post::getLikedByUser((int)$post['id'], (int)$user['id']);
            }
        }

        return $this->render('pages/discussion', [
            'discussion' => $discussion,
            'posts' => $posts,
            'tags' => $tags,
            'page' => $page,
        ]);
    }

    public function create(Request $request): Response
    {
        $this->requireAuth();

        $currentUser = $this->auth->user();
        if (!GroupPermission::canStartDiscussion($currentUser)) {
            throw new \RuntimeException('你当前所在用户组没有发帖权限', 403);
        }

        $tagTree = Tag::getTree();
        $tags = GroupPermission::filterTreeForPosting($tagTree, $currentUser);

        return $this->render('pages/discussion-create', [
            'tags' => $tags,
            'hasSelectableTags' => GroupPermission::flattenTree($tags) !== [],
            'canPublishWithoutCategory' => true,
            'canPublishAnnouncement' => GroupPermission::canManageAnnouncements($currentUser),
        ]);

    }


    public function store(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $currentUser = $this->auth->user();
        if (!GroupPermission::canStartDiscussion($currentUser)) {
            return $this->json(['error' => '你当前所在用户组没有发帖权限'], 403);
        }


        $errors = $request->validate([
            'title' => 'required|min:3|max:200',
            'content' => 'required|min:10',
        ]);
        if ($errors) {
            return $this->json(['errors' => $errors], 422);
        }

        $selectedTagIds = array_values(array_unique(array_filter(array_map('intval', (array)($request->input('tags') ?? [])), static fn ($id) => $id > 0)));
        $allTags = Tag::getTree();
        if (!$this->auth->isAdmin() && !GroupPermission::canPostToSelectedTags($currentUser, $selectedTagIds, $allTags)) {
            return $this->json(['error' => '公告分类仅管理员与版主可发帖，请重新选择普通分类'], 422);
        }



        $id = Discussion::create([
            'title' => htmlspecialchars((string)$request->input('title'), ENT_QUOTES, 'UTF-8'),
            'content' => (string)$request->input('content'),
            'user_id' => $this->auth->id(),
            'tag_ids' => $selectedTagIds,
        ]);

        $this->events->dispatch('discussion.created', ['id' => $id, 'user_id' => $this->auth->id()]);

        if ($request->isAjax()) {
            return $this->json(['redirect' => Url::route('d/' . $id)]);
        }

        return $this->redirect(Url::route('d/' . $id));
    }

    public function edit(Request $request): Response
    {
        $this->requireAuth();

        $id = (int)$request->param('id');
        $discussion = Discussion::getDetail($id);
        if (!$discussion) {
            throw new \RuntimeException('Not found', 404);
        }

        if ((int)$discussion['user_id'] !== (int)$this->auth->id() && !$this->auth->isAdmin()) {
            throw new \RuntimeException('Forbidden', 403);
        }

        $firstPost = $this->db->selectOne('SELECT * FROM posts WHERE id = ?', [$discussion['first_post_id']]);
        $tagTree = Tag::getTree();
        $discussionTags = Tag::getForDiscussion($id);
        $currentUser = $this->auth->user();
        $tags = GroupPermission::filterTreeForPosting($tagTree, $currentUser);

        return $this->render('pages/discussion-edit', [
            'discussion' => $discussion,
            'firstPost' => $firstPost,
            'tags' => $tags,
            'discussionTags' => $discussionTags,
            'hasSelectableTags' => GroupPermission::flattenTree($tags) !== [],
            'canPublishWithoutCategory' => true,
            'canPublishAnnouncement' => GroupPermission::canManageAnnouncements($currentUser),
        ]);


    }

    public function update(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        $discussion = Discussion::getDetail($id);
        if (!$discussion) {
            throw new \RuntimeException('Not found', 404);
        }
        if ((int)$discussion['user_id'] !== (int)$this->auth->id() && !$this->auth->isAdmin()) {
            throw new \RuntimeException('Forbidden', 403);
        }

        $title = htmlspecialchars((string)$request->input('title', ''), ENT_QUOTES, 'UTF-8');
        $content = (string)$request->input('content', '');
        if (mb_strlen($title, 'UTF-8') < 3) {
            return $this->json(['error' => '标题至少需要 3 个字符'], 422);
        }
        if (mb_strlen(trim($content), 'UTF-8') < 10) {
            return $this->json(['error' => '内容至少需要 10 个字符'], 422);
        }

        $selectedTagIds = array_values(array_unique(array_filter(array_map('intval', (array)($request->input('tags') ?? [])), static fn ($id) => $id > 0)));
        $allTags = Tag::getTree();
        $currentUser = $this->auth->user();
        if (!$this->auth->isAdmin() && !GroupPermission::canPostToSelectedTags($currentUser, $selectedTagIds, $allTags)) {
            return $this->json(['error' => '公告分类仅管理员与版主可发帖，请重新选择普通分类'], 422);
        }


        $tagIds = Discussion::normalizeTagIds($selectedTagIds);

        $this->db->table('discussions')->where('id', $id)->update([
            'title' => $title,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        $this->db->table('posts')->where('id', $discussion['first_post_id'])->update([
            'content' => $content,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        $this->db->delete('DELETE FROM discussion_tag WHERE discussion_id = ?', [$id]);
        foreach ($tagIds as $tagId) {
            $this->db->table('discussion_tag')->insert([
                'discussion_id' => $id,
                'tag_id' => $tagId,
            ]);
        }

        return $this->json(['redirect' => Url::route('d/' . $id)]);
    }

    public function destroy(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        $discussion = Discussion::getDetail($id);
        if (!$discussion) {
            throw new \RuntimeException('Not found', 404);
        }
        if ((int)$discussion['user_id'] !== (int)$this->auth->id() && !$this->auth->isAdmin()) {
            throw new \RuntimeException('Forbidden', 403);
        }

        Discussion::hideWithRelations($id);
        return $this->json(['redirect' => Url::route()]);

    }

    protected function requireDiscussionModeration(): void
    {
        if (!$this->auth->can('moderate')) {
            throw new \RuntimeException('Moderator access required.', 403);
        }
    }

    public function toggleSticky(Request $request): Response
    {
        $this->requireDiscussionModeration();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        $discussion = Discussion::getDetail($id);
        if (!$discussion) {
            throw new \RuntimeException('Not found', 404);
        }

        $new = !empty($discussion['is_sticky']) ? 0 : 1;
        $this->db->table('discussions')->where('id', $id)->update(['is_sticky' => $new]);
        return $this->json(['sticky' => (bool)$new]);
    }

    public function toggleFeatured(Request $request): Response
    {
        $this->requireDiscussionModeration();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        $discussion = Discussion::getDetail($id);
        if (!$discussion) {
            throw new \RuntimeException('Not found', 404);
        }

        $new = !empty($discussion['is_featured']) ? 0 : 1;
        $this->db->table('discussions')->where('id', $id)->update(['is_featured' => $new]);
        return $this->json(['featured' => (bool)$new]);
    }

    public function toggleLock(Request $request): Response
    {
        $this->requireDiscussionModeration();
        $this->validateCsrf($request);

        $id = (int)$request->param('id');
        $discussion = Discussion::getDetail($id);
        if (!$discussion) {
            throw new \RuntimeException('Not found', 404);
        }

        $new = !empty($discussion['is_locked']) ? 0 : 1;
        $this->db->table('discussions')->where('id', $id)->update(['is_locked' => $new]);
        return $this->json(['locked' => (bool)$new]);
    }
}
