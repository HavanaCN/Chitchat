<?php
namespace App\Forum\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\Notification;
use App\Forum\Models\User;
use App\Helpers\EmailCode;
use App\Helpers\Mailer;
use App\Helpers\Settings;
use App\Helpers\Url;

class AuthController extends BaseController
{
    public function showLogin(Request $request): Response
    {
        return $this->redirect(Url::route());
    }

    public function login(Request $request): Response
    {
        $this->validateCsrf($request);

        $login = trim((string)$request->input('login', $request->input('email', '')));
        $password = (string)$request->input('password', '');
        $remember = (bool)$request->input('remember', false);

        if (!$this->auth->attempt($login, $password, $remember)) {
            if ($request->isAjax()) {
                return $this->json(['error' => '用户名、邮箱或密码不正确'], 401);
            }

            $this->session->flash('error', '用户名、邮箱或密码不正确');
            return $this->redirect(Url::route());
        }

        $redirect = trim((string)$request->input('redirect', ''));
        if ($redirect === '' || $redirect === '/') {
            $redirect = Url::route();
        } elseif (str_starts_with($redirect, '/')) {
            $redirect = Url::route($redirect);
        }

        if ($request->isAjax()) {
            return $this->json(['redirect' => Url::prependIfRelativeRoot($redirect)]);
        }

        return $this->redirect($redirect);
    }

    public function showRegister(Request $request): Response
    {
        return $this->redirect(Url::route());
    }

    public function register(Request $request): Response
    {
        $this->validateCsrf($request);

        $settings = $this->getForumSettings();
        if (empty($settings['allow_registration'])) {
            return $this->json(['error' => '当前站点已关闭注册'], 403);
        }

        $errors = $request->validate([
            'username' => 'required|min:3|max:30',
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        $username = trim((string)$request->input('username', ''));
        $email = trim((string)$request->input('email', ''));
        $password = (string)$request->input('password', '');
        $emailCode = trim((string)$request->input('email_code', ''));
        $smtpEnabled = Settings::isSmtpEnabled($settings);

        if (filter_var($username, FILTER_VALIDATE_EMAIL)) {
            $errors['username'][] = '用户名不能直接使用邮箱地址';
        }

        if (!$errors) {
            if (User::findByEmail($email)) {
                $errors['email'][] = '该邮箱已被注册';
            }
            if (User::findByUsername($username)) {
                $errors['username'][] = '该用户名已被使用';
            }
        }

        if ($smtpEnabled && $emailCode === '') {
            $errors['email_code'][] = '请输入邮箱验证码';
        }

        if ($errors) {
            return $this->respondValidationErrors($request, $errors);
        }

        if ($smtpEnabled && !EmailCode::consume($email, 'register', $emailCode)) {
            return $this->respondValidationErrors($request, [
                'email_code' => ['邮箱验证码无效或已过期，请重新获取'],
            ]);
        }

        $userId = User::register([
            'username' => $username,
            'email' => $email,
            'password' => $password,
        ]);
        $user = User::getWithGroup($userId) ?? User::find($userId);
        $this->auth->login($user ?? ['id' => $userId]);

        if ($request->isAjax()) {
            return $this->json([
                'redirect' => Url::route(),
                'message' => '注册成功，欢迎加入！',
            ]);
        }

        return $this->redirect(Url::route());
    }

    public function sendRegisterCode(Request $request): Response
    {
        $this->validateCsrf($request);

        $settings = $this->getForumSettings();
        if (empty($settings['allow_registration'])) {
            return $this->json(['error' => '当前站点已关闭注册'], 403);
        }
        if (!Settings::isSmtpEnabled($settings)) {
            return $this->json(['error' => $this->smtpUnavailableMessage()], 403);
        }

        $username = trim((string)$request->input('username', '新用户'));
        $email = trim((string)$request->input('email', ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->json(['error' => '请先填写有效的邮箱地址'], 422);
        }
        if (User::findByEmail($email)) {
            return $this->json(['error' => '该邮箱已被注册'], 422);
        }
        if ($username !== '' && User::findByUsername($username)) {
            return $this->json(['error' => '该用户名已被使用，请更换后再获取验证码'], 422);
        }

        try {
            $payload = EmailCode::issue($email, 'register');
            $this->sendTemplatedMail(
                $settings,
                $email,
                $username === '' ? '新用户' : $username,
                Settings::mailTemplate('mail_register_verify_subject', $settings),
                Settings::mailTemplate('mail_register_verify_body', $settings),
                $payload
            );

            return $this->json([
                'success' => true,
                'message' => '验证码已发送，请留意收件箱或垃圾邮件箱',
            ]);
        } catch (\Throwable $e) {
            return $this->json(['error' => $e->getMessage()], 422);
        }
    }

    public function sendResetPasswordCode(Request $request): Response
    {
        $this->validateCsrf($request);

        $settings = $this->getForumSettings();
        if (!Settings::isSmtpEnabled($settings)) {
            return $this->json(['error' => $this->smtpUnavailableMessage()], 403);
        }

        $email = trim((string)$request->input('email', ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->json(['error' => '请输入有效的注册邮箱'], 422);
        }

        $user = User::findByEmail($email);
        if (!$user) {
            return $this->json(['error' => '未找到该邮箱对应的账号'], 404);
        }

        try {
            $payload = EmailCode::issue($email, 'reset_password');
            $this->sendTemplatedMail(
                $settings,
                $email,
                (string)$user['username'],
                Settings::mailTemplate('mail_reset_password_subject', $settings),
                Settings::mailTemplate('mail_reset_password_body', $settings),
                $payload
            );

            return $this->json([
                'success' => true,
                'message' => '重置验证码已发送，请检查你的邮箱',
            ]);
        } catch (\Throwable $e) {
            return $this->json(['error' => $e->getMessage()], 422);
        }
    }

    public function resetPassword(Request $request): Response
    {
        $this->validateCsrf($request);

        $settings = $this->getForumSettings();
        if (!Settings::isSmtpEnabled($settings)) {
            return $this->json(['error' => $this->smtpUnavailableMessage()], 403);
        }

        $errors = $request->validate([
            'email' => 'required|email',
            'code' => 'required|min:6|max:6',
            'password' => 'required|min:6',
        ]);

        $email = trim((string)$request->input('email', ''));
        $code = trim((string)$request->input('code', ''));
        $password = (string)$request->input('password', '');
        $confirmPassword = (string)$request->input('password_confirm', '');

        if ($confirmPassword === '') {
            $errors['password_confirm'][] = '请再次输入新密码';
        } elseif ($password !== $confirmPassword) {
            $errors['password_confirm'][] = '两次输入的密码不一致';
        }

        $user = filter_var($email, FILTER_VALIDATE_EMAIL) ? User::findByEmail($email) : null;
        if (!$user) {
            $errors['email'][] = '未找到该邮箱对应的账号';
        }

        if ($errors) {
            return $this->json(['errors' => $errors], 422);
        }

        if (!EmailCode::consume($email, 'reset_password', $code)) {
            return $this->json(['errors' => ['code' => ['验证码无效或已过期，请重新获取']]], 422);
        }

        User::update((int)$user['id'], [
            'password' => password_hash($password, PASSWORD_DEFAULT),
        ]);

        return $this->json([
            'success' => true,
            'message' => '密码已重置，现在可以使用新密码登录',
        ]);
    }

    public function logout(Request $request): Response
    {
        $this->validateCsrf($request);
        $this->auth->logout();
        return $this->redirect(Url::route());
    }

    public function notifications(Request $request): Response
    {
        $this->requireAuth();
        $notifications = Notification::getForUser($this->auth->id(), 30);
        Notification::markAllRead($this->auth->id());
        return $this->json(['notifications' => $notifications]);
    }

    public function notificationCount(Request $request): Response
    {
        if (!$this->auth->check()) {
            return $this->json(['count' => 0]);
        }

        $count = Notification::getUnreadCount($this->auth->id());
        return $this->json(['count' => $count]);
    }

    protected function respondValidationErrors(Request $request, array $errors): Response
    {
        if ($request->isAjax()) {
            return $this->json(['errors' => $errors], 422);
        }

        $this->session->flash('errors', $errors);
        return $this->redirect(Url::route());
    }

    protected function sendTemplatedMail(array $settings, string $email, string $username, string $subjectTemplate, string $bodyTemplate, array $payload): void
    {
        $siteUrl = trim((string)($settings['forum_url'] ?? ''));
        if ($siteUrl === '') {
            $siteUrl = Url::prependIfRelativeRoot(Url::route());
        }

        $variables = [
            'forum_name' => $settings['forum_name'] ?? 'Chitchat',
            'username' => $username,
            'code' => $payload['code'],
            'expires_minutes' => $payload['expires_minutes'],
            'site_url' => $siteUrl,
        ];

        $subject = Settings::renderTemplate($subjectTemplate, $variables);
        $body = Settings::renderTemplate($bodyTemplate, $variables);

        $mailer = new Mailer($settings);
        $mailer->send($email, $subject, $body, $username);
    }

    protected function smtpUnavailableMessage(): string
    {
        return '当前站点的邮件服务尚未启用或还没通过 SMTP 测试验证，暂不支持验证码与密码找回功能，请联系站点管理员处理。';
    }

}
