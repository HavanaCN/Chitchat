<?php
namespace App\Forum\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\Discussion;
use App\Forum\Models\Tag;

class HomeController extends BaseController
{
    public function index(Request $request): Response
    {
        $page  = (int)($request->query('page', 1));
        $sort  = $request->query('sort', 'last_reply');
        $tagSlug = $request->query('tag');

        $tagId = null;
        $currentTag = null;
        if ($tagSlug) {
            $currentTag = Tag::findBySlug($tagSlug);
            $tagId = $currentTag['id'] ?? null;
        }

        $discussions = Discussion::getList($page, 20, $tagId, $sort);
        $tags        = Tag::getTree();
        $tagCounts   = Tag::getDiscussionCounts();

        return $this->render('pages/home', [
            'discussions' => $discussions,
            'tags'        => $tags,
            'tagCounts'   => $tagCounts,
            'currentTag'  => $currentTag,
            'sort'        => $sort,
            'page'        => $page,
        ]);
    }

    public function search(Request $request): Response
    {
        $q = trim($request->query('q', ''));
        $author = trim($request->query('author', ''));
        $tagSlug = trim($request->query('tag', ''));
        $page = (int)$request->query('page', 1);

        $currentTag = $tagSlug !== '' ? Tag::findBySlug($tagSlug) : null;
        $tagId = $currentTag ? (int)$currentTag['id'] : null;
        $tags = Tag::getTree();

        $results = [];
        if ($q !== '' || $author !== '' || $tagId !== null) {
            $results = Discussion::search($q, $page, 20, $author !== '' ? $author : null, $tagId);
        }

        return $this->render('pages/search', [
            'q' => $q,
            'author' => $author,
            'results' => $results,
            'tags' => $tags,
            'currentTag' => $currentTag,
            'selectedTagSlug' => $currentTag['slug'] ?? '',
            'page' => $page,
        ]);
    }
}
