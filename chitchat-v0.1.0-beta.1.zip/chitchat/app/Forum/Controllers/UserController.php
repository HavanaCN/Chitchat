<?php
namespace App\Forum\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\User;

class UserController extends BaseController
{
    public function profile(Request $request): Response
    {
        $username = $request->param('username');
        $baseUser = User::findByUsername($username);
        if (!$baseUser) {
            throw new \RuntimeException('User not found', 404);
        }

        $user = User::getWithGroup((int)$baseUser['id']) ?? $baseUser;
        $stats = User::getStats((int)$user['id']);
        $recentDiscussions = $this->db->select(
            'SELECT d.id, d.title, d.created_at FROM discussions d WHERE d.user_id = ? AND d.is_hidden = 0 ORDER BY d.created_at DESC LIMIT 10',
            [$user['id']]
        );

        return $this->render('pages/profile', [
            'profileUser' => $user,
            'stats' => $stats,
            'recentDiscussions' => $recentDiscussions,
            'avatarUrl' => User::getAvatarUrl($user, 80),
        ]);
    }

    public function editProfile(Request $request): Response
    {
        $this->requireAuth();
        $user = $this->auth->user();

        return $this->render('pages/settings', [
            'profileUser' => $user,
            'avatarUrl' => User::getAvatarUrl($user, 80),
        ]);
    }

    public function updateProfile(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $userId = $this->auth->id();
        $bio = htmlspecialchars((string)$request->input('bio', ''), ENT_QUOTES, 'UTF-8');
        $updateData = ['bio' => $bio];

        $file = $request->file('avatar');
        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            if (($file['size'] ?? 0) > 2 * 1024 * 1024) {
                return $this->json(['error' => '图片大小不能超过2MB'], 422);
            }

            $imageInfo = @getimagesize($file['tmp_name']);
            $allowedTypes = [
                IMAGETYPE_JPEG => 'jpg',
                IMAGETYPE_PNG => 'png',
                IMAGETYPE_GIF => 'gif',
                IMAGETYPE_WEBP => 'webp',
            ];

            if (!$imageInfo || !isset($allowedTypes[$imageInfo[2] ?? null])) {
                return $this->json(['error' => '只允许上传 JPG、PNG、GIF、WEBP 图片'], 422);
            }

            $ext = $allowedTypes[$imageInfo[2]];
            $filename = 'avatar_' . $userId . '_' . time() . '.' . $ext;
            $destPath = PUBLIC_PATH . '/uploads/avatars/' . $filename;

            if (!is_dir(dirname($destPath)) && !mkdir(dirname($destPath), 0755, true)) {
                return $this->json(['error' => '创建头像目录失败'], 500);
            }

            if (!move_uploaded_file($file['tmp_name'], $destPath)) {
                return $this->json(['error' => '保存头像失败，请稍后重试'], 500);
            }

            $updateData['avatar'] = $filename;
        }

        $newPassword = (string)$request->input('new_password', '');
        if ($newPassword !== '') {
            if (strlen($newPassword) < 6) {
                return $this->json(['error' => '密码至少6位'], 422);
            }
            $currentUser = User::find((int)$userId);
            if (!$currentUser || !password_verify((string)$request->input('current_password', ''), (string)$currentUser['password'])) {
                return $this->json(['error' => '当前密码不正确'], 422);
            }
            $updateData['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
        }

        User::update((int)$userId, $updateData);

        $updatedUser = User::find((int)$userId);
        $response = [
            'success' => true,
            'message' => '个人资料已更新',
        ];

        if (!empty($updatedUser['avatar']) || array_key_exists('avatar', $updateData)) {
            $response['avatar_url'] = User::getAvatarUrl($updatedUser, 80) . '?v=' . time();
        }

        return $this->json($response);
    }
}
