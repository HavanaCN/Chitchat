<?php
namespace App\Forum\Controllers;

use App\Core\BaseController;
use App\Core\Request;
use App\Core\Response;
use App\Forum\Models\Discussion;
use App\Forum\Models\Notification;
use App\Forum\Models\Post;
use App\Helpers\Url;

class PostController extends BaseController
{
    public function store(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $discussionId = (int)$request->param('id');
        $discussion = Discussion::getDetail($discussionId);
        if (!$discussion) {
            throw new \RuntimeException('Discussion not found', 404);
        }
        if (!empty($discussion['is_locked']) && !$this->auth->isAdmin()) {
            return $this->json(['error' => 'Discussion is locked'], 403);
        }

        $errors = $request->validate(['content' => 'required|min:1']);
        if ($errors) {
            return $this->json(['errors' => $errors], 422);
        }

        $replyToId = $request->input('reply_to') ? (int)$request->input('reply_to') : null;
        $replyToPost = $replyToId ? $this->findReplyTarget($replyToId, $discussionId) : null;
        if ($replyToId && !$replyToPost) {
            return $this->json(['error' => '引用的楼层不存在或已删除'], 422);
        }

        $content = $this->prependQuotedUserMention((string)$request->input('content'), $replyToPost['username'] ?? null);

        $postId = Post::create([
            'discussion_id' => $discussionId,
            'user_id' => $this->auth->id(),
            'content' => $content,
            'reply_to' => $replyToId,
        ]);

        $excludedMentionUserIds = [];
        if ($replyToPost && (int)$replyToPost['user_id'] !== (int)$this->auth->id()) {
            $excludedMentionUserIds[] = (int)$replyToPost['user_id'];
            Notification::send($replyToPost['user_id'], 'quoted_reply', [
                'discussion_id' => $discussionId,
                'discussion_title' => $discussion['title'],
                'post_id' => $postId,
                'quoted_post_id' => (int)$replyToPost['id'],
                'quoted_post_number' => (int)($replyToPost['number'] ?? 0),
                'quoted_by' => $this->auth->user()['username'],
            ], $this->auth->id());
        }

        $this->processMentions($content, $discussionId, $postId, $discussion['title'], $excludedMentionUserIds);

        $post = $this->db->selectOne(
            'SELECT p.*, u.username, u.avatar, u.email as user_email, g.name as group_name, g.display_name as group_display_name
             FROM posts p
             LEFT JOIN users u ON p.user_id = u.id
             LEFT JOIN groups g ON u.group_id = g.id
             WHERE p.id = ?',
            [$postId]
        );

        $this->events->dispatch('post.created', ['post' => $post, 'discussion' => $discussion]);

        if ((int)$discussion['user_id'] !== (int)$this->auth->id()) {
            Notification::send($discussion['user_id'], 'new_reply', [
                'discussion_id' => $discussionId,
                'discussion_title' => $discussion['title'],
                'post_id' => $postId,
            ], $this->auth->id());
        }

        return $this->json(['post' => $post]);
    }

    public function uploadEditorImage(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $file = $request->file('image');
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return $this->json(['error' => '上传图片失败，请重新选择文件'], 400);
        }

        if (($file['size'] ?? 0) > 5 * 1024 * 1024) {
            return $this->json(['error' => '图片大小不能超过 5MB'], 422);
        }

        $imageInfo = @getimagesize($file['tmp_name']);
        $allowedTypes = [
            IMAGETYPE_JPEG => 'jpg',
            IMAGETYPE_PNG => 'png',
            IMAGETYPE_GIF => 'gif',
            IMAGETYPE_WEBP => 'webp',
        ];

        if (!$imageInfo || !isset($allowedTypes[$imageInfo[2] ?? null])) {
            return $this->json(['error' => '只允许上传 JPG、PNG、GIF、WEBP 图片'], 422);
        }

        $folder = date('Y/m');
        $ext = $allowedTypes[$imageInfo[2]];
        $random = bin2hex(random_bytes(4));
        $filename = 'post_' . $this->auth->id() . '_' . date('YmdHis') . '_' . $random . '.' . $ext;
        $relativeDir = '/uploads/posts/' . $folder;
        $destDir = PUBLIC_PATH . $relativeDir;
        $destPath = $destDir . '/' . $filename;

        if (!is_dir($destDir) && !mkdir($destDir, 0755, true)) {
            return $this->json(['error' => '创建图片目录失败'], 500);
        }

        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            return $this->json(['error' => '保存图片失败，请稍后重试'], 500);
        }

        $relativeUrl = $relativeDir . '/' . $filename;
        $url = Url::path(ltrim($relativeUrl, '/'));
        $alt = preg_replace('/[^a-zA-Z0-9\-_\x{4e00}-\x{9fa5}]+/u', '-', pathinfo($file['name'], PATHINFO_FILENAME) ?: 'image');
        $alt = trim((string)$alt, '-') ?: 'image';

        return $this->json([
            'success' => true,
            'url' => $url,
            'markdown' => '![' . $alt . '](' . $url . ')',
        ]);
    }

    public function update(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $postId = (int)$request->param('postId');
        $post = Post::find($postId);
        if (!$post) {
            throw new \RuntimeException('Post not found', 404);
        }
        if ((int)$post['user_id'] !== (int)$this->auth->id() && !$this->auth->isAdmin()) {
            throw new \RuntimeException('Forbidden', 403);
        }

        $content = (string)$request->input('content', '');
        if (trim($content) === '') {
            return $this->json(['error' => 'Content required'], 422);
        }

        $this->db->table('posts')->where('id', $postId)->update([
            'content' => $content,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        return $this->json(['content' => $content]);
    }

    public function destroy(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $postId = (int)$request->param('postId');
        $post = Post::find($postId);
        if (!$post) {
            throw new \RuntimeException('Post not found', 404);
        }
        if ((int)$post['user_id'] !== (int)$this->auth->id() && !$this->auth->isAdmin()) {
            throw new \RuntimeException('Forbidden', 403);
        }

        if (!empty($post['is_hidden'])) {
            return $this->json(['success' => true]);
        }

        $this->db->table('posts')->where('id', $postId)->update(['is_hidden' => 1]);
        $discussionVisible = Discussion::syncVisibility((int)$post['discussion_id']);

        if (!$discussionVisible) {
            return $this->json([
                'success' => true,
                'discussion_deleted' => true,
                'redirect' => Url::route(),
            ]);
        }

        return $this->json(['success' => true]);

    }

    public function like(Request $request): Response
    {
        $this->requireAuth();
        $this->validateCsrf($request);

        $postId = (int)$request->param('postId');
        $result = Post::toggleLike($postId, $this->auth->id());
        return $this->json($result);
    }

    protected function findReplyTarget(int $replyToId, int $discussionId): ?array
    {
        return $this->db->selectOne(
            'SELECT p.id, p.user_id, p.number, u.username
             FROM posts p
             LEFT JOIN users u ON p.user_id = u.id
             WHERE p.id = ? AND p.discussion_id = ? AND p.is_hidden = 0',
            [$replyToId, $discussionId]
        );
    }

    protected function prependQuotedUserMention(string $content, ?string $username): string
    {
        $content = trim($content);
        $username = trim((string)$username);
        if ($username === '') {
            return $content;
        }

        $mentionPattern = '/(^|\s)@' . preg_quote($username, '/') . '(?=\s|$)/u';
        if (preg_match($mentionPattern, $content) === 1) {
            return $content;
        }

        return '@' . $username . ($content === '' ? '' : ' ' . $content);
    }

    protected function processMentions(string $content, int $discussionId, int $postId, string $discussionTitle, array $excludedUserIds = []): void
    {
        preg_match_all('/@(\w+)/', $content, $matches);
        $excludedUserIds = array_map('intval', $excludedUserIds);

        foreach (array_unique($matches[1]) as $username) {
            $user = $this->db->selectOne('SELECT id FROM users WHERE username = ?', [$username]);
            $userId = (int)($user['id'] ?? 0);
            if ($userId > 0
                && $userId !== (int)$this->auth->id()
                && !in_array($userId, $excludedUserIds, true)
            ) {
                Notification::send($userId, 'mention', [
                    'discussion_id' => $discussionId,
                    'discussion_title' => $discussionTitle,
                    'post_id' => $postId,
                    'mentioned_by' => $this->auth->user()['username'],
                ], $this->auth->id());
            }
        }
    }
}
